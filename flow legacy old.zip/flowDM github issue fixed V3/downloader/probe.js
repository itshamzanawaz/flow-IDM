/* ================================================================
 *  Flow — URL probe + save-target resolution
 *  HEAD first; falls back to GET + Range: bytes=0-0 when the server
 *  refuses HEAD, doesn't advertise ranges, or omits Content-Length.
 *
 *  Captures ETag / Last-Modified / Content-Type and derives a single
 *  `validator` (strong ETag preferred) that workers send as If-Range
 *  and that resume validation compares against. `finalUrl` is the
 *  post-redirect URL and is used by MOTW and by callers that re-probe
 *  on validator mismatch.
 * ================================================================ */

const axios = require("axios");
const fsp = require("fs/promises");
const path = require("path");

const { PROBE_TIMEOUT_MS, MB } = require("./config");
const { USER_AGENT } = require("./worker/config");
const { parseFilename, uniquePath } = require("./utils");
const { computeWorkerCount, computeChunkSize } = require("./chunkState");

async function prepareDownload(url, saveDirectory, extraHeaders = {}) {
  if (!url || typeof url !== "string") throw new Error("Invalid URL");
  try {
    const u = new URL(url);
    if (u.protocol !== "http:" && u.protocol !== "https:") {
      throw new Error("Unsupported URL scheme");
    }
  } catch {
    throw new Error("Malformed URL");
  }

  try {
    await fsp.mkdir(saveDirectory, { recursive: true });
  } catch (err) {
    throw new Error(`Cannot access save directory: ${err.message}`);
  }

  let totalSize = null;
  let acceptRanges = null;
  let disposition = null;
  let finalUrl = url;
  let etag = null;
  let lastModified = null;
  let contentType = null;

  /* ---- HEAD ---- */
  let headFailed = false;
  try {
    const res = await axios.head(url, {
      timeout: PROBE_TIMEOUT_MS,
      maxRedirects: 10,
      headers: {
        "User-Agent": USER_AGENT,
        "Accept-Encoding": "identity",
        ...extraHeaders,
      },
      validateStatus: () => true,
    });
    if (res.status >= 200 && res.status < 300) {
      acceptRanges = res.headers["accept-ranges"];
      // Only trust Content-Length when the response is not encoded —
      // otherwise it is the compressed length, not the file length.
      if (!res.headers["content-encoding"]) {
        const len = parseInt(res.headers["content-length"], 10);
        if (Number.isFinite(len) && len > 0) totalSize = len;
      }
      disposition = res.headers["content-disposition"];
      contentType = res.headers["content-type"] || contentType;
      etag = res.headers["etag"] || null;
      lastModified = res.headers["last-modified"] || null;
      finalUrl = res.request?.res?.responseUrl || url;
    } else {
      // 404, 405, 5xx — fall through to GET like any other HEAD failure.
      headFailed = true;
    }
  } catch (err) {
    if (err.code === "ENOTFOUND")    throw new Error("Host not found. Check your connection.");
    if (err.code === "ECONNREFUSED") throw new Error("Connection refused by server.");
    headFailed = true;
  }

  /* ---- GET + Range fallback ---- */
  if (headFailed || !totalSize || !acceptRanges || acceptRanges === "none") {
    let probe;
    try {
      probe = await axios.get(url, {
        timeout: PROBE_TIMEOUT_MS,
        maxRedirects: 10,
        headers: {
          "User-Agent": USER_AGENT,
          ...extraHeaders,
          Range: "bytes=0-0",
          "Accept-Encoding": "identity",
        },
        responseType: "stream",
        validateStatus: () => true,
      });
    } catch (err) {
      throw new Error(`Could not reach server: ${err.message}`);
    }
    try { probe.data.destroy(); } catch {}

    if (probe.status === 401 || probe.status === 403) {
      throw new Error(`Server rejected the request (HTTP ${probe.status}). The link may have expired or require authentication.`);
    }
    if (probe.status === 404) throw new Error("File not found (HTTP 404).");
    if (probe.status >= 400)  throw new Error(`Server error (HTTP ${probe.status}).`);

    const contentRange = probe.headers["content-range"];
    if (contentRange) {
      const m = contentRange.match(/bytes\s+\d+-\d+\/(\d+)/i);
      if (m) totalSize = parseInt(m[1], 10);
      acceptRanges = "bytes";
    }
    if (!totalSize) {
      const len = parseInt(probe.headers["content-length"], 10);
      if (Number.isFinite(len) && len > 0 && probe.status === 200) totalSize = len;
    }
    if (!disposition) disposition = probe.headers["content-disposition"];
    if (!acceptRanges) acceptRanges = probe.headers["accept-ranges"];
    if (!contentType) contentType = probe.headers["content-type"] || null;
    if (!etag) etag = probe.headers["etag"] || null;
    if (!lastModified) lastModified = probe.headers["last-modified"] || null;
    finalUrl = probe.request?.res?.responseUrl || url;
  }

  if (!acceptRanges || acceptRanges === "none") {
    throw new Error("Server does not support resumable downloads (no Range support).");
  }
  if (!Number.isFinite(totalSize) || totalSize <= 0) {
    throw new Error("Could not determine file size from the server.");
  }

  /* ---- Disk space check (unchanged) ---- */
  try {
    if (typeof fsp.statfs === "function") {
      const stats = await fsp.statfs(saveDirectory);
      const freeBytes = Number(stats.bavail) * Number(stats.bsize);
      if (freeBytes > 0 && freeBytes < totalSize * 1.1) {
        const need = (totalSize / 1e9).toFixed(2);
        const free = (freeBytes / 1e9).toFixed(2);
        throw new Error(`Not enough disk space. Need ~${need} GB, only ${free} GB free.`);
      }
    }
  } catch (err) {
    if (err.message && err.message.includes("disk space")) throw err;
  }

  const rawName = parseFilename(disposition, finalUrl);
  const filePath = uniquePath(saveDirectory, rawName);
  const fileName = path.basename(filePath);

  const workers = computeWorkerCount(totalSize);
  const chunkSize = computeChunkSize(totalSize, workers);
  const numChunks = Math.ceil(totalSize / chunkSize);

  // Strong ETag preferred for If-Range (weak etags are not validators
  // for byte ranges per RFC 7233 §3.2). Fall back to Last-Modified.
  const validator = (etag && !etag.startsWith("W/")) ? etag : (lastModified || null);

  console.log(
    `[prepareDownload] size=${(totalSize / MB).toFixed(1)}MB ` +
    `ranges=${acceptRanges} workers=${workers} ` +
    `chunkSize=${(chunkSize / MB).toFixed(1)}MB chunks=${numChunks} ` +
    `name="${fileName}" validator=${validator ? "yes" : "none"}`
  );

  return { fileName, filePath, totalSize, etag, lastModified, validator, contentType, finalUrl };
}

module.exports = { prepareDownload };