/* ================================================================
 *  Flow — download engine constants
 * ================================================================ */

const MB = 1024 * 1024;
const GB = 1024 * MB;

module.exports = {
  MB,
  GB,

  MAX_THREADS: 20,
  MIN_CHUNK_SIZE: 1 * MB,                 // 1 MB
  MAX_CHUNK_SIZE: 8 * MB,                 // 8 MB
  CHUNKS_PER_WORKER: 4,                   // target ratio for stealing

  STALL_TIMEOUT_MS: 45000,
  WATCHDOG_INTERVAL_MS: 5000,
  FORCE_KILL_MS: 3000,
  MAX_CHUNK_ATTEMPTS: 2,                  // main-level requeues
  PROGRESS_THROTTLE_MS: 100,
  PROBE_TIMEOUT_MS: 20000,

  NO_PROGRESS_FAIL_MS: 5 * 60 * 1000,     // 5 min global no-progress -> fail
  RESUME_GRACE_MS: 10 * 1000,             // watchdog grace after system resume
  THROTTLE_GROWTH_INTERVAL_MS: 30 * 1000, // AIMD +1 concurrency after 30s no throttle
  MAX_WORKER_RESPAWNS: 5,
  FINALIZE_TIMEOUT_MS: 60 * 1000,

  STATE_VERSION: 3,
};