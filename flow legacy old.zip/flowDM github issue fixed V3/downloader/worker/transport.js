/* ================================================================
 *  Flow — transport dispatcher
 *
 *  HTTP/1.1 only. Validates that a 206 response's Content-Range matches
 *  the request, that Content-Encoding is identity, that Content-Length
 *  matches the requested length, and that a 200 response is only
 *  accepted when the chunk covers the whole file.
 *
 *  Every throw carries a typed err.code that chunk.js uses for
 *  classification: fatal-disk | fatal-link | file-changed | throttled
 *  | transient. For throttled errors, err.retryAfter carries the
 *  Retry-After header value in seconds when present.
 * ================================================================ */

const { openHttpsStream } = require("./h1");
const { state } = require("./state");

async function openStream(start, end) {
  return openHttpsStream(state.url, state.extraHeaders, start, end, state.ifRange);
}

function typedError(message, code, extra = {}) {
  const err = new Error(message);
  err.code = code;
  for (const k of Object.keys(extra)) {
    if (extra[k] !== undefined) err[k] = extra[k];
  }
  return err;
}

function validateResponse(resp, start, expectedBytes) {
  if (resp.status === 401 || resp.status === 403) {
    throw typedError(`HTTP ${resp.status} — link expired or auth required`, "fatal-link", { status: resp.status });
  }
  if (resp.status === 404) {
    throw typedError("HTTP 404 — file not found", "fatal-link", { status: 404 });
  }
  if (resp.status === 410) {
    throw typedError("HTTP 410 — file no longer available", "fatal-link", { status: 410 });
  }
  if (resp.status === 416) {
    throw typedError("HTTP 416 — range not satisfiable", "file-changed", { status: 416 });
  }
  if (resp.status === 429) {
    const retryAfter = resp.headers["retry-after"] ? Number(resp.headers["retry-after"]) : null;
    throw typedError("HTTP 429 — server is rate-limiting this link", "throttled", {
      status: 429,
      retryAfter: Number.isFinite(retryAfter) ? retryAfter : null,
    });
  }
  if (resp.status >= 500) {
    const retryAfter = resp.headers["retry-after"] ? Number(resp.headers["retry-after"]) : null;
    throw typedError(`HTTP ${resp.status} — server error`, resp.status === 503 ? "throttled" : "transient", {
      status: resp.status,
      retryAfter: Number.isFinite(retryAfter) ? retryAfter : null,
    });
  }
  if (resp.status !== 200 && resp.status !== 206) {
    throw typedError(`Unexpected HTTP ${resp.status}`, "transient", { status: resp.status });
  }

  // Reject 200 unless the chunk covers the whole file (start == 0 and
  // requested length == totalSize). A 200 on chunk 0 is NOT automatically
  // acceptable — the server may be ignoring Range.
  if (resp.status === 200) {
    if (start !== 0 || expectedBytes !== state.totalSize) {
      throw typedError("Server ignored Range (status 200)", "file-changed", { status: 200 });
    }
  }

  // For 206, Content-Range must match the request exactly.
  if (resp.status === 206) {
    const cr = String(resp.headers["content-range"] || "");
    const m = cr.match(/bytes\s+(\d+)-(\d+)\/(\d+)/i);
    if (!m) throw typedError("HTTP 206 without valid Content-Range", "transient", { status: 206 });
    const crStart = parseInt(m[1], 10);
    const crEnd = parseInt(m[2], 10);
    const crTotal = parseInt(m[3], 10);
    if (crStart !== start) {
      throw typedError(`Content-Range start ${crStart} != requested ${start}`, "file-changed", { status: 206 });
    }
    const expectedEnd = start + expectedBytes - 1;
    if (crEnd !== expectedEnd) {
      throw typedError(`Content-Range end ${crEnd} != requested ${expectedEnd}`, "file-changed", { status: 206 });
    }
    if (Number.isFinite(state.totalSize) && state.totalSize > 0 && crTotal !== state.totalSize) {
      throw typedError(`Content-Range total ${crTotal} != probed ${state.totalSize}`, "file-changed", { status: 206 });
    }
  }

  // Content-Encoding: we sent identity; anything else means the byte count
  // we write no longer matches the file on disk.
  const ce = String(resp.headers["content-encoding"] || "identity").toLowerCase();
  if (ce !== "identity") {
    throw typedError(`Unexpected Content-Encoding: ${ce}`, "transient");
  }

  // Content-Length (when present) must equal what we asked for. For 206,
  // Content-Range above already pins this — the check here catches a
  // misbehaving server that sends both and disagrees.
  const cl = resp.headers["content-length"];
  if (cl !== undefined) {
    const clNum = parseInt(cl, 10);
    if (Number.isFinite(clNum) && clNum !== expectedBytes) {
      throw typedError(`Content-Length ${clNum} != expected ${expectedBytes}`, "transient");
    }
  }

  // HTML guard: reject only if the probe saw a non-HTML content type.
  // Legitimate .html downloads must not be blocked.
  const ct = String(resp.headers["content-type"] || "").toLowerCase();
  const probeCt = String(state.probeContentType || "").toLowerCase();
  if (ct.includes("text/html") && !probeCt.includes("text/html") && expectedBytes > 100 * 1024) {
    throw typedError("Server returned HTML error page", "transient");
  }
}

module.exports = { openStream, validateResponse };