/* ================================================================
 *  Flow — HTTPS / HTTP (HTTP/1.1) transport
 *
 *  Caller-supplied headers are applied FIRST; engine-owned headers
 *  (range, accept-encoding, connection, host, user-agent) are applied
 *  afterwards so a caller cannot silently break range semantics.
 *  If-Range is added when a validator was captured at probe time.
 * ================================================================ */

const { https: followHttps, http: followHttp } = require("follow-redirects");

const { USER_AGENT } = require("./config");
const { httpsAgent, httpAgent } = require("./agents");

const CREDENTIAL_HEADERS = new Set(["cookie", "authorization", "proxy-authorization"]);
const ENGINE_OWNED = new Set(["range", "accept-encoding", "connection", "host", "user-agent"]);
const MAX_REDIRECTS = 10;

function openHttpsStream(url, headers, start, end, ifRange) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const isHttps = u.protocol === "https:";
    const mod = isHttps ? followHttps : followHttp;
    const originalOrigin = u.origin;

    // Caller headers first (lowercased), dropping anything engine owns.
    const reqHeaders = {};
    for (const k of Object.keys(headers || {})) {
      const lk = k.toLowerCase();
      if (!ENGINE_OWNED.has(lk)) reqHeaders[lk] = headers[k];
    }
    // Engine-owned headers forced last.
    reqHeaders["range"] = `bytes=${start}-${end}`;
    reqHeaders["accept-encoding"] = "identity";
    reqHeaders["user-agent"] = USER_AGENT;
    reqHeaders["connection"] = "keep-alive";
    if (ifRange) reqHeaders["if-range"] = ifRange;

    const req = mod.request({
      method: "GET",
      hostname: u.hostname,
      port: u.port || (isHttps ? 443 : 80),
      path: u.pathname + u.search,
      headers: reqHeaders,
      agent: isHttps ? httpsAgent : httpAgent,

      maxRedirects: MAX_REDIRECTS,
      beforeRedirect: (options, _responseDetails) => {
        const newOrigin =
          `${options.protocol}//${options.hostname}` +
          (options.port ? `:${options.port}` : "");
        if (newOrigin === originalOrigin) return;
        if (!options.headers) return;
        for (const h of Object.keys(options.headers)) {
          if (CREDENTIAL_HEADERS.has(h.toLowerCase())) {
            delete options.headers[h];
          }
        }
      },
    }, (res) => {
      resolve({
        status: res.statusCode,
        headers: res.headers,
        stream: res,
      });
    });

    req.once("error", reject);

    req.setTimeout(30000, () => {
      try { req.destroy(new Error("Transport timeout")); } catch {}
    });

    req.end();
  });
}

module.exports = { openHttpsStream };