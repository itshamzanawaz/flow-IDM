/* ================================================================
 *  Flow — single range download
 *
 *  Streams one byte-range from the server directly into the temp file
 *  at the right offset, capping writes to the requested length and
 *  reporting incremental progress as an ABSOLUTE FILE OFFSET high-water
 *  mark (not a delta). On failure, the throw carries .bytesWritten so
 *  the caller can advance without double-counting.
 * ================================================================ */

const fs = require("fs");
const { pipeline } = require("stream/promises");
const { Transform } = require("stream");

const { PROGRESS_INTERVAL_MS, WRITE_BUFFER_BYTES } = require("./config");
const { state, post } = require("./state");
const { openStream, validateResponse } = require("./transport");

async function downloadRange(start, end, chunkId) {
  const remaining = end - start + 1;
  if (remaining <= 0) return 0;

  const resp = await openStream(start, end);
  try {
    validateResponse(resp, start, remaining);
  } catch (err) {
    try { resp.stream.destroy(); } catch {}
    throw err;
  }

  // Byte-limiting transform: refuse to write more than `remaining` bytes
  let passed = 0;
  const limiter = new Transform({
    transform(chunk, _enc, cb) {
      const space = remaining - passed;
      if (space <= 0) return cb();
      if (chunk.length <= space) {
        passed += chunk.length;
        return cb(null, chunk);
      }
      passed += space;
      cb(null, chunk.slice(0, space));
    },
  });

  const ws = fs.createWriteStream(state.tempFilePath, {
    flags: "r+",
    start,
    highWaterMark: WRITE_BUFFER_BYTES,
  });

  state.currentWriteStream = ws;

  // Report ABSOLUTE file offset high-water. Main uses max(), so double
  // posting the same offset is harmless; delta double-counting is not.
  let lastReported = -1;
  const report = () => {
    const hw = start + ws.bytesWritten;
    if (hw > lastReported) {
      lastReported = hw;
      post({ type: "progress", chunkId, fileOffset: hw });
    }
  };

  const progressTimer = setInterval(report, PROGRESS_INTERVAL_MS);

  try {
    await pipeline(resp.stream, limiter, ws);
    report();
    return ws.bytesWritten;
  } catch (err) {
    report();
    // Attach partial-write count so chunk.js can advance `downloaded`
    // without re-fetching bytes that are already on disk.
    err.bytesWritten = ws.bytesWritten;
    throw err;
  } finally {
    clearInterval(progressTimer);
    state.currentWriteStream = null;
  }
}

module.exports = { downloadRange };