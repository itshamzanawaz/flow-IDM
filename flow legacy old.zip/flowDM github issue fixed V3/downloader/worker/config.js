/* ================================================================
 *  Flow — worker constants
 * ================================================================ */

module.exports = {
  USER_AGENT:
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",

  H2_CONNECT_TIMEOUT_MS: 6000,
  PROGRESS_INTERVAL_MS: 250,
  WRITE_BUFFER_BYTES: 1024 * 1024,   // 1 MB
  RETRY_BASE_MS: 500,
};