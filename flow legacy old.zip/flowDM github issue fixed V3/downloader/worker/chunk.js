/* ================================================================
 *  Flow — chunk download with in-worker retries
 *
 *  Retries the *remaining* portion of a chunk on partial failure.
 *  `downloaded` advances by the partial byte count reported by
 *  range.js even when the attempt throws, so retries never re-fetch
 *  bytes already on disk, and main's high-water accounting stays
 *  monotone.
 *
 *  Freeze-fix (v3.1): throttled errors are bounded by
 *  MAX_THROTTLE_RETRIES so a permanently 429/503-throttled server
 *  fails loudly instead of hanging inside the retry loop until the
 *  task-level NO_PROGRESS_FAIL_MS watchdog fires.
 * ================================================================ */

const { RETRY_BASE_MS } = require("./config");
const { state, log, sleep } = require("./state");
const { downloadRange } = require("./range");

const MAX_THROTTLE_RETRIES = 20;

function classifyError(err) {
  const code = err && err.code;
  const status = err && err.status;
  const msg = String((err && err.message) || "");

  if (code === "ENOSPC" || code === "EACCES" || code === "ENOENT" || code === "EBADF") {
    return "fatal-disk";
  }
  if (status === 404 || status === 410) return "fatal-link";
  if (/HTTP 404|HTTP 410|link expired|auth required|HTML error page/i.test(msg)) return "fatal-link";
  if (status === 429 || status === 503) return "throttled";
  if (/HTTP 429|HTTP 503/.test(msg)) return "throttled";
  if (status === 416) return "file-changed";
  if (/Content-Range|HTTP 416|If-Range|ignored Range/i.test(msg)) return "file-changed";
  return "transient";
}

function retryDelayMs(err, attempt) {
  const ra = err && Number(err.retryAfter);
  if (Number.isFinite(ra) && ra > 0) return Math.min(ra * 1000, 60000);
  const exp = Math.min(RETRY_BASE_MS * Math.pow(2, attempt - 1), 30000);
  return exp + Math.random() * RETRY_BASE_MS;
}

async function downloadChunk(chunk) {
  const { id: chunkId, start, end } = chunk;
  const totalBytes = end - start + 1;
  let downloaded = chunk.downloaded || 0;

  let lastErr = null;
  let throttleRetries = 0;

  for (let attempt = 1; attempt <= state.maxAttempts; attempt++) {
    if (state.isShuttingDown) throw new Error("aborted");

    const offset = start + downloaded;
    const remaining = end - offset + 1;
    if (remaining <= 0) return;

    let written = 0;
    try {
      written = await downloadRange(offset, end, chunkId);
    } catch (err) {
      if (state.isShuttingDown || err.message === "aborted") {
        throw new Error("aborted");
      }
      const partial = err.bytesWritten || 0;
      if (partial > 0) {
        downloaded += partial;
        if (downloaded >= totalBytes) return;
      }
      err.code = err.code || classifyError(err);
      lastErr = err;
      log(`chunk ${chunkId} attempt ${attempt} failed (+${partial}B) [${err.code}]: ${err.message}`);

      if (err.code === "fatal-disk" || err.code === "fatal-link" || err.code === "file-changed") {
        throw err;
      }
      if (err.code === "throttled") {
        // Throttled errors do not consume the per-chunk attempt budget,
        // but they must terminate: bound throttle retries so a permanent
        // 429/503 fails loudly instead of hanging the worker.
        throttleRetries++;
        if (throttleRetries > MAX_THROTTLE_RETRIES) throw err;
        await sleep(retryDelayMs(err, throttleRetries));
        attempt--;
        continue;
      }
      if (attempt < state.maxAttempts) await sleep(retryDelayMs(err, attempt));
      continue;
    }

    downloaded += written;
    if (downloaded >= totalBytes) return;

    log(`chunk ${chunkId} attempt ${attempt}: got ${downloaded}/${totalBytes}, retrying`);
    if (attempt < state.maxAttempts) await sleep(retryDelayMs(null, attempt));
  }

  throw lastErr || new Error(
    `Chunk ${chunkId} failed after ${state.maxAttempts} attempts`
  );
}

module.exports = { downloadChunk, classifyError };