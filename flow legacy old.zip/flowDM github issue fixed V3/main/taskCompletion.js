/* ================================================================
 *  Flow — task completion + lingering-task cleanup
 *
 *  handleTaskCompletion: translates the engine's result object into
 *    a DB status + IPC event, honouring opts.restoreOnError so that
 *    a failed resume can be silently restored to "Paused" instead of
 *    being flagged as an Error.
 *
 *  clearLingeringTask: before resume/refresh we cancel any task the
 *    engine still has registered under this id, otherwise startTask
 *    would reject with "download with this id already exists".
 *    A 5 s timeout guard prevents a wedged engine from freezing the
 *    resume IPC handler.
 * ================================================================ */

const { cancelTask } = require("../downloader/downloadManager");
const { getDB } = require("./database");

async function clearLingeringTask(id) {
  try {
    const res = await Promise.race([
      cancelTask(id),
      new Promise((r) =>
        setTimeout(() => r({ success: false, error: "timeout" }), 5000)
      ),
    ]);
    if (res && res.success === false && res.error !== "timeout") {
      console.log(`[main] cancelTask(${id}) note:`, res.error);
    }
  } catch (err) {
    // No registered task — perfectly normal for a fresh start.
    console.log(`[main] cancelTask(${id}) skipped:`, err.message);
  }
  // Small grace period so the manager can drop internal bookkeeping.
  await new Promise((r) => setTimeout(r, 80));
}

async function handleTaskCompletion(id, taskPromise, sender, opts = {}) {
  const out =
    sender && typeof sender.send === "function" ? sender : { send: () => {} };
  const errorStatus = opts.restoreOnError || "Error";
  const db = getDB();

  try {
    const result = await taskPromise;
    if (!result) return;

    if (result.success) {
      db.prepare(`UPDATE history SET status = 'Completed' WHERE id = ?`).run(id);
      out.send("status-change");
    } else if (result.paused) {
      out.send("status-change");
    } else if (result.cancelled) {
      out.send("status-change");
    } else if (result.error) {
      db.prepare(`UPDATE history SET status = ? WHERE id = ?`).run(errorStatus, id);
      if (errorStatus !== "Paused") {
        out.send("download-error", { id, message: result.error });
      } else {
        out.send("download-error", { id, message: result.error, silent: true });
      }
      out.send("status-change");
    }
  } catch (err) {
    db.prepare(`UPDATE history SET status = ? WHERE id = ?`).run(errorStatus, id);
    const message = err.message || String(err);
    if (errorStatus !== "Paused") {
      out.send("download-error", { id, message });
    } else {
      out.send("download-error", { id, message, silent: true });
    }
    out.send("status-change");
  }
}

module.exports = { clearLingeringTask, handleTaskCompletion };