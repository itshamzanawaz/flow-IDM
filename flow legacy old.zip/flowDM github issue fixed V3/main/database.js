/* ================================================================
 *  Flow — SQLite history store
 *
 *  initDB() runs once at app startup. Startup reconciliation
 *  downgrades stale "Downloading"/"Preparing" rows to "Paused" so
 *  the UI keeps a Resume button after a crash or force-quit.
 * ================================================================ */

const path = require("path");
const Database = require("better-sqlite3");
const { app } = require("electron");

let db = null;

function initDB() {
  const dbPath = path.join(app.getPath("userData"), "downloads.db");
  db = new Database(dbPath);

  db.exec(`
    CREATE TABLE IF NOT EXISTS history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      filename TEXT,
      directory TEXT,
      url TEXT,
      totalSize INTEGER,
      status TEXT,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  try { db.exec(`ALTER TABLE history ADD COLUMN url TEXT;`); } catch (e) {}
  try { db.exec(`ALTER TABLE history ADD COLUMN totalSize INTEGER;`); } catch (e) {}

  try {
    const res = db
      .prepare(
        `UPDATE history SET status = 'Paused'
         WHERE LOWER(status) IN ('downloading','preparing')`
      )
      .run();
    if (res.changes > 0) {
      console.log(`[flow] Reconciled ${res.changes} interrupted download(s) to Paused`);
    }
  } catch (err) {
    console.warn("[flow] startup reconciliation failed:", err.message);
  }
}

function getDB() {
  if (!db) throw new Error("Database not initialized");
  return db;
}

module.exports = { initDB, getDB };