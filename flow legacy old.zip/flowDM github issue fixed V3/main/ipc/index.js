/* ================================================================
 *  Flow — register all IPC handlers in one place
 * ================================================================ */

const { registerClipboardHandlers }   = require("./clipboard");
const { registerDirectoryHandlers }   = require("./directories");
const { registerFileHandlers }        = require("./files");
const { registerHistoryHandlers }     = require("./history");
const { registerDownloadHandlers }    = require("./downloads");

function registerAllIpcHandlers() {
  registerClipboardHandlers();
  registerDirectoryHandlers();
  registerFileHandlers();
  registerHistoryHandlers();
  registerDownloadHandlers();
}

module.exports = { registerAllIpcHandlers };