/* ================================================================
 *  Flow — download lifecycle IPC handlers
 *
 *  Freeze fixes:
 *    • new-download / refresh-link: prepareDownload is wrapped in
 *      PREPARE_TIMEOUT_MS so the renderer's "Preparing…" spinner
 *      cannot hang indefinitely on a slow or stalling server.
 *    • new-download / refresh-link: the probe result is passed to
 *      startTask as `validators` so workers can send If-Range and
 *      correctly bypass the HTML guard on legitimate HTML downloads.
 *    • resume-download: the clearLingeringTask wait is time-boxed; if
 *      the previous task cannot be cancelled cleanly, the new start
 *      still goes ahead so the user is not left staring at a Paused
 *      row that never resumes.
 * ================================================================ */

const { ipcMain, app } = require("electron");

const { getDB } = require("../database");
const { isYouTubeUrl } = require("../media");
const {
  prepareYoutubeDownload,
  startYoutubeTask,
  pauseYoutubeTask,
} = require("../youtube");
const {
  prepareDownload,
  startTask,
  pauseTask,
  cancelTask,
  removePartialFiles,
} = require("../../downloader/downloadManager");
const {
  clearLingeringTask,
  handleTaskCompletion,
} = require("../taskCompletion");

/* Hard upper bound on how long the renderer waits for "Preparing…".
 * The probe itself has a 20 s per-request timeout, but a redirect
 * chain can multiply that; this caps the whole phase. */
const PREPARE_TIMEOUT_MS = 60000;

/* Upper bound on how long resume-download blocks on cleaning up a
 * previous task. clearLingeringTask already caps itself at ~5 s; we
 * add a second guard so a wedged IPC handler cannot stall forever. */
const RESUME_CLEANUP_TIMEOUT_MS = 6000;

function withTimeout(promise, ms, label) {
  return Promise.race([
    promise,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`${label} timed out after ${ms / 1000}s`)), ms)
    ),
  ]);
}

function validatorsFromProbe(fileInfo) {
  return {
    etag: fileInfo.etag || null,
    lastModified: fileInfo.lastModified || null,
    validator: fileInfo.validator || null,
    contentType: fileInfo.contentType || null,
    finalUrl: fileInfo.finalUrl || null,
  };
}

function registerDownloadHandlers() {
  /* ---------------- new-download ---------------- */
  ipcMain.handle("new-download", async (event, { url, saveDirectory }) => {
    try {
      if (!url || typeof url !== "string") {
        return { error: "Missing or invalid URL." };
      }

      const dir = saveDirectory || app.getPath("downloads");
      const isYt = isYouTubeUrl(url);

      const fileInfo = isYt
        ? await prepareYoutubeDownload(url, dir)
        : await withTimeout(
            prepareDownload(url, dir),
            PREPARE_TIMEOUT_MS,
            "Preparing download"
          );

      const stmt = getDB().prepare(
        `INSERT INTO history (filename, directory, url, totalSize, status)
         VALUES (?, ?, ?, ?, ?)`
      );
      const info = stmt.run(
        fileInfo.fileName,
        fileInfo.filePath,
        url,
        fileInfo.totalSize || 0,
        "Downloading"
      );
      const dbId = info.lastInsertRowid;

      event.sender.send("download-start", { id: dbId, ...fileInfo });
      event.sender.send("status-change");

      if (isYt) {
        handleTaskCompletion(
          dbId,
          startYoutubeTask(dbId, url, fileInfo.filePath, event.sender),
          event.sender
        );
      } else {
        handleTaskCompletion(
          dbId,
          startTask(
            dbId,
            url,
            fileInfo.filePath,
            fileInfo.totalSize,
            event.sender,
            {},
            validatorsFromProbe(fileInfo)
          ),
          event.sender
        );
      }

      return { id: dbId };
    } catch (err) {
      return { error: err.message || String(err) };
    }
  });

  /* ---------------- pause-download ---------------- */
  ipcMain.handle("pause-download", async (event, id) => {
    const db = getDB();
    const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
    if (!item) return { success: false, error: "Item not found" };

    const st = String(item.status || "").toLowerCase();
    if (st === "paused") return { success: true, alreadyPaused: true };
    if (st === "completed") return { success: false, error: "Download already completed" };
    if (st === "cancelled") return { success: false, error: "Download was cancelled" };

    db.prepare(`UPDATE history SET status = 'Paused' WHERE id = ?`).run(id);

    if (isYouTubeUrl(item.url)) {
      try { pauseYoutubeTask(id); } catch (err) {
        console.warn("[main] pauseYoutubeTask:", err.message);
      }
    } else {
      Promise.resolve()
        .then(() => pauseTask(id))
        .then((res) => {
          if (res && res.success === false) {
            console.warn("[main] pauseTask:", res.error);
          }
        })
        .catch((err) => console.warn("[main] pauseTask failed:", err.message));
    }

    event.sender.send("status-change");
    return { success: true };
  });

  /* ---------------- resume-download ---------------- */
  ipcMain.handle("resume-download", async (event, id) => {
    const db = getDB();
    const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
    if (!item) return { success: false, error: "Item not found" };

    const st = String(item.status || "").toLowerCase();
    if (st === "downloading" || st === "preparing") {
      return { success: false, error: "Already downloading" };
    }
    if (st === "completed") {
      return { success: false, error: "Download already completed" };
    }

    // Time-boxed. If the previous task cannot be cleaned up cleanly we
    // still try to start the new one — a stale registry entry will
    // surface as startTask's rejection, which we convert to a friendly
    // error rather than a silent stall.
    try {
      await withTimeout(clearLingeringTask(id), RESUME_CLEANUP_TIMEOUT_MS, "Resume cleanup");
    } catch (err) {
      console.warn("[main] clearLingeringTask time-boxed out:", err.message);
    }

    db.prepare(`UPDATE history SET status = 'Downloading' WHERE id = ?`).run(id);
    event.sender.send("status-change");

    let taskPromise;
    try {
      if (isYouTubeUrl(item.url)) {
        taskPromise = startYoutubeTask(id, item.url, item.directory, event.sender);
      } else {
        taskPromise = startTask(
          id,
          item.url,
          item.directory,
          item.totalSize,
          event.sender
        );
      }
    } catch (err) {
      db.prepare(`UPDATE history SET status = 'Paused' WHERE id = ?`).run(id);
      event.sender.send("status-change");
      return { success: false, error: err.message || String(err) };
    }

    handleTaskCompletion(id, taskPromise, event.sender, { restoreOnError: "Paused" });

    return { success: true };
  });

  /* ---------------- cancel-download ---------------- */
  ipcMain.handle("cancel-download", async (event, id, deletePartial = true) => {
    const db = getDB();
    const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
    if (!item) return { success: false, error: "Item not found" };

    const st = String(item.status || "").toLowerCase();
    if (st === "completed") {
      return { success: false, error: "Download already completed" };
    }

    db.prepare(`UPDATE history SET status = 'Cancelled' WHERE id = ?`).run(id);

    if (isYouTubeUrl(item.url)) {
      try { pauseYoutubeTask(id); } catch {}
    } else {
      Promise.resolve()
        .then(() => cancelTask(id))
        .then((res) => {
          if (res && res.success === false) {
            console.warn("[main] cancelTask:", res.error);
          }
        })
        .catch((err) => console.warn("[main] cancelTask failed:", err.message));
    }

    if (deletePartial) {
      setTimeout(() => {
        try { removePartialFiles(item.directory); } catch {}
      }, 300);
    }

    event.sender.send("status-change");
    return { success: true };
  });

  /* ---------------- refresh-link ---------------- */
  ipcMain.handle("refresh-link", async (event, id, newUrl) => {
    if (!newUrl || typeof newUrl !== "string") {
      return { success: false, error: "Invalid URL" };
    }

    try {
      await withTimeout(clearLingeringTask(id), RESUME_CLEANUP_TIMEOUT_MS, "Refresh cleanup");
    } catch (err) {
      console.warn("[main] clearLingeringTask time-boxed out:", err.message);
    }

    const db = getDB();
    db.prepare(`UPDATE history SET url = ? WHERE id = ?`).run(newUrl, id);
    const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
    if (!item) return { success: false, error: "Item not found" };

    let fileInfo;
    try {
      fileInfo = await withTimeout(
        prepareDownload(newUrl, require("path").dirname(item.directory)),
        PREPARE_TIMEOUT_MS,
        "Refreshing link"
      );
    } catch (err) {
      return { success: false, error: err.message || String(err) };
    }

    db.prepare(`UPDATE history SET status = 'Downloading' WHERE id = ?`).run(id);
    event.sender.send("status-change");

    let taskPromise;
    try {
      if (isYouTubeUrl(item.url)) {
        taskPromise = startYoutubeTask(id, item.url, item.directory, event.sender);
      } else {
        taskPromise = startTask(
          id,
          item.url,
          fileInfo.filePath,
          fileInfo.totalSize,
          event.sender,
          {},
          validatorsFromProbe(fileInfo)
        );
      }
    } catch (err) {
      db.prepare(`UPDATE history SET status = 'Paused' WHERE id = ?`).run(id);
      event.sender.send("status-change");
      return { success: false, error: err.message || String(err) };
    }

    handleTaskCompletion(id, taskPromise, event.sender, { restoreOnError: "Paused" });
    return { success: true };
  });
}

module.exports = { registerDownloadHandlers };