/* ================================================================
 *  Flow — Electron main process entry point
 *
 *  Freeze fix:
 *    • before-quit is time-boxed. pauseAll() is best-effort; if a
 *      worker will not terminate, we still exit after 3 s so clicking
 *      the window close button always works.
 * ================================================================ */

const { app, BrowserWindow } = require("electron");

const { initDB } = require("./database");
const { createWindow } = require("./window");
const { registerAllIpcHandlers } = require("./ipc");
const { startHttpBridge } = require("./bridge");
const { pauseAll } = require("../downloader/downloadManager");

const SHUTDOWN_GRACE_MS = 3000;

let isQuitting = false;

app.whenReady().then(() => {
  initDB();
  registerAllIpcHandlers();
  startHttpBridge();
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("before-quit", async (e) => {
  if (isQuitting) return;
  isQuitting = true;
  e.preventDefault();
  try {
    await Promise.race([
      pauseAll(),
      new Promise((r) => setTimeout(r, SHUTDOWN_GRACE_MS)),
    ]);
  } catch (err) {
    console.error("[shutdown] pauseAll failed:", err.message);
  }
  app.exit(0);
});