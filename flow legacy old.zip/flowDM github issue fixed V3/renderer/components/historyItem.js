/* ================================================================
 *  Flow — History row rendering
 * ================================================================ */

import { SVG } from "../icons.js";
import { escapeHtml, normalizeStatus } from "../utils.js";
import { formatBytes, formatDate } from "../formatters.js";
import { statusBadge, fileIconHtml, emptyState } from "./badges.js";
import { state } from "../state.js";

const ICON_BTN = (action, id, title, svg, danger = false) =>
  `<button class="btn-icon${danger ? " danger" : ""}" data-action="${action}" data-id="${id}" title="${title}" aria-label="${title}">${svg}</button>`;

export function historyActions(item) {
  const id = item.id;
  const st = normalizeStatus(item.status);

  if (st === "downloading") {
    return ICON_BTN("pause",  id, "Pause", SVG.pause)
         + ICON_BTN("cancel", id, "Cancel", SVG.x, true)
         + ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
  }
  if (st === "paused") {
    return ICON_BTN("resume", id, "Resume", SVG.play)
         + ICON_BTN("cancel", id, "Cancel", SVG.x, true)
         + ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
  }
  if (st === "completed") {
    return ICON_BTN("open",   id, "Open file", SVG.external)
         + ICON_BTN("folder", id, "Show in folder", SVG.folder)
         + ICON_BTN("copy",   id, "Copy URL", SVG.copy)
         + ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
  }
  if (st === "error" || st === "cancelled") {
    return ICON_BTN("retry",  id, "Retry", SVG.retry)
         + ICON_BTN("copy",   id, "Copy URL", SVG.copy)
         + ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
  }
  return ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
}

export function historyItemHtml(item, { selectable = false } = {}) {
  const st = normalizeStatus(item.status);
  const isLive = item.isLive && st === "downloading";
  const percent = isLive ? Math.max(0, Math.min(100, item.percent || 0)) : 0;

  const check = selectable
    ? `<label class="check-wrap"><input type="checkbox" class="row-check" data-id="${item.id}" ${
        state.selected.has(Number(item.id)) ? "checked" : ""
      }><span class="check-box"></span></label>`
    : "";

  const metaParts = [];
  if (isLive) {
    metaParts.push(
      `<span class="hi-progress" data-live-progress="${item.id}">${Math.round(percent)}% · ${item.speedMBps || 0} MB/s</span>`
    );
  }
  metaParts.push(escapeHtml(formatBytes(item.totalSize)));
  metaParts.push(escapeHtml(formatDate(item.timestamp)));
  const meta = metaParts.join(`<span class="dot"></span>`);

  const selectedCls = state.selected.has(Number(item.id)) ? " selected" : "";

  return `
    <div class="history-item${selectedCls}" data-id="${item.id}">
      ${check}
      ${fileIconHtml(item.filename)}
      <div class="hi-info" data-action="details" data-id="${item.id}">
        <div class="hi-name" title="${escapeHtml(item.filename)}">${escapeHtml(item.filename)}</div>
        <div class="hi-meta">${meta}</div>
      </div>
      <div class="hi-status">${statusBadge(item.status)}</div>
      <div class="hi-actions">${historyActions(item)}</div>
    </div>
  `;
}

export function historySignature(list, opts = {}) {
  const sel = opts.selectable
    ? Array.from(state.selected).sort((a, b) => a - b).join(",")
    : "";
  const rows = list
    .map((x) => `${x.id}:${normalizeStatus(x.status)}:${x.isLive ? "L" : "-"}`)
    .join("|");
  return `${rows}#${sel}`;
}

export function renderHistory(container, list, emptyTitle = "Nothing here yet", emptyDesc = "Your downloads will appear here.", opts = {}) {
  if (!container) return;
  const sig = historySignature(list, opts);
  if (container.dataset.sig === sig) return;   // no churn → no flicker
  container.dataset.sig = sig;

  if (!list.length) {
    container.innerHTML = emptyState(emptyTitle, emptyDesc);
    return;
  }
  container.innerHTML = list.map((item) => historyItemHtml(item, opts)).join("");
}