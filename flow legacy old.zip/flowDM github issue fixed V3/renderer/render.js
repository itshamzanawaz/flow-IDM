/* ================================================================
 *  Flow — top-level render pipeline
 *
 *  Progress ticks do NOT call render() — they only touch active
 *  cards + live progress spans, so history lists never rebuild.
 * ================================================================ */

import { state } from "./state.js";
import { getMergedList, getActiveList } from "./data.js";
import { renderActive } from "./components/activeCard.js";
import { renderHistory } from "./components/historyItem.js";
import { normalizeStatus } from "./utils.js";

/* ---------------- Surgical live progress ---------------- */
export function updateLiveHistoryProgress() {
  if (state.active.size === 0) return;
  for (const [id, entry] of state.active.entries()) {
    const els = document.querySelectorAll(`[data-live-progress="${id}"]`);
    if (!els.length) continue;
    const percent = Math.max(0, Math.min(100, entry.percent || 0));
    const text = `${Math.round(percent)}% · ${entry.speedMBps || 0} MB/s`;
    els.forEach((el) => {
      if (el.textContent !== text) el.textContent = text;
    });
  }
}

/* ---------------- All Downloads: filter / search / sort ---------------- */
export function applyAllControls(list) {
  let out = list.slice();

  if (state.allFilter !== "all") {
    out = out.filter((item) => normalizeStatus(item.status) === state.allFilter);
  }

  const q = state.allSearch.trim().toLowerCase();
  if (q) {
    out = out.filter((item) =>
      String(item.filename || "").toLowerCase().includes(q) ||
      String(item.url || "").toLowerCase().includes(q) ||
      String(item.status || "").toLowerCase().includes(q)
    );
  }

  const cmp = {
    newest:     (a, b) => new Date(b.timestamp || 0) - new Date(a.timestamp || 0),
    oldest:     (a, b) => new Date(a.timestamp || 0) - new Date(b.timestamp || 0),
    "name-asc": (a, b) => String(a.filename || "").localeCompare(String(b.filename || "")),
    "name-desc":(a, b) => String(b.filename || "").localeCompare(String(a.filename || "")),
    "size-desc":(a, b) => (Number(b.totalSize) || 0) - (Number(a.totalSize) || 0),
    "size-asc": (a, b) => (Number(a.totalSize) || 0) - (Number(b.totalSize) || 0),
    status:     (a, b) => normalizeStatus(a.status).localeCompare(normalizeStatus(b.status)),
  }[state.allSort];
  if (cmp) out.sort(cmp);

  return out;
}

export function updateFilterCounts(list) {
  const counts = { all: 0, downloading: 0, paused: 0, completed: 0, error: 0, cancelled: 0 };
  for (const item of list) {
    counts.all++;
    const s = normalizeStatus(item.status);
    if (counts[s] != null) counts[s]++;
  }
  document.querySelectorAll(".filter-tab .count").forEach((el) => {
    const key = el.dataset.count;
    if (key && counts[key] != null) el.textContent = String(counts[key]);
  });
}

export function updateBulkBar() {
  const bar = document.querySelector("#bulk-bar");
  const count = state.selected.size;
  if (bar) bar.hidden = count === 0;
  const label = document.querySelector("#bulk-count");
  if (label) label.textContent = count === 1 ? "1 selected" : `${count} selected`;
}

export function renderAll() {
  const merged = getMergedList();
  updateFilterCounts(merged);
  const list = applyAllControls(merged);
  const opts = { selectable: state.selectMode };
  renderHistory(
    document.querySelector("#all-list"),
    list,
    state.allSearch ? "No matches" : "No downloads yet",
    state.allSearch
      ? "Try a different search term or clear the filter."
      : "Downloads you start will appear here.",
    opts
  );
  updateBulkBar();
}

/* ---------------- Active containers ---------------- */
export function renderActiveContainers() {
  const list = getActiveList();
  renderActive(document.querySelector("#active-list"), list);
  renderActive(document.querySelector("#active-view-list"), list);
  updateGlobalStatus();
}

/* ---------------- Top-level render ---------------- */
export function render() {
  const view = state.view;
  const merged = getMergedList();

  if (view === "dashboard") {
    renderActiveContainers();
    renderHistory(document.querySelector("#recent-list"), merged.slice(0, 5),
      "No downloads yet", "Your recent downloads will appear here.");
  }
  if (view === "all") {
    renderAll();
  }
  if (view === "active") {
    renderActiveContainers();
  }
  if (view === "recent") {
    renderHistory(document.querySelector("#recent-view-list"), merged.slice(0, 25),
      "No downloads yet", "Your recent downloads will appear here.");
  }
  if (view === "completed") {
    const completed = merged.filter((x) => normalizeStatus(x.status) === "completed");
    renderHistory(document.querySelector("#completed-list"), completed,
      "No completed downloads", "Finished downloads will appear here.");
  }

  updateGlobalStatus();
  updateDirectoryLabels();
  updateNavBadges(merged);
}

/* ---------------- Chrome ---------------- */
export function updateNavBadges(merged) {
  const activeCount = state.active.size;
  const activeBadge = document.querySelector("#active-badge");
  if (activeBadge) {
    activeBadge.hidden = activeCount === 0;
    activeBadge.textContent = String(activeCount);
  }

  const allBadge = document.querySelector("#all-badge");
  if (allBadge) {
    allBadge.hidden = merged.length === 0;
    allBadge.textContent = String(merged.length);
  }

  const completedCount = merged.filter((x) => normalizeStatus(x.status) === "completed").length;
  const completedBadge = document.querySelector("#completed-badge");
  if (completedBadge) {
    completedBadge.hidden = completedCount === 0;
    completedBadge.textContent = String(completedCount);
  }

  const completedCountEl = document.querySelector("#settings-completed-count");
  if (completedCountEl) completedCountEl.textContent = String(completedCount);
}

export function updateGlobalStatus() {
  const hint = document.querySelector("#active-count-hint");
  const n = state.active.size;
  if (hint) hint.textContent = n === 1 ? "1 active" : `${n} active`;

  const pill = document.querySelector("#global-status");
  const pillText = document.querySelector("#global-status-text");
  if (pill && pillText) {
    if (n > 0) {
      pill.classList.add("busy");
      pillText.textContent = n === 1 ? "Downloading" : `${n} downloading`;
    } else {
      pill.classList.remove("busy");
      pillText.textContent = "Ready";
    }
  }
}

export function updateDirectoryLabels() {
  const label = state.directory || "Default Downloads";
  const saveDir = document.querySelector("#save-dir-display");
  const settingsDir = document.querySelector("#settings-dir");
  const sidebarEl = document.querySelector("#sidebar-dir");
  if (saveDir) saveDir.textContent = label;
  if (settingsDir) settingsDir.textContent = label;
  if (sidebarEl) {
    sidebarEl.textContent = label;
    sidebarEl.title = state.directory || "";
  }
}