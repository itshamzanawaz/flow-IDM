const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("api", {
  // Clipboard & directories
  readClipboard: () => ipcRenderer.invoke("read-clipboard"),
  selectDirectory: () => ipcRenderer.invoke("select-directory"),
  getDefaultDirectory: () => ipcRenderer.invoke("get-default-directory"),

  // Downloads
  newDownload: (payload) => ipcRenderer.invoke("new-download", payload),
  pauseDownload: (id) => ipcRenderer.invoke("pause-download", id),
  resumeDownload: (id) => ipcRenderer.invoke("resume-download", id),
  cancelDownload: (id, deletePartial = true) =>
    ipcRenderer.invoke("cancel-download", id, deletePartial),
  refreshLink: (id, newUrl) => ipcRenderer.invoke("refresh-link", id, newUrl),

  // History
  getHistory: () => ipcRenderer.invoke("get-history"),
  deleteDownload: (id, deleteFile) =>
    ipcRenderer.invoke("delete-download", id, deleteFile),
  clearCompleted: () => ipcRenderer.invoke("clear-completed"),

  // File actions
  openFolder: (filePath) => ipcRenderer.send("open-folder", filePath),
  openFile: (filePath) => ipcRenderer.invoke("open-file", filePath),

  // Events
  onDownloadStart: (cb) => ipcRenderer.on("download-start", (_e, data) => cb(data)),
  onDownloadProgress: (cb) => ipcRenderer.on("download-progress", (_e, data) => cb(data)),
  onDownloadError: (cb) => ipcRenderer.on("download-error", (_e, data) => cb(data)),
  onStatusChange: (cb) => ipcRenderer.on("status-change", () => cb()),
});