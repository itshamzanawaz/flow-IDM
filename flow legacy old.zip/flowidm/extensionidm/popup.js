const $container = document.getElementById("queue-container");
const $status = document.getElementById("status");
const $clearAll = document.getElementById("clear-all");

let currentQueue = [];

async function loadQueue() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "get-queue" }, (res) => {
      currentQueue = res.queue || [];
      renderQueue();
      resolve();
    });
  });
}

function renderQueue() {
  if (currentQueue.length === 0) {
    $container.innerHTML = '<div class="empty">No captured HLS streams.</div>';
    $clearAll.style.display = "none";
    return;
  }

  $clearAll.style.display = "block";
  $container.innerHTML = "";

  currentQueue.forEach(item => {
    const el = document.createElement("div");
    el.className = "item";
    
    const name = item.displayName || "Unknown File";
    let typeStr = "HLS Stream";
    if (item.audioUrl) typeStr = "Video + Audio";
    
    el.innerHTML = `
      <div class="item-name">${escapeHtml(name)}</div>
      <div class="item-url">${escapeHtml(item.url)}</div>
      <button class="btn" data-id="${item.captureId}">Download with Flow (${typeStr})</button>
    `;
    
    const btn = el.querySelector("button");
    btn.addEventListener("click", () => handleDownload(item.captureId, btn));
    
    $container.appendChild(el);
  });
}

async function handleDownload(id, btn) {
  const originalText = btn.textContent;
  btn.disabled = true;
  btn.textContent = "Sending to Flow...";
  $status.textContent = "";

  chrome.runtime.sendMessage({ type: "download-item", id }, async (res) => {
    if (res && res.success) {
      await loadQueue();
      $status.textContent = "Sent!";
      setTimeout(() => $status.textContent = "Ready", 2000);
    } else {
      btn.disabled = false;
      btn.textContent = originalText;
      $status.textContent = "Error";
      
      const err = document.createElement("div");
      err.className = "btn btn-error";
      err.textContent = res.error || "Failed to send";
      btn.parentElement.appendChild(err);
      setTimeout(() => err.remove(), 4000);
    }
  });
}

$clearAll.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "clear-queue" }, () => {
    loadQueue();
  });
});

function escapeHtml(str) {
  return String(str || "").replace(/[&<>"']/g, (c) => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;",
  }[c]));
}

loadQueue();