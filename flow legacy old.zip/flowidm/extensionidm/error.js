const params = new URLSearchParams(location.search);
const msg = params.get('msg') || 'Unknown error';
const url = params.get('url') || '';

document.getElementById('error-msg').textContent = `Error: ${msg}\nURL: ${url}`;

document.getElementById('copy-btn').addEventListener('click', () => {
  navigator.clipboard.writeText(`Error: ${msg}\nURL: ${url}`).then(() => {
    const btn = document.getElementById('copy-btn');
    btn.textContent = 'Copied!';
    setTimeout(() => btn.textContent = 'Copy Error Code', 2000);
  });
});

document.getElementById('close-btn').addEventListener('click', () => {
  window.close();
});
