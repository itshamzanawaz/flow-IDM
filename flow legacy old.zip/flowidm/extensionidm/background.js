/* ================================================================
 *  Flow Download Capture (v17 — 4MB Rule + Persistent Errors)
 * ================================================================ */

const BRIDGE_URL         = "http://127.0.0.1:27812/download";
const BRIDGE_TOKEN       = "flow-download-manager-secret-change-me";
const POST_TIMEOUT_MS    = 15000;
const HLS_PAIR_WINDOW_MS = 3000;
const DEDUP_WINDOW_MS    = 5000;
const MB4                = 4 * 1024 * 1024;

let autoCapture = true;
chrome.storage.local.get(["autoCapture"], (r) => {
  if (r.autoCapture !== undefined) autoCapture = r.autoCapture;
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.autoCapture) autoCapture = changes.autoCapture.newValue;
});

/* ================================================================
 *  Helpers
 * ================================================================ */
async function getFileSize(url) {
  try {
    const controller = new AbortController();
    setTimeout(() => controller.abort(), 3000); // 3s timeout
    const res = await fetch(url, { method: 'HEAD', credentials: 'include', signal: controller.signal });
    const len = res.headers.get('content-length');
    if (len) return parseInt(len, 10);
  } catch (e) {}
  return -1;
}

function showErrorPopup(errorMsg, url) {
  chrome.windows.create({
    url: `error.html?msg=${encodeURIComponent(errorMsg)}&url=${encodeURIComponent(url)}`,
    type: 'popup',
    width: 500,
    height: 350
  });
}

/* ================================================================
 *  HLS Manual Queue (Always captured)
 * ================================================================ */
async function queueCapture(payload) {
  try {
    const data = await chrome.storage.local.get(["captureQueue"]);
    const queue = data.captureQueue || [];
    
    const id = Date.now().toString() + Math.floor(Math.random() * 1000);
    payload.captureId = id;
    
    let displayName = payload.filename || "Unknown File";
    if (!payload.filename && payload.url) {
      displayName = payload.url.split('?')[0].split('/').pop() || "HLS Stream";
    }
    payload.displayName = displayName;

    queue.push(payload);
    await chrome.storage.local.set({ captureQueue: queue });
    
    await chrome.action.setBadgeText({ text: queue.length.toString() });
    await chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
    
    console.log("[Flow SW] Queued HLS stream:", displayName);
  } catch (e) {
    console.error("[Flow SW] Failed to queue capture:", e);
  }
}

chrome.storage.local.get(["captureQueue"], (data) => {
  const count = (data.captureQueue || []).length;
  if (count > 0) {
    chrome.action.setBadgeText({ text: count.toString() });
    chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
  }
});

/* ================================================================
 *  HLS Capture (webRequest)
 * ================================================================ */
const hlsPending = new Map();

function isManifestUrl(url) {
  if (typeof url !== "string") return false;
  if (/\.m3u8(\?|#|$)/i.test(url)) return true;
  if (/\.mpd(\?|#|$)/i.test(url)) return true;
  return false;
}

function hlsBasePath(url) {
  try {
    const u = new URL(url);
    const parts = u.pathname.split("/").filter(Boolean);
    const filesIdx = parts.indexOf("files");
    if (filesIdx >= 0 && parts.length > filesIdx + 1) {
      return parts.slice(0, filesIdx + 2).join("/");
    }
    for (let i = 0; i < parts.length; i++) {
      if (/^[0-9A-Za-z]{16,}$/.test(parts[i])) {
        return parts.slice(0, i + 1).join("/");
      }
    }
    return parts.slice(0, -2).join("/");
  } catch { return url; }
}

function hlsClassify(url) {
  try {
    const u = new URL(url);
    if (u.hostname.includes("net52") || u.hostname.includes("netmirror")) {
      return "master";
    }
  } catch {}

  if (/\/master\.m3u8/i.test(url) || /\/playlist\.m3u8/i.test(url)) return "master";
  if (/\/\d+p\//i.test(url) || /\/(video|v)\//i.test(url))            return "video";
  if (/\/a\/\d/i.test(url) || /\/(audio|aud)\//i.test(url))           return "audio";
  return "other";
}

chrome.webRequest.onCompleted.addListener(
  async (details) => {
    if (!isManifestUrl(details.url)) return;
    if (details.statusCode < 200 || details.statusCode >= 400) return;
    if (details.tabId === -2) return;
    if (!autoCapture) return;

    try {
      await handleManifestRequest(details);
    } catch (err) {
      console.error("[Flow SW] handleManifest Error:", err);
    }
  },
  { urls: ["<all_urls>"], types: ["xmlhttprequest", "media", "other", "object"] }
);

async function handleManifestRequest(details) {
  const base = hlsBasePath(details.url);
  const kind = hlsClassify(details.url);
  const now  = Date.now();

  let entry = hlsPending.get(base);
  if (!entry) {
    entry = { ts: now, timer: null, sent: false, master: null, video: null, audio: null, seenUrls: [], tabId: details.tabId >= 0 ? details.tabId : null, initiator: details.initiator };
    hlsPending.set(base, entry);
  }
  entry.ts = now;
  if (details.tabId >= 0 && !entry.tabId) entry.tabId = details.tabId;
  if (details.initiator && !entry.initiator) entry.initiator = details.initiator;

  if (kind === "master") entry.master = details.url;
  if (kind === "video")  entry.video  = details.url;
  if (kind === "audio")  entry.audio  = details.url;

  if (!entry.seenUrls.includes(details.url)) entry.seenUrls.push(details.url);
  if (entry.seenUrls.length >= 2 && !entry.video && !entry.audio) {
    entry.video = entry.seenUrls[0];
    entry.audio = entry.seenUrls[1];
  }

  if (entry.master && !entry.sent) return flushHlsToQueue(base, entry, true);
  if (entry.video && entry.audio && !entry.sent) return flushHlsToQueue(base, entry, false);

  if (!entry.timer) {
    entry.timer = setTimeout(() => { if (!entry.sent) flushHlsToQueue(base, entry, true); }, HLS_PAIR_WINDOW_MS);
  }
}

async function flushHlsToQueue(base, entry, single) {
  entry.sent = true;
  if (entry.timer) clearTimeout(entry.timer);
  hlsPending.delete(base);

  let url = null, audioUrl = null;
  if (single) url = entry.master || entry.video || entry.audio;
  else { url = entry.video; audioUrl = entry.audio; }
  if (!url) return;

  let referrer = entry.initiator || "";
  if (url.includes("net52.cc") || url.includes("freecdn") || url.includes("netmirror")) {
      referrer = "https://net52.cc";
  }

  let displayName = "HLS_Video";
  try {
    const u = new URL(url);
    const parts = u.pathname.split('/');
    displayName = parts[parts.length - 1] || displayName;
  } catch {}

  const payload = { url, isHls: true, referrer, filename: displayName };
  if (audioUrl) payload.audioUrl = audioUrl;
  
  await queueCapture(payload);
}

/* ================================================================
 *  Normal Downloads (chrome.downloads)
 * ================================================================ */
function basename(p) {
  if (!p || typeof p !== "string") return "";
  p = p.split('?')[0];
  const i = Math.max(p.lastIndexOf("/"), p.lastIndexOf("\\"));
  return i >= 0 ? p.slice(i + 1) : p;
}

const recentCaptures = new Map();
function isDuplicate(url) {
  const now = Date.now();
  for (const [u, ts] of recentCaptures) {
    if (now - ts > DEDUP_WINDOW_MS) recentCaptures.delete(u);
  }
  if (recentCaptures.has(url)) return true;
  recentCaptures.set(url, now);
  return false;
}

chrome.downloads.onCreated.addListener(async (downloadItem) => {
  if (downloadItem.byExtensionId) return;
  const url = downloadItem.url;
  if (!url || url.startsWith("blob:") || url.startsWith("data:")) return;

  // Ignore HLS fragments
  if (/\.(ts|m4s)(\?|#|$)/i.test(url)) return;

  const startTime = new Date(downloadItem.startTime).getTime();
  if (Date.now() - startTime > 10000) {
    chrome.downloads.erase({ id: downloadItem.id }).catch(() => {});
    return;
  }

  if (isDuplicate(url)) {
    chrome.downloads.cancel(downloadItem.id).catch(() => {});
    chrome.downloads.erase({ id: downloadItem.id }).catch(() => {});
    return;
  }

  // Get file size
  let size = downloadItem.fileSize || downloadItem.totalBytes || -1;
  if (size <= 0) {
    size = await getFileSize(url);
  }

  // 4MB Rule: If size is known and less than 4MB, let Chrome handle it.
  if (size > 0 && size < MB4 && !isManifestUrl(url) && !url.includes("yt-dl.click")) {
    console.log(`[Flow SW] File < 4MB (${size} bytes). Letting Chrome handle it.`);
    return; 
  }

  // IMMEDIATELY cancel and erase to prevent the Chrome popup from appearing
  try {
    await chrome.downloads.cancel(downloadItem.id);
    await chrome.downloads.erase({ id: downloadItem.id });
  } catch (e) {}

  let referrer = "";
  if (downloadItem.referrer && (downloadItem.referrer.startsWith("http:") || downloadItem.referrer.startsWith("https:"))) {
    referrer = downloadItem.referrer;
  }

  let filename = basename(downloadItem.filename) || basename(url);
  if (filename === "download" || filename === "download.bin") {
    filename = "";
  }
  
  const useYtDlp = url.includes("yt-dl.click") || url.includes("y2mate") || url.includes("tunnel");

  if (isManifestUrl(url)) {
      console.log("[Flow SW] Intercepted HLS download:", filename);
      const payload = { url, filename, referrer, isHls: true };
      await queueCapture(payload);
  } else if (useYtDlp) {
      console.log("[Flow SW] Intercepted Tunnel/YT-DLP download:", filename);
      autoSendToFlow({ url, filename, referrer, useYtDlp: true });
  } else {
      console.log("[Flow SW] Intercepted Normal file >= 4MB:", filename);
      autoSendToFlow({ url, filename, referrer });
  }
});

/* ================================================================
 *  Bridge Communication
 * ================================================================ */
async function autoSendToFlow(payload) {
  try {
    const res = await sendToBridge(payload);
    if (res && res.success) {
      console.log("[Flow SW] Auto-download started in Flow app:", res.id);
    } else {
      throw new Error(res.error || "Bridge rejected the download.");
    }
  } catch (err) {
    console.error("[Flow SW] Auto-send failed:", err.message);
    
    // If Flow explicitly rejected it for being < 4MB, silently fallback
    if (err.message.includes("less than 4MB")) {
      console.log("[Flow SW] Flow rejected file < 4MB. Restoring Chrome download.");
      chrome.downloads.download({ url: payload.url, filename: payload.filename });
      return;
    }

    // Otherwise, show the persistent error popup and restore Chrome download
    showErrorPopup(err.message, payload.url);
    chrome.downloads.download({ url: payload.url, filename: payload.filename });
  }
}

async function sendToBridge(payload) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), POST_TIMEOUT_MS);
  
  try {
    const cookies = await chrome.cookies.getAll({ url: payload.url }).catch(() => []);
    if (cookies.length > 0) {
      const seen = new Set();
      const parts = [];
      for (const c of cookies) {
        if (seen.has(c.name)) continue;
        seen.add(c.name);
        parts.push(`${c.name}=${c.value}`);
      }
      payload.cookies = parts.join("; ");
    }

    const res = await fetch(BRIDGE_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Flow-Token": BRIDGE_TOKEN },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      let msg = `HTTP ${res.status}`;
      try { const parsed = JSON.parse(text); if (parsed.error) msg += ` — ${parsed.error}`; } catch { if (text) msg += ` — ${text.slice(0, 200)}`; }
      throw new Error(msg);
    }
    return await res.json();
  } catch (err) {
    if (err.name === 'AbortError') throw new Error("Flow app timed out.");
    if (err.message === "Failed to fetch") throw new Error("Flow app is not running.");
    throw err;
  } finally { 
    clearTimeout(timer); 
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg) return;

  if (msg.type === "get-queue") {
    chrome.storage.local.get(["captureQueue"], (data) => {
      sendResponse({ queue: data.captureQueue || [] });
    });
    return true;
  }

  if (msg.type === "download-item") {
    chrome.storage.local.get(["captureQueue"], async (data) => {
      const queue = data.captureQueue || [];
      const payload = queue.find(q => q.captureId === msg.id);
      if (!payload) return sendResponse({ success: false, error: "Not found in queue" });

      try {
        const res = await sendToBridge(payload);
        if (res && res.success) {
          const newQueue = queue.filter(q => q.captureId !== msg.id);
          await chrome.storage.local.set({ captureQueue: newQueue });
          
          if (newQueue.length > 0) {
            chrome.action.setBadgeText({ text: newQueue.length.toString() });
          } else {
            chrome.action.setBadgeText({ text: "" });
          }
          
          sendResponse({ success: true });
        } else {
          sendResponse({ success: false, error: res.error || "Bridge rejected" });
        }
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    });
    return true;
  }

  if (msg.type === "clear-queue") {
    chrome.storage.local.set({ captureQueue: [] }).then(() => {
      chrome.action.setBadgeText({ text: "" });
      sendResponse({ success: true });
    });
    return true;
  }
});
