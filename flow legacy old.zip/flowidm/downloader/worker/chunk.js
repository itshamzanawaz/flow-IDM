/* ================================================================
 *  Flow — chunk download with in-worker retries
 *
 *  Retries the *remaining* portion of a chunk on partial failure.
 *  `downloaded` advances by the partial byte count reported by
 *  range.js even when the attempt throws, so retries never re-fetch
 *  bytes already on disk, and main's high-water accounting stays
 *  monotone.
 *
 *  Freeze-fix (v3.1): throttled errors are bounded by
 *  MAX_THROTTLE_RETRIES so a permanently 429/503-throttled server
 *  fails loudly instead of hanging inside the retry loop until the
 *  task-level NO_PROGRESS_FAIL_MS watchdog fires.
 * ================================================================ */

const { RETRY_BASE_MS } = require("./config");
const { state, log, sleep } = require("./state");
const { downloadRange } = require("./range");

const MAX_THROTTLE_RETRIES = 20;
// Hard bound on how many times a single chunk may be restarted from byte 0
// because the server keeps answering 200 OK. Beyond this we give up and let
// main convert the whole download to a non-resumable single stream — this
// guarantees the worker can never spin forever on a Range-ignoring server.
const MAX_RESTART_FROM_ZERO = 3;

function classifyError(err) {
  const code = err && err.code;
  const status = err && err.status;
  const msg = String((err && err.message) || "");

  if (err && (err.restartFromZero || code === "non-resumable")) return "restart-from-zero";
  if (code === "ENOSPC" || code === "EACCES" || code === "ENOENT" || code === "EBADF") {
    return "fatal-disk";
  }
  if (status === 404 || status === 410) return "fatal-link";
  if (/HTTP 404|HTTP 410|link expired|auth required|HTML error page/i.test(msg)) return "fatal-link";
  if (status === 429 || status === 503) return "throttled";
  if (/HTTP 429|HTTP 503/.test(msg)) return "throttled";
  if (status === 416) return "file-changed";
  if (/Content-Range|HTTP 416|If-Range|ignored Range/i.test(msg)) return "file-changed";
  return "transient";
}

function retryDelayMs(err, attempt) {
  const ra = err && Number(err.retryAfter);
  if (Number.isFinite(ra) && ra > 0) return Math.min(ra * 1000, 60000);
  const exp = Math.min(RETRY_BASE_MS * Math.pow(2, attempt - 1), 30000);
  return exp + Math.random() * RETRY_BASE_MS;
}

async function downloadChunk(chunk) {
  const { id: chunkId, start, end } = chunk;
  const totalBytes = end - start + 1;
  let downloaded = chunk.downloaded || 0;

  let lastErr = null;
  let throttleRetries = 0;
  let restartFromZeroCount = 0;

  for (let attempt = 1; attempt <= state.maxAttempts; attempt++) {
    if (state.isShuttingDown) throw new Error("aborted");

    const offset = start + downloaded;
    const remaining = end - offset + 1;
    if (remaining <= 0) return;

    let written = 0;
    try {
      written = await downloadRange(offset, end, chunkId);
    } catch (err) {
      if (state.isShuttingDown || err.message === "aborted") {
        throw new Error("aborted");
      }
      const partial = err.bytesWritten || 0;
      if (partial > 0) {
        downloaded += partial;
        if (downloaded >= totalBytes) return;
      }
      err.code = err.code || classifyError(err);
      lastErr = err;
      log(`chunk ${chunkId} attempt ${attempt} failed (+${partial}B) [${err.code}]: ${err.message}`);

      if (err.code === "fatal-disk" || err.code === "fatal-link" || err.code === "file-changed") {
        throw err;
      }
      if (err.code === "restart-from-zero" || err.code === "non-resumable") {
        // The server answered 200 OK instead of 206 Partial Content — it is
        // ignoring Range. BOUNDED fallback: never spin forever on a server
        // that keeps answering 200 OK.
        restartFromZeroCount++;
        if (restartFromZeroCount > MAX_RESTART_FROM_ZERO) {
          throw err; // give up gracefully; main converts the whole download
        }
        if (chunk.start > 0 || totalBytes !== state.totalSize) {
          // Mid-file chunk (or a partial first chunk): byte 0 does not
          // belong to this chunk, so it cannot safely restart from 0 on its
          // own. Re-throw so main converts the task to a single
          // non-resumable stream from byte 0.
          throw err;
        }
        // Whole-file chunk: fall back to a plain continuous stream from 0.
        downloaded = 0;
        attempt--; // a 200-OK restart is a fallback, not a failure
        await sleep(500);
        continue;
      }
      if (err.code === "throttled") {
        // Throttled errors do not consume the per-chunk attempt budget,
        // but they must terminate: bound throttle retries so a permanent
        // 429/503 fails loudly instead of hanging the worker.
        throttleRetries++;
        if (throttleRetries > MAX_THROTTLE_RETRIES) throw err;
        await sleep(retryDelayMs(err, throttleRetries));
        attempt--;
        continue;
      }
      if (attempt < state.maxAttempts) await sleep(retryDelayMs(err, attempt));
      continue;
    }

    downloaded += written;
    if (downloaded >= totalBytes) return;

    log(`chunk ${chunkId} attempt ${attempt}: got ${downloaded}/${totalBytes}, retrying`);
    if (attempt < state.maxAttempts) await sleep(retryDelayMs(null, attempt));
  }

  throw lastErr || new Error(
    `Chunk ${chunkId} failed after ${state.maxAttempts} attempts`
  );
}

module.exports = { downloadChunk, classifyError };