/* ================================================================
 *  Flow — download engine (public facade)
 *
 *  Exports the same API as before the refactor:
 *    prepareDownload, startTask, pauseTask, cancelTask, pauseAll,
 *    removePartialFiles, isTaskActive
 *
 *  Plus:
 *    onSystemResume()   — called from powerMonitor.on("resume")
 *
 *  Internals are split across:
 *    config.js      — constants
 *    utils.js       — filename / path / fs helpers
 *    chunkState.js  — sizing, layout, validation, persistence
 *    probe.js       — prepareDownload implementation
 *    task.js        — DownloadTask class (worker orchestration)
 *
 *  id-type boundary
 *  -----------------
 *  better-sqlite3 returns lastInsertRowid as a JS number, and the
 *  renderer hands resume/cancel ids back as numbers. DownloadTask
 *  requires a non-empty string id so its internal state files and
 *  log lines are unambiguous. This module is the single translation
 *  boundary: caller-supplied ids are stringified before reaching
 *  DownloadTask and before being used as registry keys; progress
 *  payloads emitted by the task are re-emitted to the renderer with
 *  the caller's original numeric id so `state.active.get(id)` lookups
 *  keep working.
 * ================================================================ */

const fs = require("fs");

const { prepareDownload } = require("./probe");
const { DownloadTask } = require("./task");
const { forwardDownloadProgress } = require("../main/downloadWindow");

/* ---------------- Global registry ---------------- */
const tasks = new Map();       // String(id) -> DownloadTask
const fileLocks = new Map();   // filePath  -> DownloadTask (instance, not id)

/* ================================================================
 *  Sender adapter
 *
 *  DownloadTask emits `download-progress` payloads whose `id` field
 *  equals its internal (string) id. The renderer keys `state.active`
 *  by the DB-assigned numeric id, so we rewrite the payload id back
 *  to the caller's original value on the way out. Non-progress
 *  channels (status-change, download-error) are passed through
 *  untouched because taskCompletion.js already sends those with the
 *  numeric id.
 * ================================================================ */
function wrapSender(sender, originalId, stringId) {
  if (!sender || typeof sender.send !== "function") {
    return { send: () => {} };
  }
  return {
    send: (channel, payload) => {
      try {
        if (payload && typeof payload === "object" && payload.id === stringId) {
          const out = { ...payload, id: originalId };
          sender.send(channel, out);
          // Requirement 5: keep any open dedicated progress window for this
          // download live with the same progress stream.
          if (channel === "download-progress") forwardDownloadProgress(out);
        } else {
          sender.send(channel, payload);
        }
      } catch {
        /* webContents destroyed mid-send — same policy as before */
      }
    },
    isDestroyed:
      typeof sender.isDestroyed === "function"
        ? () => sender.isDestroyed()
        : undefined,
  };
}

/* ================================================================
 *  startTask
 *
 *  validators (7th argument) is passed through to DownloadTask so
 *  workers can send If-Range and so MOTW can stamp the redirect-
 *  target host. It is optional — callers that omit it disable
 *  change detection for the task.
 *
 *  Ownership rule: the .finally block only removes registry / lock
 *  entries that still reference THIS task instance, so a new task
 *  started with the same id after this one finalizes is never
 *  orphaned by an old task's cleanup.
 * ================================================================ */
function startTask(id, url, filePath, totalSize, sender, extraHeaders = {}, validators = {}) {
  const stringId = String(id);

  const existing = tasks.get(stringId);
  if (existing && existing.state !== "finalized") {
    return Promise.reject(new Error("A download is already running with this id."));
  }

  const lockedBy = fileLocks.get(filePath);
  if (lockedBy && lockedBy !== existing) {
    return Promise.reject(new Error("Another download is already writing to this file."));
  }

  const wrappedSender = wrapSender(sender, id, stringId);

  const task = new DownloadTask({
    id: stringId,
    url,
    filePath,
    totalSize,
    sender: wrappedSender,
    extraHeaders,
    validators,
  });

  tasks.set(stringId, task);
  fileLocks.set(filePath, task);

  return task.run().finally(() => {
    if (tasks.get(stringId) === task) tasks.delete(stringId);
    if (fileLocks.get(filePath) === task) fileLocks.delete(filePath);
  });
}

/* ================================================================
 *  pauseTask / cancelTask
 * ================================================================ */
async function pauseTask(id) {
  const task = tasks.get(String(id));
  if (!task) return { success: false, error: "No active download with this id." };
  return task.pause();
}

async function cancelTask(id) {
  const task = tasks.get(String(id));
  if (!task) return { success: false, error: "No active download with this id." };
  return task.cancel();
}

async function pauseAll() {
  const ids = Array.from(tasks.keys());
  await Promise.all(ids.map((id) => pauseTask(id).catch(() => {})));
}

/* ================================================================
 *  Utilities
 * ================================================================ */
function removePartialFiles(filePath) {
  const files = [
    filePath + ".fastdl",
    filePath + ".download",
    filePath + ".fastdl.tmp",
  ];
  for (const p of files) {
    try {
      if (fs.existsSync(p)) fs.unlinkSync(p);
    } catch (err) {
      console.error("[downloadManager] cleanup failed:", p, err.message);
    }
  }
}

function isTaskActive(id) {
  const t = tasks.get(String(id));
  return !!t && t.state !== "finalized";
}

/* ================================================================
 *  onSystemResume — called from powerMonitor.on("resume")
 *
 *  Applies a grace window on every live task so a laptop sleep/resume
 *  is not treated as a network stall by the per-chunk watchdog.
 * ================================================================ */
async function onSystemResume() {
  for (const t of tasks.values()) {
    try { t.onSystemResume(); } catch { /* per-task failure handled inside */ }
  }
}

/* ================================================================
 *  Exports
 * ================================================================ */
module.exports = {
  prepareDownload,
  startTask,
  pauseTask,
  cancelTask,
  pauseAll,
  removePartialFiles,
  isTaskActive,
  onSystemResume,
};