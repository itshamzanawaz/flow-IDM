/* ================================================================
 *  Flow — Download Progress Window Renderer Logic
 *
 *  Renders live progress (progress bar, speed, ETA, bytes) for one
 *  download id. The main process forwards "download-progress" events
 *  to this window while the download is active; "status-change" events
 *  keep the action buttons in sync with the DB state.
 * ================================================================ */

const urlParams = new URLSearchParams(window.location.search);
const downloadId = Number(urlParams.get("id"));

const filenameEl = document.getElementById("filename");
const speedEl = document.getElementById("speed");
const etaEl = document.getElementById("eta");
const fillEl = document.getElementById("fill");
const statsEl = document.getElementById("stats");
const pauseBtn = document.getElementById("pauseBtn");
const cancelBtn = document.getElementById("cancelBtn");

function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.min(sizes.length - 1, Math.floor(Math.log(bytes) / Math.log(k)));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

function setProgress(percent, downloaded, totalSize, speedMBps, etaSeconds) {
  const pct = Math.max(0, Math.min(100, Number(percent) || 0));
  fillEl.style.width = `${pct}%`;
  speedEl.textContent = `${Number(speedMBps) || 0} MB/s`;
  etaEl.textContent = Number(etaSeconds) > 0 ? `ETA: ${Math.ceil(etaSeconds)}s` : "ETA: --";
  statsEl.textContent = `${formatBytes(downloaded)} / ${formatBytes(totalSize)} (${Math.round(pct)}%)`;
}

async function init() {
  const history = await window.api.getHistory();
  const item = history.find((h) => Number(h.id) === downloadId);
  if (!item) return;

  filenameEl.textContent = item.filename || "Download";
  applyStatus(item);
}

function applyStatus(item) {
  if (!item) return;
  const st = String(item.status || "").toLowerCase();
  const total = Number(item.totalSize) || 0;

  if (st === "completed") {
    fillEl.style.width = "100%";
    speedEl.textContent = "0 MB/s";
    etaEl.textContent = "ETA: --";
    statsEl.textContent = `${formatBytes(total)} (Completed)`;
    pauseBtn.textContent = "Open";
    pauseBtn.disabled = false;
    pauseBtn.onclick = () => window.api.openFile(item.directory);
    cancelBtn.textContent = "Close";
    cancelBtn.disabled = false;
    cancelBtn.onclick = () => window.close();
    return;
  }

  if (st === "paused") {
    pauseBtn.textContent = "Resume";
    pauseBtn.disabled = false;
    pauseBtn.onclick = () => window.api.resumeDownload(downloadId);
    cancelBtn.textContent = "Cancel";
    cancelBtn.disabled = false;
    cancelBtn.onclick = () => { window.api.cancelDownload(downloadId, true); window.close(); };
    return;
  }

  if (st === "error" || st === "cancelled") {
    pauseBtn.textContent = "Retry";
    pauseBtn.disabled = false;
    pauseBtn.onclick = () => window.api.resumeDownload(downloadId);
    cancelBtn.textContent = "Close";
    cancelBtn.disabled = false;
    cancelBtn.onclick = () => window.close();
    return;
  }

  // Downloading / Preparing / unknown
  pauseBtn.textContent = "Pause";
  pauseBtn.disabled = false;
  pauseBtn.onclick = () => window.api.pauseDownload(downloadId);
  cancelBtn.textContent = "Cancel";
  cancelBtn.disabled = false;
  cancelBtn.onclick = () => { window.api.cancelDownload(downloadId, true); window.close(); };
}

window.api.onDownloadProgress((payload) => {
  if (Number(payload.id) !== downloadId) return;
  setProgress(payload.percent, payload.downloaded, payload.totalSize, payload.speedMBps, payload.etaSeconds);
});

window.api.onStatusChange(async () => {
  const history = await window.api.getHistory();
  const item = history.find((h) => Number(h.id) === downloadId);
  if (item) applyStatus(item);
});

init();
