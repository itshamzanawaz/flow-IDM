/* ================================================================
 *  Flow — user-initiated actions (pause / resume / cancel / delete…)
 *  Optimistic UI with snapshot restore on failure.
 *
 *  doRemove now presents a two-option delete dialog:
 *    • Delete from disk     → deleteDownload(id, true)
 *    • Remove from list     → deleteDownload(id, false)
 *
 *  runBulk("remove") reuses the same dialog once for the whole
 *  selection and passes skipConfirm to each per-item call so the
 *  dialog is not re-shown per row.
 * ================================================================ */

import { state } from "./state.js";
import { findItem } from "./data.js";
import { render } from "./render.js";
import { toast } from "./toast.js";
import { confirmDialog } from "./confirm.js";
import { deleteChoiceDialog } from "./deleteDialog.js";
import { refreshHistory } from "./refresh.js";
import { openDetails } from "./details.js";

export async function handleAction(action, id, opts = {}) {
  const numId = Number(id);
  const key = `${action}:${numId}`;
  if (state.inflight.has(key)) return;
  state.inflight.add(key);

  try {
    switch (action) {
      case "pause":       return await doPause(numId);
      case "resume":      return await doResume(numId);
      case "cancel":      return await doCancel(numId);
      case "retry":       return await doRetry(numId);
      case "remove":      return await doRemove(numId, opts);
      case "open":        return await doOpen(numId);
      case "folder":      return doFolder(numId);
      case "copy":        return await doCopy(numId);
      case "details":     return doDetails(numId);
      case "openDownloadWindow": return await doOpenDownloadWindow(numId);
    }
  } catch (err) {
    console.error("[flow] action failed:", action, err);
    toast(err.message || "Action failed", "error");
  } finally {
    state.inflight.delete(key);
    if (["pause", "resume", "cancel", "retry", "remove"].includes(action)) {
      try { await refreshHistory(); } catch {}
    }
  }
}

/* ---------------- Individual actions ---------------- */
async function doPause(numId) {
  const entry = state.active.get(numId);
  if (entry) {
    entry.status = "Paused";
    entry.speedMBps = 0;
    entry.etaSeconds = 0;
    render();
  }
  let res;
  try { res = await window.api.pauseDownload(numId); }
  catch (err) {
    if (entry) entry.status = "Downloading";
    render();
    toast("Could not pause: " + (err.message || err), "error");
    return;
  }
  if (!res || res.success === false) {
    if (entry) entry.status = "Downloading";
    render();
    toast((res && res.error) || "Could not pause download", "error");
  } else {
    toast("Download paused", "info");
  }
}

async function doResume(numId) {
  const item = findItem(numId);
  const prev = state.active.get(numId);

  const base = {
    id: numId,
    filename: item ? item.filename : (prev?.filename || "download"),
    filePath: item ? item.directory : prev?.filePath,
    totalSize: item ? item.totalSize : (prev?.totalSize || 0),
    percent: prev?.percent || 0,
    speedMBps: 0,
    etaSeconds: 0,
    startedAt: Date.now(),
  };
  const snapshot = { ...base, status: "Paused" };

  state.active.set(numId, { ...base, status: "Downloading" });
  render();

  let res;
  try { res = await window.api.resumeDownload(numId); }
  catch (err) {
    state.active.set(numId, snapshot);
    render();
    toast("Could not resume: " + (err.message || err), "error");
    return;
  }
  if (!res || res.success === false) {
    state.active.set(numId, snapshot);
    render();
    toast((res && res.error) || "Could not resume download", "error");
  } else {
    toast("Download resumed", "info");
  }
}

async function doCancel(numId) {
  const entry = state.active.get(numId);
  state.active.delete(numId);
  render();

  let res;
  try { res = await window.api.cancelDownload(numId, true); }
  catch (err) {
    if (entry) state.active.set(numId, entry);
    render();
    toast("Could not cancel: " + (err.message || err), "error");
    return;
  }
  if (!res || res.success === false) {
    if (entry) state.active.set(numId, entry);
    render();
    toast((res && res.error) || "Could not cancel download", "error");
  } else {
    toast("Download cancelled", "info");
  }
}

async function doRetry(numId) {
  const item = findItem(numId);
  const prev = state.active.get(numId);

  const base = {
    id: numId,
    filename: item ? item.filename : (prev?.filename || "download"),
    filePath: item ? item.directory : prev?.filePath,
    totalSize: item ? item.totalSize : (prev?.totalSize || 0),
    percent: 0,
    speedMBps: 0,
    etaSeconds: 0,
    startedAt: Date.now(),
  };
  const snapshot = { ...base, status: "Error" };

  state.active.set(numId, { ...base, status: "Downloading" });
  render();

  let res;
  try { res = await window.api.resumeDownload(numId); }
  catch (err) {
    state.active.set(numId, snapshot);
    render();
    toast("Could not retry: " + (err.message || err), "error");
    return;
  }
  if (!res || res.success === false) {
    state.active.set(numId, snapshot);
    render();
    toast((res && res.error) || "Could not retry download", "error");
  } else {
    toast("Retrying download", "info");
  }
}

async function doRemove(numId, { skipConfirm = false, deleteFile = false } = {}) {
  const item = findItem(numId);

  let choice;
  if (skipConfirm) {
    choice = deleteFile ? "disk" : "list";
  } else {
    choice = await deleteChoiceDialog(item?.filename);
    if (!choice) return;                 // user cancelled
  }

  const res = await window.api.deleteDownload(numId, choice === "disk");
  if (res && res.success) {
    toast(choice === "disk" ? "Deleted from disk" : "Removed from history", "info");
  } else if (res && res.error) {
    toast(res.error, "warning");
  }
  state.selected.delete(numId);
}

async function doOpen(numId) {
  const item = findItem(numId);
  if (!item) return;
  const res = await window.api.openFile(item.directory);
  if (res && !res.success) toast(res.error || "File not found", "error");
}

/** Requirement 5: open the dedicated progress window for an active download. */
async function doOpenDownloadWindow(numId) {
  const res = await window.api.openDownloadWindow(numId);
  if (res && res.success === false) {
    toast(res.error || "Could not open progress window", "error");
  }
}

function doFolder(numId) {
  const item = findItem(numId);
  if (!item) return;
  window.api.openFolder(item.directory);
}

async function doCopy(numId) {
  const item = findItem(numId);
  if (!item || !item.url) { toast("No URL to copy", "warning"); return; }
  try {
    await navigator.clipboard.writeText(item.url);
    toast("URL copied", "success");
  } catch { toast("Could not copy URL", "error"); }
}

function doDetails(numId) {
  const item = findItem(numId);
  if (!item) return;
  openDetails(item);
}

/* ---------------- Bulk actions ---------------- */
export async function runBulk(kind) {
  const ids = Array.from(state.selected);
  if (!ids.length) return;

  if (kind === "clear-selection") {
    state.selected.clear();
    render();
    return;
  }

  if (kind === "remove") {
    const label = ids.length === 1 ? undefined : `${ids.length} items`;
    const choice = await deleteChoiceDialog(label);
    if (!choice) return;
    const deleteFile = choice === "disk";
    const results = await Promise.allSettled(
      ids.map((id) => handleAction("remove", id, { skipConfirm: true, deleteFile }))
    );
    const failed = results.filter((r) => r.status === "rejected").length;
    state.selected.clear();
    if (failed) toast(`${failed} action(s) failed`, "warning");
    else toast(deleteFile ? "Deleted from disk" : "Removed from history", "success");
    await refreshHistory();
    return;
  }

  if (kind === "cancel") {
    const ok = await confirmDialog(
      "Cancel selected downloads?",
      `Cancel ${ids.length} active download${ids.length === 1 ? "" : "s"}? Partial files will be deleted.`,
      { confirmLabel: "Cancel downloads" }
    );
    if (!ok) return;
  }

  const results = await Promise.allSettled(ids.map((id) => handleAction(kind, id)));
  const failed = results.filter((r) => r.status === "rejected").length;
  state.selected.clear();
  if (failed) toast(`${failed} action(s) failed`, "warning");
  else toast(`Bulk ${kind} complete`, "success");
  await refreshHistory();
}