/* ================================================================
 *  Flow — task completion + lingering-task cleanup
 *
 *  handleTaskCompletion: translates the engine's result object into
 *    a DB status + IPC event, honouring opts.restoreOnError so that
 *    a failed resume can be silently restored to "Paused" instead of
 *    being flagged as an Error.
 *
 *  clearLingeringTask: before resume/refresh we cancel any task the
 *    engine still has registered under this id, otherwise startTask
 *    would reject with "download with this id already exists".
 *    A 5 s timeout guard prevents a wedged engine from freezing the
 *    resume IPC handler.
 * ================================================================ */

const { cancelTask } = require("../downloader/downloadManager");
const { getDB } = require("./database");
const { Notification } = require("electron");
const path = require("path");
const fsp = require("fs/promises");
const fs = require("fs");

const TYPE_EXTS = {
  Video:   ["mp4","mkv","avi","mov","webm","flv","m4v","wmv","mpg","mpeg","ts","m2ts"],
  Music:   ["mp3","wav","flac","aac","ogg","m4a","wma","opus","aiff"],
  Documents: ["pdf","doc","docx","txt","rtf","odt","md","xls","xlsx","ppt","pptx","csv","epub"],
  Compressed: ["zip","rar","7z","tar","gz","bz2","xz","iso","dmg"],
};

function getFileCategory(filename) {
  const ext = (String(filename || "").split(".").pop() || "").toLowerCase();
  for (const [cat, exts] of Object.entries(TYPE_EXTS)) {
    if (exts.includes(ext)) return cat;
  }
  return "Other";
}

async function sortCompletedFile(dbId, filePath) {
  try {
    if (!filePath || !fs.existsSync(filePath)) return filePath;
    const item = getDB().prepare(`SELECT directory FROM history WHERE id = ?`).get(dbId);
    if (!item || !item.directory) return filePath;

    const originalDir = path.dirname(item.directory);
    const filename = path.basename(filePath);
    const category = getFileCategory(filename);
    const targetDir = path.join(originalDir, category);

    await fsp.mkdir(targetDir, { recursive: true });
    const targetPath = path.join(targetDir, filename);

    if (filePath !== targetPath) {
      await fsp.rename(filePath, targetPath);
      getDB().prepare(`UPDATE history SET directory = ? WHERE id = ?`).run(targetPath, dbId);
      return targetPath;
    }
  } catch (err) {
    console.error("[taskCompletion] sortCompletedFile failed:", err);
  }
  return filePath;
}

async function clearLingeringTask(id) {
  try {
    const res = await Promise.race([
      cancelTask(id),
      new Promise((r) =>
        setTimeout(() => r({ success: false, error: "timeout" }), 5000)
      ),
    ]);
    if (res && res.success === false && res.error !== "timeout") {
      console.log(`[main] cancelTask(${id}) note:`, res.error);
    }
  } catch (err) {
    // No registered task — perfectly normal for a fresh start.
    console.log(`[main] cancelTask(${id}) skipped:`, err.message);
  }
  // Small grace period so the manager can drop internal bookkeeping.
  await new Promise((r) => setTimeout(r, 80));
}

async function handleTaskCompletion(id, taskPromise, sender, opts = {}) {
  const out =
    sender && typeof sender.send === "function" ? sender : { send: () => {} };
  const errorStatus = opts.restoreOnError || "Error";
  const db = getDB();

  try {
    const result = await taskPromise;
    if (!result) return;

    if (result.success) {
      const item = db.prepare(`SELECT filename, directory FROM history WHERE id = ?`).get(id);
      let finalPath = result.filePath || item?.directory;
      if (item && item.filename) {
        finalPath = await sortCompletedFile(id, finalPath);
      }
      db.prepare(`UPDATE history SET status = 'Completed' WHERE id = ?`).run(id);
      out.send("status-change");

      try {
        const filename = item ? item.filename : path.basename(finalPath || "Download");
        new Notification({ title: "Download Complete", body: filename }).show();
      } catch (err) {
        console.warn("[notification] failed:", err.message);
      }
    } else if (result.paused) {
      out.send("status-change");
    } else if (result.cancelled) {
      out.send("status-change");
    } else if (result.error) {
      db.prepare(`UPDATE history SET status = ? WHERE id = ?`).run(errorStatus, id);
      if (errorStatus !== "Paused") {
        out.send("download-error", { id, message: result.error });
      } else {
        out.send("download-error", { id, message: result.error, silent: true });
      }
      out.send("status-change");
    }
  } catch (err) {
    db.prepare(`UPDATE history SET status = ? WHERE id = ?`).run(errorStatus, id);
    const message = err.message || String(err);
    if (errorStatus !== "Paused") {
      out.send("download-error", { id, message });
    } else {
      out.send("download-error", { id, message, silent: true });
    }
    out.send("status-change");
  }
}

module.exports = { clearLingeringTask, handleTaskCompletion };