/* ================================================================
 *  Flow — HTTP bridge for the browser extension
 *
 *  Reverted the previous guard. The bridge will now accept any
 *  intentional download request, even if the URL was previously
 *  completed or cancelled.
 * ================================================================ */

const http = require("http");
const { app } = require("electron");

const { BRIDGE_PORT, BRIDGE_TOKEN } = require("./constants");
const { getDB } = require("./database");
const { getMainWindow, bringToFront } = require("./window");
const {
  prepareDownload,
  startTask,
} = require("../downloader/downloadManager");
const { handleTaskCompletion } = require("./taskCompletion");

const PREPARE_TIMEOUT_MS = 60000;

function withTimeout(promise, ms, label) {
  return Promise.race([
    promise,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`${label} timed out after ${ms / 1000}s`)), ms)
    ),
  ]);
}

function validatorsFromProbe(fileInfo) {
  return {
    etag: fileInfo.etag || null,
    lastModified: fileInfo.lastModified || null,
    validator: fileInfo.validator || null,
    contentType: fileInfo.contentType || null,
    finalUrl: fileInfo.finalUrl || null,
    // Requirement 1: propagate the probe's resumable decision so a
    // non-resumable link runs as a single whole-file stream instead of
    // being force-fed through the multi-chunk (Range) layout.
    resumable: fileInfo.resumable !== false,
  };
}

function startHttpBridge() {
  const server = http.createServer((req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-Flow-Token");

    console.log(`[http-bridge] ${req.method} ${req.url}`);

    if (req.method === "OPTIONS") {
      res.writeHead(204);
      return res.end();
    }

    if (req.method === "GET" && req.url === "/health") {
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ ok: true, app: "flow" }));
    }

    if (req.method !== "POST" || req.url !== "/download") {
      res.writeHead(404, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ error: "Not found" }));
    }

    const token = req.headers["x-flow-token"];
    if (token !== BRIDGE_TOKEN) {
      console.warn("[http-bridge] Rejecting request: bad or missing token");
      res.writeHead(403, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ error: "Forbidden — token mismatch" }));
    }

    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 5 * 1024 * 1024) req.destroy();
    });
    req.on("end", async () => {
      try {
        const parsed = JSON.parse(body);
        console.log("[http-bridge] Payload:", {
          url: parsed.url,
          cookiesLen: (parsed.cookies || "").length,
          hasReferrer: !!(parsed.referrer && String(parsed.referrer).trim()),
        });

        const result = await handleBridgeDownload(parsed);

        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify(result));
      } catch (err) {
        console.error("[http-bridge] Handler error:", err.message);
        res.writeHead(400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ success: false, error: err.message }));
      }
    });
  });

  server.on("error", (err) => {
    console.error("[http-bridge] Server error:", err.message);
    if (err.code === "EADDRINUSE") {
      console.error(
        `[http-bridge] Port ${BRIDGE_PORT} already in use. Kill the other process or change the port.`
      );
    }
  });

  server.listen(BRIDGE_PORT, "127.0.0.1", () => {
    console.log(`[http-bridge] Listening on http://127.0.0.1:${BRIDGE_PORT}`);
  });

  return server;
}

function sanitizeReferrer(referrer) {
  if (!referrer || typeof referrer !== "string") return "";
  const trimmed = referrer.trim();
  if (!trimmed) return "";
  try {
    const u = new URL(trimmed);
    if (u.protocol !== "http:" && u.protocol !== "https:") return "";
  } catch {
    return "";
  }
  return trimmed;
}

async function handleBridgeDownload({ url, cookies, referrer, filename }) {
  if (!url || typeof url !== "string") {
    throw new Error("Missing or invalid 'url' in payload.");
  }

  console.log("[bridge] handleBridgeDownload start for", url);

  bringToFront();

  const dir = app.getPath("downloads");
  const extraHeaders = {};

  if (cookies && String(cookies).trim()) {
    extraHeaders["Cookie"] = String(cookies).trim().slice(0, 8000);
  }

  const safeReferrer = sanitizeReferrer(referrer);
  if (safeReferrer) {
    extraHeaders["Referer"] = safeReferrer;
    console.log("[bridge] Referer set to:", safeReferrer);
  } else {
    console.log("[bridge] No referrer supplied — sending request without Referer header");
  }

  if (filename && String(filename).trim()) {
    extraHeaders["X-Flow-Filename-Hint"] = String(filename).trim();
  }

  let fileInfo;
  try {
    fileInfo = await withTimeout(
      prepareDownload(url, dir, extraHeaders),
      PREPARE_TIMEOUT_MS,
      "Preparing captured download"
    );
    console.log("[bridge] prepareDownload OK:", {
      fileName: fileInfo.fileName,
      totalSize: fileInfo.totalSize,
      validator: fileInfo.validator ? "yes" : "none",
    });
  } catch (err) {
    console.error("[bridge] prepareDownload FAILED:", err.message);

    const mainWindow = getMainWindow();
    if (mainWindow && !mainWindow.isDestroyed()) {
      try {
        mainWindow.webContents.send("download-error", {
          id: -1,
          message: `Could not start captured download: ${err.message}`,
        });
      } catch {}
    }

    throw err;
  }

  const stmt = getDB().prepare(
    `INSERT INTO history (filename, directory, url, totalSize, status)
     VALUES (?, ?, ?, ?, ?)`
  );
  const info = stmt.run(
    fileInfo.fileName,
    fileInfo.filePath,
    url,
    fileInfo.totalSize || 0,
    "Downloading"
  );
  const dbId = info.lastInsertRowid;
  console.log("[bridge] Inserted history row id =", dbId);

  const mainWindow = getMainWindow();
  const sender =
    mainWindow && !mainWindow.isDestroyed() && mainWindow.webContents
      ? mainWindow.webContents
      : { send: () => {} };

  try {
    sender.send("download-start", { id: dbId, ...fileInfo });
    sender.send("status-change");
  } catch (e) {
    console.warn("[bridge] Could not notify renderer:", e.message);
  }

  handleTaskCompletion(
    dbId,
    startTask(
      dbId,
      url,
      fileInfo.filePath,
      fileInfo.totalSize,
      sender,
      extraHeaders,
      validatorsFromProbe(fileInfo)
    ),
    sender
  );

  return { success: true, id: dbId, filename: fileInfo.fileName };
}

module.exports = { startHttpBridge, handleBridgeDownload };