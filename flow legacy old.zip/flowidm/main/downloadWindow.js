/* ================================================================
 *  Flow — Dedicated Download Progress Window
 *
 *  createDownloadWindow(downloadId) opens (or focuses) a small 400x300
 *  BrowserWindow per download. The window loads download.html and
 *  subscribes to the normal "download-progress" / "status-change" IPC
 *  channels through the shared preload.
 *
 *  Because DownloadTask sends progress to the webContents that started
 *  the task (the main window), this module also exposes
 *  forwardDownloadProgress(payload), which the engine's sender adapter
 *  calls so an open dedicated window receives the same live progress.
 * ================================================================ */

const { BrowserWindow } = require("electron");
const path = require("path");

const downloadWindows = new Map(); // Number(downloadId) -> BrowserWindow

function createDownloadWindow(downloadId) {
  const key = Number(downloadId);

  if (downloadWindows.has(key)) {
    const win = downloadWindows.get(key);
    if (!win.isDestroyed()) {
      if (win.isMinimized()) win.restore();
      win.focus();
      return win;
    }
    downloadWindows.delete(key);
  }

  const win = new BrowserWindow({
    width: 400,
    height: 300,
    minWidth: 350,
    minHeight: 250,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: "#0b0d12",
    title: `Download Progress #${downloadId}`,
    webPreferences: {
      preload: path.join(__dirname, "..", "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  win.once("ready-to-show", () => {
    if (!win.isDestroyed()) win.show();
  });

  win.webContents.on("did-fail-load", (_e, code, desc) => {
    console.error(`[downloadWindow] load failed for #${downloadId}:`, code, desc);
  });

  // Resolve against the app root (project root in dev, app.asar root when
  // packaged) so the window works both in `electron .` and in the build.
  win.loadFile(path.join(__dirname, "..", "download.html"), {
    query: { id: String(downloadId) },
  }).catch((err) => {
    console.error(`[downloadWindow] loadFile failed for #${downloadId}:`, err.message);
  });

  win.on("closed", () => {
    downloadWindows.delete(key);
  });

  downloadWindows.set(key, win);
  return win;
}

/**
 * Forward a live download-progress payload to the dedicated window of the
 * matching download id (if one is open). Payload ids are the numeric DB ids
 * the renderer uses; mismatched ids are ignored.
 */
function forwardDownloadProgress(payload) {
  if (!payload || payload.id === undefined || payload.id === null) return;
  const win = downloadWindows.get(Number(payload.id));
  if (!win || win.isDestroyed()) return;
  try {
    if (!win.webContents.isDestroyed()) {
      win.webContents.send("download-progress", payload);
    }
  } catch {
    /* window closing mid-send — ignore */
  }
}

module.exports = { createDownloadWindow, forwardDownloadProgress };
