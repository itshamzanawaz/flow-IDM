/* ================================================================
 *  Flow — open file / open folder IPC handlers
 * ================================================================ */

const { ipcMain, shell } = require("electron");
const fs = require("fs");
const { createDownloadWindow } = require("../downloadWindow");

function registerFileHandlers() {
  ipcMain.on("open-folder", (_event, filePath) => {
    if (filePath && fs.existsSync(filePath)) shell.showItemInFolder(filePath);
  });

  ipcMain.handle("open-file", async (_event, filePath) => {
    if (!filePath || !fs.existsSync(filePath)) {
      return { success: false, error: "File not found" };
    }
    const err = await shell.openPath(filePath);
    return err ? { success: false, error: err } : { success: true };
  });

  ipcMain.handle("open-download-window", (_event, downloadId) => {
    createDownloadWindow(downloadId);
    return { success: true };
  });
}

module.exports = { registerFileHandlers };