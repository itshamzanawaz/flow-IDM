/* ================================================================
 *  Flow — preload (contextBridge)
 * ================================================================ */

const { contextBridge, ipcRenderer } = require("electron");

function subscribe(channel, cb) {
  const handler = (_event, payload) => {
    try { cb(payload); } catch (err) {
      console.error(`[preload] listener for ${channel} threw:`, err);
    }
  };
  ipcRenderer.on(channel, handler);
  return () => ipcRenderer.removeListener(channel, handler);
}

const api = {
  /* ---------------- Clipboard / directory ---------------- */
  readClipboard:       () => ipcRenderer.invoke("read-clipboard"),
  getDefaultDirectory: () => ipcRenderer.invoke("get-default-directory"),
  selectDirectory:     () => ipcRenderer.invoke("select-directory"),

  /* ---------------- Downloads ---------------- */
  newDownload:    (payload) => ipcRenderer.invoke("new-download", payload),
  pauseDownload:  (id) => ipcRenderer.invoke("pause-download", id),
  resumeDownload: (id) => ipcRenderer.invoke("resume-download", id),
  cancelDownload: (id, deletePartial) => ipcRenderer.invoke("cancel-download", id, deletePartial),
  refreshLink:    (id, url) => ipcRenderer.invoke("refresh-link", id, url),

  /* ---------------- History ---------------- */
  getHistory:     () => ipcRenderer.invoke("get-history"),
  deleteDownload: (id, deleteFile) => ipcRenderer.invoke("delete-download", id, deleteFile),
  clearCompleted: () => ipcRenderer.invoke("clear-completed"),

  /* ---------------- Files ---------------- */
  openFile:   (filePath) => ipcRenderer.invoke("open-file", filePath),
  openFolder: (filePath) => ipcRenderer.send("open-folder", filePath),

  /* ---------------- Settings / lifecycle ---------------- */
  openSettingsWindow: () => ipcRenderer.send("open-settings-window"),
  getSettings:         () => ipcRenderer.invoke("get-settings"),
  setStartAtLogin:     (v) => ipcRenderer.invoke("set-start-at-login", v),
  setMinimizeToTray:   (v) => ipcRenderer.invoke("set-minimize-to-tray", v),
  quitApp:             () => ipcRenderer.invoke("quit-app"),

  /* ---------------- Event streams ---------------- */
  onDownloadStart:    (cb) => subscribe("download-start", cb),
  onDownloadProgress: (cb) => subscribe("download-progress", cb),
  onDownloadError:    (cb) => subscribe("download-error", cb),
  onStatusChange:     (cb) => subscribe("status-change", cb),
};

contextBridge.exposeInMainWorld("api", api);