/* ================================================================
 *  Flow — Electron main process
 *  - IPC for UI + downloads + history
 *  - HTTP bridge for browser extension
 *  - Robust probe (HEAD → GET+Range fallback)
 *  - Linux-friendly window raising
 *  - Graceful shutdown (pauses all tasks)
 *
 *  Pause / cancel / resume rules:
 *    • Status is persisted to SQLite FIRST, never blocked on the engine.
 *    • Before resuming, we ALWAYS cancel any lingering task registered
 *      under the same id, otherwise the engine rejects with
 *      "download with this id already exist".
 *    • If resume fails, the DB is restored to 'Paused' (not 'Error')
 *      so the row stays in Current Downloads with a Resume button.
 * ================================================================ */

const { app, BrowserWindow, ipcMain, dialog, shell, clipboard } = require("electron");
const path = require("path");
const Database = require("better-sqlite3");
const fs = require("fs");
const http = require("http");
const { exec } = require("child_process");

const {
  prepareDownload,
  startTask,
  pauseTask,
  cancelTask,
  pauseAll,
  removePartialFiles,
} = require("./downloader/downloadManager");

/* ---------------- Optional YouTube manager ---------------- */
let prepareYoutubeDownload, startYoutubeTask, pauseYoutubeTask;
try {
  ({
    prepareYoutubeDownload,
    startYoutubeTask,
    pauseYoutubeTask,
  } = require("./downloader/youtubeManager"));
} catch (err) {
  console.warn("[flow] youtubeManager not available:", err.message);
  prepareYoutubeDownload = async () => {
    throw new Error("YouTube downloads are not available in this build");
  };
  startYoutubeTask = async () => {
    throw new Error("YouTube downloads are not available in this build");
  };
  pauseYoutubeTask = () => {};
}

/* ---------------- Globals ---------------- */
let db;
let mainWindow;
let isQuitting = false;

const BRIDGE_PORT = 27812;
const BRIDGE_TOKEN = "flow-download-manager-secret-change-me";

/* ================================================================
 *  Database
 * ================================================================ */
function initDB() {
  const dbPath = path.join(app.getPath("userData"), "downloads.db");
  db = new Database(dbPath);

  db.exec(`
    CREATE TABLE IF NOT EXISTS history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      filename TEXT,
      directory TEXT,
      url TEXT,
      totalSize INTEGER,
      status TEXT,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  try { db.exec(`ALTER TABLE history ADD COLUMN url TEXT;`); } catch (e) {}
  try { db.exec(`ALTER TABLE history ADD COLUMN totalSize INTEGER;`); } catch (e) {}

  // Startup reconciliation: rows still marked Downloading/Preparing have no
  // live task (we just booted). Treat them as Paused so the user can resume.
  try {
    const res = db
      .prepare(
        `UPDATE history SET status = 'Paused'
         WHERE LOWER(status) IN ('downloading','preparing')`
      )
      .run();
    if (res.changes > 0) {
      console.log(`[flow] Reconciled ${res.changes} interrupted download(s) to Paused`);
    }
  } catch (err) {
    console.warn("[flow] startup reconciliation failed:", err.message);
  }
}

/* ================================================================
 *  Window
 * ================================================================ */
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1180,
    height: 800,
    minWidth: 860,
    minHeight: 600,
    backgroundColor: "#0b0d12",
    titleBarStyle: process.platform === "darwin" ? "hiddenInset" : "default",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  mainWindow.loadFile("index.html");

  mainWindow.on("closed", () => {
    mainWindow = null;
  });

  return mainWindow;
}

/* ================================================================
 *  App lifecycle
 * ================================================================ */
app.whenReady().then(() => {
  initDB();
  startHttpBridge();
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("before-quit", async (e) => {
  if (isQuitting) return;
  isQuitting = true;
  e.preventDefault();
  try {
    await pauseAll();
  } catch (err) {
    console.error("[shutdown] pauseAll failed:", err.message);
  }
  app.exit(0);
});

/* ================================================================
 *  Utils
 * ================================================================ */
function isYouTubeUrl(url) {
  return (
    typeof url === "string" &&
    (url.includes("youtube.com") || url.includes("youtu.be"))
  );
}

async function clearLingeringTask(id) {
  try {
    const res = await Promise.race([
      cancelTask(id),
      new Promise((r) => setTimeout(() => r({ success: false, error: "timeout" }), 5000)),
    ]);
    if (res && res.success === false && res.error !== "timeout") {
      console.log(`[main] cancelTask(${id}) note:`, res.error);
    }
  } catch (err) {
    console.log(`[main] cancelTask(${id}) skipped:`, err.message);
  }
  await new Promise((r) => setTimeout(r, 80));
}

/* ================================================================
 *  IPC: clipboard / directories / files
 * ================================================================ */
ipcMain.handle("read-clipboard", () => clipboard.readText());
ipcMain.handle("get-default-directory", () => app.getPath("downloads"));

ipcMain.handle("select-directory", async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog({
    properties: ["openDirectory"],
  });
  return canceled ? null : filePaths[0];
});

ipcMain.on("open-folder", (_event, filePath) => {
  if (filePath && fs.existsSync(filePath)) shell.showItemInFolder(filePath);
});

ipcMain.handle("open-file", async (_event, filePath) => {
  if (!filePath || !fs.existsSync(filePath)) {
    return { success: false, error: "File not found" };
  }
  const err = await shell.openPath(filePath);
  return err ? { success: false, error: err } : { success: true };
});

/* ================================================================
 *  IPC: history
 * ================================================================ */
ipcMain.handle("get-history", () => {
  try {
    return db.prepare("SELECT * FROM history ORDER BY timestamp DESC").all();
  } catch (err) {
    return [];
  }
});

ipcMain.handle("delete-download", async (event, id, deleteFile) => {
  const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
  if (!item) return { success: false, error: "Item not found" };

  const st = String(item.status || "").toLowerCase();
  if (st === "downloading" || st === "preparing") {
    if (isYouTubeUrl(item.url)) {
      try { pauseYoutubeTask(id); } catch {}
    } else {
      Promise.resolve()
        .then(() => cancelTask(id))
        .catch((err) => console.warn("[main] cancelTask (delete):", err.message));
    }
    await new Promise((r) => setTimeout(r, 250));
  }

  db.prepare(`DELETE FROM history WHERE id = ?`).run(id);

  if (deleteFile) {
    try {
      if (fs.existsSync(item.directory)) fs.unlinkSync(item.directory);
      removePartialFiles(item.directory);
    } catch (err) {
      console.error("Failed to delete file:", err);
      event.sender.send("status-change");
      return {
        success: false,
        error: "Removed from history, but failed to delete physical file.",
      };
    }
  }

  event.sender.send("status-change");
  return { success: true };
});

ipcMain.handle("clear-completed", (event) => {
  try {
    const info = db
      .prepare(`DELETE FROM history WHERE LOWER(status) = 'completed'`)
      .run();
    event.sender.send("status-change");
    return { success: true, removed: info.changes };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

/* ================================================================
 *  Task completion wrapper
 *  opts.restoreOnError: status to write on failure (default 'Error').
 *                       Use 'Paused' when resuming a paused download so
 *                       the row stays in Current Downloads.
 * ================================================================ */
async function handleTaskCompletion(id, taskPromise, sender, opts = {}) {
  const out = sender && typeof sender.send === "function"
    ? sender
    : { send: () => {} };
  const errorStatus = opts.restoreOnError || "Error";

  try {
    const result = await taskPromise;
    if (!result) return;

    if (result.success) {
      db.prepare(`UPDATE history SET status = 'Completed' WHERE id = ?`).run(id);
      out.send("status-change");
    } else if (result.paused) {
      out.send("status-change");
    } else if (result.cancelled) {
      out.send("status-change");
    } else if (result.error) {
      db.prepare(`UPDATE history SET status = ? WHERE id = ?`).run(errorStatus, id);
      // Only surface the error toast when we're not silently restoring to Paused.
      if (errorStatus !== "Paused") {
        out.send("download-error", { id, message: result.error });
      } else {
        out.send("download-error", { id, message: result.error, silent: true });
      }
      out.send("status-change");
    }
  } catch (err) {
    db.prepare(`UPDATE history SET status = ? WHERE id = ?`).run(errorStatus, id);
    const message = err.message || String(err);
    if (errorStatus !== "Paused") {
      out.send("download-error", { id, message });
    } else {
      out.send("download-error", { id, message, silent: true });
    }
    out.send("status-change");
  }
}

/* ================================================================
 *  IPC: new-download
 * ================================================================ */
ipcMain.handle("new-download", async (event, { url, saveDirectory }) => {
  try {
    if (!url || typeof url !== "string") {
      return { error: "Missing or invalid URL." };
    }

    const dir = saveDirectory || app.getPath("downloads");
    const isYt = isYouTubeUrl(url);

    let fileInfo;
    if (isYt) {
      fileInfo = await prepareYoutubeDownload(url, dir);
    } else {
      fileInfo = await prepareDownload(url, dir);
    }

    const stmt = db.prepare(
      `INSERT INTO history (filename, directory, url, totalSize, status)
       VALUES (?, ?, ?, ?, ?)`
    );
    const info = stmt.run(
      fileInfo.fileName,
      fileInfo.filePath,
      url,
      fileInfo.totalSize || 0,
      "Downloading"
    );
    const dbId = info.lastInsertRowid;

    event.sender.send("download-start", { id: dbId, ...fileInfo });
    event.sender.send("status-change");

    if (isYt) {
      handleTaskCompletion(
        dbId,
        startYoutubeTask(dbId, url, fileInfo.filePath, event.sender),
        event.sender
      );
    } else {
      handleTaskCompletion(
        dbId,
        startTask(dbId, url, fileInfo.filePath, fileInfo.totalSize, event.sender),
        event.sender
      );
    }

    return { id: dbId };
  } catch (err) {
    return { error: err.message || String(err) };
  }
});

/* ================================================================
 *  IPC: pause-download
 *  Persist 'Paused' FIRST, fire the engine pause without awaiting.
 * ================================================================ */
ipcMain.handle("pause-download", async (event, id) => {
  const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
  if (!item) return { success: false, error: "Item not found" };

  const st = String(item.status || "").toLowerCase();
  if (st === "paused") return { success: true, alreadyPaused: true };
  if (st === "completed") return { success: false, error: "Download already completed" };
  if (st === "cancelled") return { success: false, error: "Download was cancelled" };

  db.prepare(`UPDATE history SET status = 'Paused' WHERE id = ?`).run(id);

  if (isYouTubeUrl(item.url)) {
    try { pauseYoutubeTask(id); } catch (err) {
      console.warn("[main] pauseYoutubeTask:", err.message);
    }
  } else {
    Promise.resolve()
      .then(() => pauseTask(id))
      .then((res) => {
        if (res && res.success === false) {
          console.warn("[main] pauseTask:", res.error);
        }
      })
      .catch((err) => console.warn("[main] pauseTask failed:", err.message));
  }

  event.sender.send("status-change");
  return { success: true };
});

/* ================================================================
 *  IPC: resume-download
 *  1) reject if already live / completed
 *  2) cancel any lingering task with this id
 *  3) mark DB 'Downloading'
 *  4) start the task; on failure restore 'Paused'
 * ================================================================ */
ipcMain.handle("resume-download", async (event, id) => {
  const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
  if (!item) return { success: false, error: "Item not found" };

  const st = String(item.status || "").toLowerCase();
  if (st === "downloading" || st === "preparing") {
    return { success: false, error: "Already downloading" };
  }
  if (st === "completed") {
    return { success: false, error: "Download already completed" };
  }

  // Free the id in the manager's registry.
  await clearLingeringTask(id);

  // Now we own the id — persist the running status.
  db.prepare(`UPDATE history SET status = 'Downloading' WHERE id = ?`).run(id);
  event.sender.send("status-change");

  let taskPromise;
  try {
    if (isYouTubeUrl(item.url)) {
      taskPromise = startYoutubeTask(id, item.url, item.directory, event.sender);
    } else {
      taskPromise = startTask(id, item.url, item.directory, item.totalSize, event.sender);
    }
  } catch (err) {
    db.prepare(`UPDATE history SET status = 'Paused' WHERE id = ?`).run(id);
    event.sender.send("status-change");
    return { success: false, error: err.message || String(err) };
  }

  // Restore 'Paused' if the resume attempt fails, so the row stays
  // in Current Downloads with a Resume button rather than vanishing.
  handleTaskCompletion(id, taskPromise, event.sender, { restoreOnError: "Paused" });

  return { success: true };
});

/* ================================================================
 *  IPC: cancel-download
 * ================================================================ */
ipcMain.handle("cancel-download", async (event, id, deletePartial = true) => {
  const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
  if (!item) return { success: false, error: "Item not found" };

  const st = String(item.status || "").toLowerCase();
  if (st === "completed") {
    return { success: false, error: "Download already completed" };
  }

  db.prepare(`UPDATE history SET status = 'Cancelled' WHERE id = ?`).run(id);

  if (isYouTubeUrl(item.url)) {
    try { pauseYoutubeTask(id); } catch {}
  } else {
    Promise.resolve()
      .then(() => cancelTask(id))
      .then((res) => {
        if (res && res.success === false) {
          console.warn("[main] cancelTask:", res.error);
        }
      })
      .catch((err) => console.warn("[main] cancelTask failed:", err.message));
  }

  if (deletePartial) {
    setTimeout(() => {
      try { removePartialFiles(item.directory); } catch {}
    }, 300);
  }

  event.sender.send("status-change");
  return { success: true };
});

/* ================================================================
 *  IPC: refresh-link
 * ================================================================ */
ipcMain.handle("refresh-link", async (event, id, newUrl) => {
  if (!newUrl || typeof newUrl !== "string") {
    return { success: false, error: "Invalid URL" };
  }

  await clearLingeringTask(id);

  db.prepare(`UPDATE history SET url = ? WHERE id = ?`).run(newUrl, id);
  const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
  if (!item) return { success: false, error: "Item not found" };

  db.prepare(`UPDATE history SET status = 'Downloading' WHERE id = ?`).run(id);
  event.sender.send("status-change");

  let taskPromise;
  try {
    if (isYouTubeUrl(item.url)) {
      taskPromise = startYoutubeTask(id, item.url, item.directory, event.sender);
    } else {
      taskPromise = startTask(id, item.url, item.directory, item.totalSize, event.sender);
    }
  } catch (err) {
    db.prepare(`UPDATE history SET status = 'Paused' WHERE id = ?`).run(id);
    event.sender.send("status-change");
    return { success: false, error: err.message || String(err) };
  }

  handleTaskCompletion(id, taskPromise, event.sender, { restoreOnError: "Paused" });
  return { success: true };
});

/* ================================================================
 *  Bring app window to front (Linux-friendly)
 * ================================================================ */
function bringToFront() {
  if (!mainWindow || mainWindow.isDestroyed()) {
    console.warn("[focus] no main window to raise");
    return;
  }

  try {
    if (mainWindow.isMinimized()) mainWindow.restore();
    if (!mainWindow.isVisible()) mainWindow.show();

    mainWindow.setAlwaysOnTop(true, "floating");
    mainWindow.focus();
    mainWindow.moveTop();
    mainWindow.flashFrame(true);

    if (process.platform === "linux" && process.env.DISPLAY) {
      exec(
        `xdotool search --name "Flow" windowactivate --sync %@ 2>/dev/null || true`,
        () => {}
      );
    }

    setTimeout(() => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.setAlwaysOnTop(false);
        mainWindow.flashFrame(false);
      }
    }, 700);
  } catch (err) {
    console.warn("[focus] failed:", err.message);
  }
}

/* ================================================================
 *  HTTP Bridge for browser extension
 * ================================================================ */
function startHttpBridge() {
  const server = http.createServer((req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-Flow-Token");

    console.log(`[http-bridge] ${req.method} ${req.url}`);

    if (req.method === "OPTIONS") {
      res.writeHead(204);
      return res.end();
    }

    if (req.method === "GET" && req.url === "/health") {
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ ok: true, app: "flow" }));
    }

    if (req.method !== "POST" || req.url !== "/download") {
      res.writeHead(404, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ error: "Not found" }));
    }

    const token = req.headers["x-flow-token"];
    if (token !== BRIDGE_TOKEN) {
      console.warn("[http-bridge] Rejecting request: bad or missing token");
      res.writeHead(403, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ error: "Forbidden — token mismatch" }));
    }

    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 5 * 1024 * 1024) req.destroy();
    });
    req.on("end", async () => {
      try {
        const parsed = JSON.parse(body);
        console.log("[http-bridge] Payload:", {
          url: parsed.url,
          cookiesLen: (parsed.cookies || "").length,
          referrer: parsed.referrer,
        });

        const result = await handleBridgeDownload(parsed);

        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify(result));
      } catch (err) {
        console.error("[http-bridge] Handler error:", err.message);
        res.writeHead(400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ success: false, error: err.message }));
      }
    });
  });

  server.on("error", (err) => {
    console.error("[http-bridge] Server error:", err.message);
    if (err.code === "EADDRINUSE") {
      console.error(
        `[http-bridge] Port ${BRIDGE_PORT} already in use. Kill the other process or change the port.`
      );
    }
  });

  server.listen(BRIDGE_PORT, "127.0.0.1", () => {
    console.log(`[http-bridge] Listening on http://127.0.0.1:${BRIDGE_PORT}`);
  });
}

/* ================================================================
 *  Bridge download handler
 * ================================================================ */
async function handleBridgeDownload({ url, cookies, referrer, filename }) {
  if (!url || typeof url !== "string") {
    throw new Error("Missing or invalid 'url' in payload.");
  }

  console.log("[bridge] handleBridgeDownload start for", url);

  bringToFront();

  const dir = app.getPath("downloads");
  const extraHeaders = {};
  if (cookies) extraHeaders["Cookie"] = String(cookies).slice(0, 8000);
  if (referrer) extraHeaders["Referer"] = referrer;
  if (filename) extraHeaders["X-Flow-Filename-Hint"] = filename;

  let fileInfo;
  try {
    fileInfo = await prepareDownload(url, dir, extraHeaders);
    console.log("[bridge] prepareDownload OK:", fileInfo);
  } catch (err) {
    console.error("[bridge] prepareDownload FAILED:", err.message);

    if (mainWindow && !mainWindow.isDestroyed()) {
      try {
        mainWindow.webContents.send("download-error", {
          id: -1,
          message: `Could not start captured download: ${err.message}`,
        });
      } catch {}
    }

    throw err;
  }

  const stmt = db.prepare(
    `INSERT INTO history (filename, directory, url, totalSize, status)
     VALUES (?, ?, ?, ?, ?)`
  );
  const info = stmt.run(
    fileInfo.fileName,
    fileInfo.filePath,
    url,
    fileInfo.totalSize || 0,
    "Downloading"
  );
  const dbId = info.lastInsertRowid;
  console.log("[bridge] Inserted history row id =", dbId);

  const sender =
    mainWindow && !mainWindow.isDestroyed() && mainWindow.webContents
      ? mainWindow.webContents
      : { send: () => {} };

  try {
    sender.send("download-start", { id: dbId, ...fileInfo });
    sender.send("status-change");
  } catch (e) {
    console.warn("[bridge] Could not notify renderer:", e.message);
  }

  handleTaskCompletion(
    dbId,
    startTask(dbId, url, fileInfo.filePath, fileInfo.totalSize, sender, extraHeaders),
    sender
  );

  return { success: true, id: dbId, filename: fileInfo.fileName };
}