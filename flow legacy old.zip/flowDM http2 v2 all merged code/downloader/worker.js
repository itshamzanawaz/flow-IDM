/* ================================================================
 *  Flow — download worker (v2.1)
 *  - HTTP/2 first, HTTPS/1.1 fallback
 *  - keep-alive agents, 1 MB write buffer
 *  - Work-stealing: receives chunks from main, loops until told to stop
 *  - In-worker retry with exponential backoff
 *  - Progress reported from fs.WriteStream.bytesWritten
 *
 *  v2.1 fixes:
 *   • On abort, exit promptly so pause/cancel finalize without waiting
 *     for the main process's FORCE_KILL_MS hard-kill timer.
 *   • Always close the h2 session on exit paths.
 * ================================================================ */

const { workerData, parentPort } = require("worker_threads");
const fs = require("fs");
const https = require("https");
const http = require("http");
const http2 = require("http2");
const { pipeline } = require("stream/promises");
const { Transform } = require("stream");

const {
  url,
  headers: extraHeaders = {},
  tempFilePath,
  workerId,
  maxAttempts = 3,
} = workerData;

const USER_AGENT =
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

/* ---------------- Keep-alive agents ---------------- */
const httpsAgent = new https.Agent({
  keepAlive: true,
  keepAliveMsecs: 30000,
  maxSockets: 16,
  maxFreeSockets: 4,
});

const httpAgent = new http.Agent({
  keepAlive: true,
  keepAliveMsecs: 30000,
  maxSockets: 16,
  maxFreeSockets: 4,
});

/* ---------------- HTTP/2 session (lazy) ---------------- */
let h2Session = null;
let h2Status = "unknown"; // "unknown" | "ok" | "unsupported"

/* ---------------- Current request state ---------------- */
let currentStream = null;
let currentWriteStream = null;
let isShuttingDown = false;

/* ---------------- Helpers ---------------- */
function post(msg) { parentPort.postMessage(msg); }
function log(text) { post({ type: "worker_log", text }); }
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

function urlScheme(u) { return new URL(u).protocol.replace(":", ""); }

function closeH2() {
  try { if (h2Session) h2Session.close(); } catch {}
  h2Session = null;
}

/* ---------------- HTTP/2 session --------------- */
async function tryGetH2Session() {
  if (h2Status === "unsupported") return null;
  if (h2Session && !h2Session.closed && !h2Session.destroyed) return h2Session;

  const origin = new URL(url).origin;

  return new Promise((resolve, reject) => {
    let session;
    try {
      session = http2.connect(origin);
    } catch (err) {
      h2Status = "unsupported";
      return reject(err);
    }

    const timer = setTimeout(() => {
      try { session.destroy(); } catch {}
      h2Status = "unsupported";
      reject(new Error("HTTP/2 connect timeout"));
    }, 6000);

    session.once("connect", () => {
      clearTimeout(timer);
      h2Session = session;
      h2Status = "ok";
      log("HTTP/2 session established");
      resolve(session);
    });

    session.once("error", (err) => {
      clearTimeout(timer);
      h2Status = "unsupported";
      try { session.destroy(); } catch {}
      reject(err);
    });

    session.once("close", () => {
      if (h2Session === session) h2Session = null;
    });
  });
}

function openH2Stream(session, start, end) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const reqHeaders = {
      ":method": "GET",
      ":path": u.pathname + u.search,
      ":authority": u.host,
      ":scheme": "https",
      "range": `bytes=${start}-${end}`,
      "accept-encoding": "identity",
      "user-agent": USER_AGENT,
    };
    // Merge caller headers (lowercased for h2)
    for (const k of Object.keys(extraHeaders)) {
      reqHeaders[k.toLowerCase()] = extraHeaders[k];
    }

    let req;
    try {
      req = session.request(reqHeaders);
    } catch (err) {
      return reject(err);
    }

    let responded = false;

    req.once("response", (h) => {
      responded = true;
      resolve({
        status: parseInt(h[":status"], 10),
        headers: h,
        stream: req,
      });
    });

    req.once("error", (err) => {
      if (!responded) reject(err);
    });

    req.end();
  });
}

/* ---------------- HTTPS / HTTP fallback ---------------- */
function openHttpsStream(start, end) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const isHttps = u.protocol === "https:";
    const mod = isHttps ? https : http;
    const reqHeaders = {
      "range": `bytes=${start}-${end}`,
      "accept-encoding": "identity",
      "user-agent": USER_AGENT,
      "connection": "keep-alive",
    };
    for (const k of Object.keys(extraHeaders)) reqHeaders[k.toLowerCase()] = extraHeaders[k];

    const req = mod.request({
      method: "GET",
      hostname: u.hostname,
      port: u.port || (isHttps ? 443 : 80),
      path: u.pathname + u.search,
      headers: reqHeaders,
      agent: isHttps ? httpsAgent : httpAgent,
    }, (res) => {
      resolve({
        status: res.statusCode,
        headers: res.headers,
        stream: res,
      });
    });

    req.once("error", reject);
    req.end();
  });
}

async function openStream(start, end) {
  const scheme = urlScheme(url);

  if (scheme === "https" && h2Status !== "unsupported") {
    try {
      const session = await tryGetH2Session();
      if (session) return await openH2Stream(session, start, end);
    } catch (err) {
      log(`h2 open failed (${err.message}) — falling back to h1`);
      h2Status = "unsupported";
    }
  }

  return await openHttpsStream(start, end);
}

/* ---------------- Response validation --------------- */
function validateResponse(resp, start, expectedBytes) {
  if (resp.status === 401 || resp.status === 403) {
    throw new Error(`HTTP ${resp.status} — link expired or auth required`);
  }
  if (resp.status === 404) throw new Error("HTTP 404 — file not found");
  if (resp.status >= 500) throw new Error(`HTTP ${resp.status} — server error`);
  if (resp.status !== 200 && resp.status !== 206) {
    throw new Error(`Unexpected HTTP ${resp.status}`);
  }
  if (resp.status !== 206 && start > 0) {
    throw new Error(`Server ignored Range (status ${resp.status})`);
  }
  const ct = String(resp.headers["content-type"] || "").toLowerCase();
  if (ct.includes("text/html") && expectedBytes > 100 * 1024) {
    throw new Error("Server returned HTML error page");
  }
}

/* ---------------- Single range download ---------------
 * Returns the number of bytes actually written to disk.
 * ----------------------------------------------------- */
async function downloadRange(start, end, chunkId, totalBytesForChunk, alreadyWritten) {
  const remaining = end - start + 1;
  if (remaining <= 0) return 0;

  const resp = await openStream(start, end);
  try {
    validateResponse(resp, start, remaining);
  } catch (err) {
    try { resp.stream.destroy(); } catch {}
    throw err;
  }

  // Byte-limiting transform: refuse to write more than `remaining` bytes
  let bytesPassedThrough = 0;
  const limiter = new Transform({
    transform(chunk, _enc, cb) {
      const space = remaining - bytesPassedThrough;
      if (space <= 0) return cb();
      if (chunk.length <= space) {
        bytesPassedThrough += chunk.length;
        return cb(null, chunk);
      }
      bytesPassedThrough += space;
      cb(null, chunk.slice(0, space));
    },
  });

  const ws = fs.createWriteStream(tempFilePath, {
    flags: "r+",
    start,
    highWaterMark: 1024 * 1024,
  });

  currentWriteStream = ws;

  let lastFlushed = 0;
  const progressTimer = setInterval(() => {
    const flushed = ws.bytesWritten;
    if (flushed > lastFlushed) {
      const delta = flushed - lastFlushed;
      lastFlushed = flushed;
      post({ type: "progress", chunkId, bytes: delta });
    }
  }, 250);

  try {
    await pipeline(resp.stream, limiter, ws);

    const flushed = ws.bytesWritten;
    if (flushed > lastFlushed) {
      post({ type: "progress", chunkId, bytes: flushed - lastFlushed });
      lastFlushed = flushed;
    }
    return flushed;
  } catch (err) {
    const flushed = ws.bytesWritten || 0;
    if (flushed > lastFlushed) {
      post({ type: "progress", chunkId, bytes: flushed - lastFlushed });
      lastFlushed = flushed;
    }
    throw err;
  } finally {
    clearInterval(progressTimer);
    currentWriteStream = null;
  }
}

/* ---------------- Chunk download with retries --------------- */
async function downloadChunk(chunk) {
  const { id: chunkId, start, end } = chunk;
  const totalBytes = end - start + 1;
  let downloaded = chunk.downloaded || 0;

  let lastErr = null;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    if (isShuttingDown) throw new Error("aborted");

    const offset = start + downloaded;
    const remaining = end - offset + 1;
    if (remaining <= 0) return;

    let written = 0;
    try {
      written = await downloadRange(offset, end, chunkId, totalBytes, downloaded);
    } catch (err) {
      if (isShuttingDown || err.message === "aborted") throw new Error("aborted");
      lastErr = err;
      log(`chunk ${chunkId} attempt ${attempt} failed: ${err.message}`);
      // Non-retryable conditions
      if (/expired|404|ignored Range|HTML/.test(err.message)) throw err;
      if (attempt < maxAttempts) await sleep(500 * attempt);
      continue;
    }

    downloaded += written;
    if (downloaded >= totalBytes) return;

    log(`chunk ${chunkId} attempt ${attempt}: got ${downloaded}/${totalBytes}, retrying`);
    if (attempt < maxAttempts) await sleep(400 * attempt);
  }

  throw lastErr || new Error(`Chunk ${chunkId} failed after ${maxAttempts} attempts`);
}

/* ---------------- Message loop --------------- */
parentPort.on("message", async (msg) => {
  if (!msg) return;

  if (msg.type === "abort") {
    isShuttingDown = true;
    // v2.1 fix: kill any in-flight write so pipeline unwinds immediately.
    try { if (currentWriteStream) currentWriteStream.destroy(); } catch {}
    // If we're between chunks, there's nothing in flight — exit now so the
    // main process can finalize pause/cancel without waiting for the
    // FORCE_KILL_MS hard-kill timer.
    if (!currentWriteStream) {
      closeH2();
      process.exit(0);
    }
    return;
  }

  if (msg.type === "chunk") {
    try {
      await downloadChunk(msg.chunk);
      post({ type: "chunk_done", chunkId: msg.chunk.id });
    } catch (err) {
      if (err.message === "aborted" || isShuttingDown) {
        // Silent exit — main process is closing us down.
        closeH2();
        process.exit(0);
      }
      post({ type: "chunk_failed", chunkId: msg.chunk.id, error: err.message || String(err) });
    }
    return;
  }

  if (msg.type === "no_more_chunks") {
    // Clean shutdown
    closeH2();
    post({ type: "worker_done" });
    setImmediate(() => process.exit(0));
    return;
  }
});

/* ---------------- Safety: uncaught exceptions --------------- */
process.on("uncaughtException", (err) => {
  log(`uncaught exception: ${err.message}`);
  post({ type: "chunk_failed", chunkId: -1, error: err.message });
  process.exit(1);
});