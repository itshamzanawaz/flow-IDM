/* ================================================================
 *  Flow — download engine (v2.1)
 *  - Work-stealing chunk queue (small dynamic chunks)
 *  - Adaptive worker count (2–20) based on file size
 *  - Robust URL probe (HEAD → GET+Range fallback)
 *  - Filename sanitization + collision handling
 *  - Per-file locks
 *  - Chunk-level retry at both main and worker level
 *  - HTTP/2 negotiation done inside worker
 *  - Atomic state writes, corrupted-state detection
 *  - Cross-device rename fallback
 *
 *  v2.1 fixes:
 *   • maybeFinalize no longer requires pendingChunks to be empty —
 *     user-requested pause/cancel always wins and finalizes cleanly.
 *   • assignNextChunk refuses to hand out work when state != downloading.
 *   • spawnWorker only kicks off if a download is actively running.
 *   • pauseTask / cancelTask finalize immediately when possible and
 *     never leave a stale force-kill timer behind.
 * ================================================================ */

const axios = require("axios");
const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");
const { Worker } = require("worker_threads");

/* ---------------- Config ---------------- */
const MAX_THREADS = 20;
const MIN_CHUNK_SIZE = 1 * 1024 * 1024;         // 1 MB
const MAX_CHUNK_SIZE = 8 * 1024 * 1024;         // 8 MB
const CHUNKS_PER_WORKER = 4;                    // target ratio for stealing
const STALL_TIMEOUT_MS = 45000;
const WATCHDOG_INTERVAL_MS = 5000;
const FORCE_KILL_MS = 3000;
const MAX_CHUNK_ATTEMPTS = 2;                   // main-level requeues
const PROGRESS_THROTTLE_MS = 100;
const PROBE_TIMEOUT_MS = 20000;
const MB = 1024 * 1024;
const GB = 1024 * MB;
const STATE_VERSION = 2;

/* ---------------- Global state ---------------- */
const tasks = new Map();
const fileLocks = new Map();

/* ================================================================
 *  Adaptive sizing
 * ================================================================ */
function computeWorkerCount(totalSize) {
  let desired;
  if (totalSize < 10 * MB)         desired = 2;
  else if (totalSize < 100 * MB)   desired = 4;
  else if (totalSize < 500 * MB)   desired = 8;
  else if (totalSize < 2 * GB)     desired = 12;
  else if (totalSize < 5 * GB)     desired = 16;
  else                             desired = MAX_THREADS;
  const maxBySize = Math.max(1, Math.floor(totalSize / (2 * MB)));
  return Math.max(1, Math.min(desired, maxBySize, MAX_THREADS));
}

function computeChunkSize(totalSize, workers) {
  const targetChunks = Math.max(1, workers * CHUNKS_PER_WORKER);
  const ideal = totalSize / targetChunks;
  const size = Math.max(MIN_CHUNK_SIZE, Math.min(MAX_CHUNK_SIZE, Math.ceil(ideal)));
  return size;
}

/* ================================================================
 *  Utility
 * ================================================================ */
function safeFilename(name) {
  if (!name || typeof name !== "string") return "download.bin";
  let n = name
    .replace(/[\x00-\x1f\x7f]/g, "")
    .replace(/[\\/:*?"<>|]/g, "_")
    .replace(/^[\s.]+|[\s.]+$/g, "");
  const base = n.split(".")[0].toUpperCase();
  const reserved = ["CON","PRN","AUX","NUL","COM1","COM2","COM3","COM4","COM5","COM6","COM7","COM8","COM9","LPT1","LPT2","LPT3","LPT4","LPT5","LPT6","LPT7","LPT8","LPT9"];
  if (reserved.includes(base)) n = "_" + n;
  if (n.length > 200) {
    const ext = path.extname(n).slice(0, 20);
    n = n.slice(0, 200 - ext.length) + ext;
  }
  return n || "download.bin";
}

function parseFilename(disposition, finalUrl) {
  if (disposition && typeof disposition === "string") {
    const rfc = disposition.match(/filename\*\s*=\s*([^']+)'[^']*'([^;]+)/i);
    if (rfc) {
      try { return safeFilename(decodeURIComponent(rfc[2].trim())); } catch {}
    }
    const plain = disposition.match(/filename\s*=\s*(?:"([^"]*)"|([^;]+))/i);
    if (plain) {
      const val = (plain[1] || plain[2] || "").trim();
      if (val) return safeFilename(val);
    }
  }
  try {
    const u = new URL(finalUrl);
    const base = path.basename(u.pathname);
    if (base) return safeFilename(decodeURIComponent(base));
  } catch {}
  return "download.bin";
}

function uniquePath(dir, filename) {
  const full = path.join(dir, filename);
  const exists = (p) => fs.existsSync(p) || fs.existsSync(p + ".fastdl");
  if (!exists(full)) return full;
  const ext = path.extname(filename);
  const base = filename.slice(0, filename.length - ext.length);
  for (let i = 1; i < 1000; i++) {
    const candidate = path.join(dir, `${base} (${i})${ext}`);
    if (!exists(candidate)) return candidate;
  }
  return path.join(dir, `${base}-${Date.now()}${ext}`);
}

async function renameCrossDevice(oldPath, newPath) {
  try {
    await fsp.rename(oldPath, newPath);
    return;
  } catch (err) {
    if (err.code !== "EXDEV") throw err;
  }
  await fsp.copyFile(oldPath, newPath);
  try { await fsp.unlink(oldPath); } catch {}
}

async function renameWithRetry(oldPath, newPath, retries = 5) {
  let lastErr = null;
  for (let i = 0; i < retries; i++) {
    try {
      await renameCrossDevice(oldPath, newPath);
      return;
    } catch (err) {
      lastErr = err;
      await new Promise((r) => setTimeout(r, 400 * (i + 1)));
    }
  }
  throw lastErr;
}

function atomicWriteJson(filePath, obj) {
  const tmp = filePath + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(obj));
  fs.renameSync(tmp, filePath);
}

function persistState(task) {
  try {
    atomicWriteJson(task.statePath, {
      version: STATE_VERSION,
      url: task.url,
      totalSize: task.totalSize,
      chunkSize: task.chunkSize,
      chunks: task.chunks.map((c) => ({
        id: c.id, start: c.start, end: c.end, downloaded: c.downloaded,
      })),
    });
    task.lastSave = Date.now();
  } catch (err) {
    console.error("[downloadManager] state write failed:", err.message);
  }
}

function buildChunkLayout(totalSize, chunkSize) {
  const chunks = [];
  let start = 0;
  let id = 0;
  while (start < totalSize) {
    const end = Math.min(start + chunkSize - 1, totalSize - 1);
    chunks.push({
      id, start, end, downloaded: 0,
      state: "pending",      // pending | claimed | done | failed
      workerId: null,
      attempts: 0,
    });
    start = end + 1;
    id++;
  }
  return chunks;
}

function isValidState(state, totalSize) {
  if (!state || typeof state !== "object") return false;
  if (state.version !== STATE_VERSION) return false;
  if (state.totalSize !== totalSize) return false;
  if (!Array.isArray(state.chunks) || state.chunks.length === 0) return false;
  let sum = 0;
  for (const c of state.chunks) {
    if (!Number.isFinite(c.start) || !Number.isFinite(c.end) || !Number.isFinite(c.downloaded)) return false;
    if (c.end < c.start) return false;
    if (c.downloaded < 0 || c.downloaded > c.end - c.start + 1) return false;
    sum += (c.end - c.start + 1);
  }
  return sum === totalSize;
}

/* ================================================================
 *  prepareDownload
 * ================================================================ */
async function prepareDownload(url, saveDirectory, extraHeaders = {}) {
  if (!url || typeof url !== "string") throw new Error("Invalid URL");
  try { new URL(url); } catch { throw new Error("Malformed URL"); }

  try { await fsp.mkdir(saveDirectory, { recursive: true }); }
  catch (err) { throw new Error(`Cannot access save directory: ${err.message}`); }

  let totalSize = null;
  let acceptRanges = null;
  let disposition = null;
  let finalUrl = url;

  /* ---- HEAD ---- */
  let headFailed = false;
  try {
    const res = await axios.head(url, {
      timeout: PROBE_TIMEOUT_MS,
      maxRedirects: 10,
      headers: extraHeaders,
      validateStatus: () => true,
    });
    if (res.status >= 200 && res.status < 300) {
      acceptRanges = res.headers["accept-ranges"];
      const len = parseInt(res.headers["content-length"], 10);
      if (Number.isFinite(len) && len > 0) totalSize = len;
      disposition = res.headers["content-disposition"];
      finalUrl = res.request?.res?.responseUrl || url;
    } else if (res.status === 404) {
      throw new Error("File not found (HTTP 404).");
    } else {
      headFailed = true;
    }
  } catch (err) {
    if (err.code === "ENOTFOUND") throw new Error("Host not found. Check your connection.");
    if (err.code === "ECONNREFUSED") throw new Error("Connection refused by server.");
    if (err.message && err.message.includes("HTTP 404")) throw err;
    headFailed = true;
  }

  /* ---- GET+Range fallback ---- */
  if (headFailed || !totalSize || !acceptRanges || acceptRanges === "none") {
    let probe;
    try {
      probe = await axios.get(url, {
        timeout: PROBE_TIMEOUT_MS,
        maxRedirects: 10,
        headers: { ...extraHeaders, Range: "bytes=0-0", "Accept-Encoding": "identity" },
        responseType: "stream",
        validateStatus: () => true,
      });
    } catch (err) {
      throw new Error(`Could not reach server: ${err.message}`);
    }
    try { probe.data.destroy(); } catch {}

    if (probe.status === 401 || probe.status === 403) {
      throw new Error(`Server rejected the request (HTTP ${probe.status}). The link may have expired or require authentication.`);
    }
    if (probe.status === 404) throw new Error("File not found (HTTP 404).");
    if (probe.status >= 400) throw new Error(`Server error (HTTP ${probe.status}).`);

    const contentRange = probe.headers["content-range"];
    if (contentRange) {
      const m = contentRange.match(/bytes\s+\d+-\d+\/(\d+)/i);
      if (m) totalSize = parseInt(m[1], 10);
      acceptRanges = "bytes";
    }
    if (!totalSize) {
      const len = parseInt(probe.headers["content-length"], 10);
      if (Number.isFinite(len) && len > 0 && probe.status === 200) totalSize = len;
    }
    if (!disposition) disposition = probe.headers["content-disposition"];
    if (!acceptRanges) acceptRanges = probe.headers["accept-ranges"];
    finalUrl = probe.request?.res?.responseUrl || url;
  }

  if (!acceptRanges || acceptRanges === "none") {
    throw new Error("Server does not support resumable downloads (no Range support).");
  }
  if (!Number.isFinite(totalSize) || totalSize <= 0) {
    throw new Error("Could not determine file size from the server.");
  }

  /* ---- Disk space ---- */
  try {
    if (typeof fsp.statfs === "function") {
      const stats = await fsp.statfs(saveDirectory);
      const freeBytes = Number(stats.bavail) * Number(stats.bsize);
      if (freeBytes > 0 && freeBytes < totalSize * 1.1) {
        const need = (totalSize / 1e9).toFixed(2);
        const free = (freeBytes / 1e9).toFixed(2);
        throw new Error(`Not enough disk space. Need ~${need} GB, only ${free} GB free.`);
      }
    }
  } catch (err) {
    if (err.message && err.message.includes("disk space")) throw err;
  }

  const rawName = parseFilename(disposition, finalUrl);
  const filePath = uniquePath(saveDirectory, rawName);
  const fileName = path.basename(filePath);

  const workers = computeWorkerCount(totalSize);
  const chunkSize = computeChunkSize(totalSize, workers);
  const chunks = Math.ceil(totalSize / chunkSize);
  console.log(`[prepareDownload] size=${(totalSize/MB).toFixed(1)}MB ranges=${acceptRanges} workers=${workers} chunkSize=${(chunkSize/MB).toFixed(1)}MB chunks=${chunks} name="${fileName}"`);

  return { fileName, filePath, totalSize };
}

/* ================================================================
 *  startTask
 * ================================================================ */
function startTask(id, url, filePath, totalSize, sender, extraHeaders = {}) {
  const lockedBy = fileLocks.get(filePath);
  if (lockedBy !== undefined && lockedBy !== id) {
    return Promise.reject(new Error("Another download is already writing to this file."));
  }
  fileLocks.set(filePath, id);

  const existing = tasks.get(id);
  if (existing && existing.state !== "finalized") {
    fileLocks.delete(filePath);
    return Promise.reject(new Error("A download is already running with this id."));
  }

  const statePath = filePath + ".fastdl";
  const tempFilePath = filePath + ".download";

  const workerCount = computeWorkerCount(totalSize);
  const chunkSize = computeChunkSize(totalSize, workerCount);

  let chunks = null;
  const resuming = fs.existsSync(statePath) && fs.existsSync(tempFilePath);
  if (resuming) {
    try {
      const parsed = JSON.parse(fs.readFileSync(statePath, "utf8"));
      if (isValidState(parsed, totalSize) && (!parsed.url || parsed.url === url)) {
        chunks = parsed.chunks.map((c) => ({
          ...c,
          state: c.downloaded >= (c.end - c.start + 1) ? "done" : "pending",
          workerId: null,
          attempts: 0,
        }));
        console.log(`[downloadManager id=${id}] resuming: ${chunks.filter(c=>c.state==="done").length}/${chunks.length} chunks complete`);
      } else {
        console.warn(`[downloadManager id=${id}] state file invalid or incompatible — restarting`);
      }
    } catch (err) {
      console.warn("[downloadManager] discarding corrupted state file:", err.message);
    }
  }

  if (!chunks) {
    try {
      const fd = fs.openSync(tempFilePath, "w");
      try { fs.ftruncateSync(fd, totalSize); } finally { fs.closeSync(fd); }
    } catch (err) {
      fileLocks.delete(filePath);
      return Promise.reject(new Error(`Cannot create temp file: ${err.message}`));
    }
    chunks = buildChunkLayout(totalSize, chunkSize);
    console.log(`[downloadManager id=${id}] starting fresh: ${chunks.length} chunks, ${workerCount} workers`);
  }

  const task = {
    id, url, filePath, statePath, tempFilePath,
    totalSize, chunkSize, chunks,
    workersTotal: Math.min(workerCount, chunks.length),
    state: "downloading",
    pendingAction: null,
    workers: new Map(),                    // workerId -> { worker, currentChunkId, alive }
    pendingChunks: [],                     // queue of chunk IDs to assign
    finishedChunks: new Set(),             // chunk IDs fully downloaded
    totalDownloaded: chunks.reduce((a, c) => a + c.downloaded, 0),
    initialDownloaded: 0,
    firstError: null,
    watchdog: null,
    forceKillTimer: null,
    lastSave: 0,
    lastProgressSent: 0,
    startTime: Date.now(),
    resolveTask: null,
    _pauseResolve: null,
    _cancelResolve: null,
    finalized: false,
    _maybeFinalize: null,
    extraHeaders,
  };
  task.initialDownloaded = task.totalDownloaded;
  tasks.set(id, task);

  // Build initial pending queue
  for (const c of chunks) {
    if (c.state === "pending") task.pendingChunks.push(c.id);
    else if (c.state === "done") task.finishedChunks.add(c.id);
  }

  const saveStateThrottled = () => {
    if (Date.now() - task.lastSave > 1000) persistState(task);
  };

  const clearTimers = () => {
    if (task.watchdog) { clearInterval(task.watchdog); task.watchdog = null; }
    if (task.forceKillTimer) { clearTimeout(task.forceKillTimer); task.forceKillTimer = null; }
  };
  const terminateAllWorkers = () => {
    for (const w of task.workers.values()) { try { w.worker.terminate(); } catch {} }
    task.workers.clear();
  };

  const activeWorkerCount = () => {
    let n = 0;
    for (const w of task.workers.values()) if (w.alive) n++;
    return n;
  };

  /* ---- Finalizers ---- */
  const finalizeSuccess = async () => {
    if (task.finalized) return;
    task.finalized = true;
    task.state = "finalized";
    clearTimers();
    terminateAllWorkers();
    tasks.delete(id);
    fileLocks.delete(filePath);

    try {
      if (task.finishedChunks.size !== chunks.length) {
        throw new Error("Cannot finalize: not all chunks are complete.");
      }
      try { if (fs.existsSync(statePath)) fs.unlinkSync(statePath); } catch {}
      await renameWithRetry(tempFilePath, filePath);
      task.resolveTask?.({ success: true, filePath });
      task._pauseResolve?.({ success: false, error: "Download completed" });
      task._cancelResolve?.({ success: false, error: "Download completed" });
    } catch (err) {
      task.resolveTask?.({ success: false, error: "Finalization failed: " + err.message });
      task._pauseResolve?.({ success: false, error: "Finalization failed" });
      task._cancelResolve?.({ success: false, error: "Finalization failed" });
    }
    task._pauseResolve = null;
    task._cancelResolve = null;
  };

  const finalizePause = () => {
    if (task.finalized) return;
    task.finalized = true;
    task.state = "finalized";
    clearTimers();
    terminateAllWorkers();
    persistState(task);
    tasks.delete(id);
    fileLocks.delete(filePath);

    task.resolveTask?.({ success: false, paused: true });
    task._pauseResolve?.({ success: true });
    task._cancelResolve?.({ success: false, error: "Paused instead of cancelled" });
    task._pauseResolve = null;
    task._cancelResolve = null;
  };

  const finalizeCancel = () => {
    if (task.finalized) return;
    task.finalized = true;
    task.state = "finalized";
    clearTimers();
    terminateAllWorkers();
    tasks.delete(id);
    fileLocks.delete(filePath);

    task.resolveTask?.({ success: false, cancelled: true });
    task._cancelResolve?.({ success: true });
    task._pauseResolve?.({ success: false, error: "Cancelled instead of paused" });
    task._pauseResolve = null;
    task._cancelResolve = null;
  };

  const finalizeFailure = (message) => {
    if (task.finalized) return;
    task.finalized = true;
    task.state = "finalized";
    clearTimers();
    terminateAllWorkers();
    persistState(task);
    tasks.delete(id);
    fileLocks.delete(filePath);

    task.resolveTask?.({ success: false, error: message });
    task._pauseResolve?.({ success: false, error: message });
    task._cancelResolve?.({ success: false, error: message });
    task._pauseResolve = null;
    task._cancelResolve = null;
  };

  /* ---- Finalize decision (v2.1 fix) ----
   * Priority order:
   *   1. Everything on disk → success
   *   2. Workers still alive → wait
   *   3. User-requested pause/cancel wins, even with chunks still queued
   *   4. First error, or nothing left to do → failure
   * ------------------------------------------------------- */
  const maybeFinalize = () => {
    if (task.finalized) return;

    // 1. All chunks done → success
    if (task.finishedChunks.size === chunks.length) {
      return finalizeSuccess();
    }

    // 2. Wait for workers to actually stop before tearing down.
    if (activeWorkerCount() > 0) return;

    // 3. Pause / cancel take precedence over any pending chunks.
    if (task.pendingAction === "cancel") return finalizeCancel();
    if (task.pendingAction === "pause")  return finalizePause();

    // 4. Nothing left to do and no user action → fail.
    if (task.firstError) return finalizeFailure(task.firstError);
    return finalizeFailure("All workers stopped before chunks were complete");
  };
  task._maybeFinalize = maybeFinalize;

  /* ---- Progress ---- */
  const emitProgress = () => {
    if (!sender || task.state !== "downloading") return;
    const now = Date.now();
    if (now - task.lastProgressSent < PROGRESS_THROTTLE_MS) return;
    task.lastProgressSent = now;

    const elapsed = (now - task.startTime) / 1000;
    const sessionBytes = task.totalDownloaded - task.initialDownloaded;
    const speedBps = elapsed > 0 ? sessionBytes / elapsed : 0;
    const speedMBps = (speedBps / MB).toFixed(2);

    let percent = task.totalSize > 0 ? (task.totalDownloaded / task.totalSize) * 100 : 0;
    if (percent > 100) percent = 100;
    if (percent >= 100 && task.finishedChunks.size < chunks.length) percent = 99.9;

    const remaining = Math.max(0, task.totalSize - task.totalDownloaded);
    const etaSeconds = speedBps > 0 ? Math.round(remaining / speedBps) : 0;

    try {
      sender.send("download-progress", {
        id: task.id,
        percent: percent.toFixed(1),
        speedMBps,
        etaSeconds,
        downloaded: task.totalDownloaded,
        totalSize: task.totalSize,
      });
    } catch {}
  };

  /* ---- Watchdog ---- */
  task.watchdog = setInterval(() => {
    if (task.state !== "downloading") return;
    const now = Date.now();
    const stalled = task.chunks.some(
      (c) => c.state === "claimed" &&
             now - (c.lastActivity || 0) > STALL_TIMEOUT_MS
    );
    if (!stalled) return;

    task.firstError = "Network stalled: no data received for over 45 seconds.";
    for (const w of task.workers.values()) {
      try { w.worker.postMessage({ type: "abort" }); } catch {}
    }
    if (task.forceKillTimer) { clearTimeout(task.forceKillTimer); }
    task.forceKillTimer = setTimeout(() => {
      terminateAllWorkers();
      maybeFinalize();
    }, FORCE_KILL_MS);
  }, WATCHDOG_INTERVAL_MS);

  /* ---- Assign next chunk to a worker ---- */
  const assignNextChunk = (workerEntry) => {
    // v2.1 fix: refuse to hand out work unless we're actively downloading.
    if (task.state !== "downloading") {
      workerEntry.currentChunkId = null;
      try { workerEntry.worker.postMessage({ type: "no_more_chunks" }); } catch {}
      return false;
    }
    while (task.pendingChunks.length > 0) {
      const chunkId = task.pendingChunks.shift();
      const chunk = task.chunks[chunkId];
      if (chunk.state === "done") continue;
      chunk.state = "claimed";
      chunk.workerId = workerEntry.id;
      chunk.lastActivity = Date.now();
      workerEntry.currentChunkId = chunkId;
      try {
        workerEntry.worker.postMessage({ type: "chunk", chunk });
      } catch (err) {
        console.error(`[downloadManager id=${id}] failed to send chunk to worker ${workerEntry.id}:`, err.message);
        chunk.state = "pending";
        task.pendingChunks.unshift(chunkId);
        return false;
      }
      return true;
    }
    // No more chunks
    workerEntry.currentChunkId = null;
    try { workerEntry.worker.postMessage({ type: "no_more_chunks" }); } catch {}
    return false;
  };

  /* ---- Handle worker messages ---- */
  const handleWorkerMessage = (workerEntry, msg) => {
    if (task.finalized || !msg) return;

    if (msg.type === "progress") {
      const chunk = task.chunks[msg.chunkId];
      if (!chunk || chunk.state !== "claimed") return;
      chunk.downloaded += msg.bytes;
      chunk.lastActivity = Date.now();
      task.totalDownloaded += msg.bytes;
      saveStateThrottled();
      emitProgress();
    } else if (msg.type === "chunk_done") {
      const chunk = task.chunks[msg.chunkId];
      if (!chunk) return;
      const expected = chunk.end - chunk.start + 1;
      if (chunk.downloaded < expected) {
        task.totalDownloaded += (expected - chunk.downloaded);
        chunk.downloaded = expected;
      }
      chunk.state = "done";
      chunk.workerId = null;
      task.finishedChunks.add(chunk.id);
      workerEntry.currentChunkId = null;

      if (task.finishedChunks.size === chunks.length) {
        return maybeFinalize();
      }
      // Give this worker another chunk
      assignNextChunk(workerEntry);
    } else if (msg.type === "chunk_failed") {
      const chunk = task.chunks[msg.chunkId];
      if (!chunk) return;
      chunk.attempts = (chunk.attempts || 0) + 1;
      workerEntry.currentChunkId = null;

      if (chunk.attempts < MAX_CHUNK_ATTEMPTS && task.state === "downloading") {
        console.warn(`[downloadManager id=${id}] chunk ${chunk.id} failed (attempt ${chunk.attempts}): ${msg.error} — requeueing`);
        chunk.state = "pending";
        chunk.workerId = null;
        task.pendingChunks.push(chunk.id);
        assignNextChunk(workerEntry);
      } else {
        console.error(`[downloadManager id=${id}] chunk ${chunk.id} failed permanently: ${msg.error}`);
        chunk.state = "failed";
        if (!task.firstError) task.firstError = msg.error || `Chunk ${chunk.id} failed`;
        for (const w of task.workers.values()) {
          try { w.worker.postMessage({ type: "abort" }); } catch {}
        }
        if (task.forceKillTimer) { clearTimeout(task.forceKillTimer); }
        task.forceKillTimer = setTimeout(() => {
          terminateAllWorkers();
          maybeFinalize();
        }, FORCE_KILL_MS);
      }
    } else if (msg.type === "worker_done") {
      workerEntry.alive = false;
      maybeFinalize();
    } else if (msg.type === "worker_log") {
      console.log(`[w${workerEntry.id}] ${msg.text}`);
    }
  };

  /* ---- Spawn workers ---- */
  const spawnWorker = (workerId) => {
    const worker = new Worker(path.join(__dirname, "worker.js"), {
      workerData: {
        url,
        headers: extraHeaders,
        tempFilePath,
        workerId,
        maxAttempts: 3,
      },
    });

    const entry = { id: workerId, worker, currentChunkId: null, alive: true };
    task.workers.set(workerId, entry);

    worker.on("message", (msg) => handleWorkerMessage(entry, msg));
    worker.on("error", (err) => {
      console.error(`[downloadManager id=${id}] worker ${workerId} error:`, err.message);
      if (entry.currentChunkId !== null) {
        const chunk = task.chunks[entry.currentChunkId];
        if (chunk && chunk.state === "claimed") {
          chunk.state = "pending";
          chunk.workerId = null;
          task.pendingChunks.push(chunk.id);
        }
      }
      entry.alive = false;
      entry.currentChunkId = null;
      maybeFinalize();
    });
    worker.on("exit", () => {
      if (entry.currentChunkId !== null) {
        const chunk = task.chunks[entry.currentChunkId];
        if (chunk && chunk.state === "claimed") {
          chunk.state = "pending";
          chunk.workerId = null;
          task.pendingChunks.push(chunk.id);
        }
        entry.currentChunkId = null;
      }
      entry.alive = false;
      maybeFinalize();
    });

    // Kick off: assign the first chunk only if we're actually downloading.
    setImmediate(() => {
      if (task.state === "downloading" && task.pendingAction === null) {
        assignNextChunk(entry);
      } else {
        // Pausing / cancelling already — just tell it to stop.
        try { entry.worker.postMessage({ type: "no_more_chunks" }); } catch {}
      }
    });

    return entry;
  };

  /* ---- Return promise + spawn workers ---- */
  return new Promise((resolve) => {
    task.resolveTask = resolve;

    if (totalSize === 0) {
      fs.writeFileSync(tempFilePath, "");
      chunks.forEach((c) => task.finishedChunks.add(c.id));
      setImmediate(maybeFinalize);
      return;
    }

    const numWorkers = task.workersTotal;
    for (let i = 0; i < numWorkers; i++) {
      spawnWorker(i);
    }

    // If there were no pending chunks (all already done), finalize now
    if (task.pendingChunks.length === 0) {
      setImmediate(maybeFinalize);
    }
  });
}

/* ================================================================
 *  Pause / Cancel / Cleanup
 * ================================================================ */
function pauseTask(id) {
  return new Promise((resolve) => {
    const task = tasks.get(id);
    if (!task) return resolve({ success: false, error: "No active download with this id." });
    if (task.state !== "downloading") {
      return resolve({ success: false, error: `Cannot pause from state '${task.state}'.` });
    }
    task.state = "pausing";
    task.pendingAction = "pause";
    task._pauseResolve = resolve;

    // v2.1 fix: drop any stale force-kill timer before arming a new one.
    if (task.forceKillTimer) { clearTimeout(task.forceKillTimer); task.forceKillTimer = null; }

    for (const w of task.workers.values()) {
      try { w.worker.postMessage({ type: "abort" }); } catch {}
    }

    // Try to finalize right now if there's nothing keeping us alive.
    task._maybeFinalize?.();

    // Only arm the hard-kill fallback if we haven't already finalized.
    if (!task.finalized) {
      task.forceKillTimer = setTimeout(() => {
        for (const w of task.workers.values()) { try { w.worker.terminate(); } catch {} }
        task._maybeFinalize?.();
      }, FORCE_KILL_MS);
    }
  });
}

function cancelTask(id) {
  return new Promise((resolve) => {
    const task = tasks.get(id);
    if (!task) return resolve({ success: false, error: "No active download with this id." });
    if (task.state !== "downloading" && task.state !== "pausing") {
      return resolve({ success: false, error: `Cannot cancel from state '${task.state}'.` });
    }
    task.state = "cancelling";
    task.pendingAction = "cancel";
    task._cancelResolve = resolve;

    // v2.1 fix: drop any stale force-kill timer before arming a new one.
    if (task.forceKillTimer) { clearTimeout(task.forceKillTimer); task.forceKillTimer = null; }

    for (const w of task.workers.values()) {
      try { w.worker.postMessage({ type: "abort" }); } catch {}
    }

    task._maybeFinalize?.();

    if (!task.finalized) {
      task.forceKillTimer = setTimeout(() => {
        for (const w of task.workers.values()) { try { w.worker.terminate(); } catch {} }
        task._maybeFinalize?.();
      }, FORCE_KILL_MS);
    }
  });
}

async function pauseAll() {
  const ids = Array.from(tasks.keys());
  await Promise.all(ids.map((id) => pauseTask(id).catch(() => {})));
}

function removePartialFiles(filePath) {
  for (const p of [filePath + ".fastdl", filePath + ".download", filePath + ".fastdl.tmp"]) {
    try { if (fs.existsSync(p)) fs.unlinkSync(p); } catch (err) {
      console.error("[downloadManager] cleanup failed:", p, err.message);
    }
  }
}

function isTaskActive(id) {
  const t = tasks.get(id);
  return !!t && t.state !== "finalized";
}

module.exports = {
  prepareDownload,
  startTask,
  pauseTask,
  cancelTask,
  pauseAll,
  removePartialFiles,
  isTaskActive,
};