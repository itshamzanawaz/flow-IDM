/* ================================================================
 *  Flow — download worker (optimized)
 *  - keep-alive HTTPS agent (connection reuse on retries)
 *  - 1 MB write buffer (fewer syscalls on fast links)
 *  - Accept-Encoding: identity (prevents range corruption)
 *  - Browser-like User-Agent (some CDNs throttle axios/x.x.x)
 *  - Progress from fs.WriteStream.bytesWritten (safe for resume)
 *  - Detects HTML error pages
 * ================================================================ */

const { workerData, parentPort } = require("worker_threads");
const axios = require("axios");
const fs = require("fs");
const https = require("https");
const { pipeline } = require("stream/promises");

const { url, start, end, tempFilePath, chunkId, headers = {} } = workerData;
const expectedBytes = end - start + 1;

const abortController = new AbortController();
let aborted = false;

let lastReported = 0;
let totalWritten = 0;
let progressTimer = null;

/* ---------------- Keep-alive agent ----------------
 * Reuses TCP/TLS connections for retries within this worker and
 * across consecutive downloads. maxSockets is generous because
 * each worker writes to its own file offset.
 */
const httpsAgent = new https.Agent({
  keepAlive: true,
  keepAliveMsecs: 30000,
  maxSockets: 64,
  maxFreeSockets: 16,
});

/* ---------------- Realistic User-Agent ---------------- */
const DEFAULT_UA =
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

function reportProgress(force = false) {
  const delta = totalWritten - lastReported;
  if (delta > 0 || force) {
    if (delta > 0) {
      parentPort.postMessage({ type: "progress", bytes: delta, chunkId });
      lastReported = totalWritten;
    }
  }
}

parentPort.on("message", (msg) => {
  if (msg && msg.type === "abort") {
    aborted = true;
    try { abortController.abort(); } catch {}
  }
});

async function run() {
  let stream = null;

  try {
    const requestHeaders = {
      Range: `bytes=${start}-${end}`,
      // Prevent gzip/br on binary ranges — this can corrupt byte offsets
      "Accept-Encoding": "identity",
      // Some CDNs throttle the default axios UA
      "User-Agent": headers["User-Agent"] || DEFAULT_UA,
      // Explicit keep-alive intent
      Connection: "keep-alive",
      // Merge caller-provided headers last so they can override
      ...headers,
    };

    const response = await axios({
      method: "get",
      url,
      responseType: "stream",
      timeout: 30000,
      maxRedirects: 10,
      headers: requestHeaders,
      httpsAgent,
      signal: abortController.signal,
    });

    /* ---- Response sanity checks ---- */
    if (response.status === 401 || response.status === 403) {
      throw new Error(`Server rejected request (HTTP ${response.status}).`);
    }
    if (response.status === 404) {
      throw new Error("File not found (HTTP 404).");
    }
    if (response.status >= 500) {
      throw new Error(`Server error (HTTP ${response.status}).`);
    }
    if (response.status !== 206 && start > 0) {
      throw new Error(`Server ignored range request (status ${response.status}) — cannot resume.`);
    }
    if (response.status !== 200 && response.status !== 206) {
      throw new Error(`Unexpected response status ${response.status}.`);
    }

    const ct = String(response.headers["content-type"] || "").toLowerCase();
    if (ct.includes("text/html") && expectedBytes > 100 * 1024) {
      throw new Error("Server returned HTML instead of file (likely an error page).");
    }

    /* ---- 1 MB write buffer — big win on gigabit+ links ---- */
    stream = fs.createWriteStream(tempFilePath, {
      flags: "r+",
      start,
      highWaterMark: 1024 * 1024,
    });

    // Poll bytesWritten — only counts bytes flushed to the OS
    progressTimer = setInterval(() => {
      if (!stream) return;
      const flushed = stream.bytesWritten;
      if (flushed > totalWritten) {
        totalWritten = flushed;
        reportProgress();
      }
    }, 250);

    await pipeline(response.data, stream);

    try { totalWritten = stream.bytesWritten; } catch {}
    reportProgress(true);

    if (totalWritten !== expectedBytes) {
      throw new Error(`Incomplete chunk. Expected ${expectedBytes} bytes, got ${totalWritten}.`);
    }

    parentPort.postMessage({ type: "done", chunkId });
  } catch (err) {
    if (stream) { try { totalWritten = stream.bytesWritten; } catch {} }
    reportProgress(true);

    if (
      aborted ||
      (axios.isCancel && axios.isCancel(err)) ||
      err.code === "ERR_CANCELED" ||
      err.code === "ABORT_ERR" ||
      (err.message && /abort/i.test(err.message))
    ) {
      parentPort.postMessage({ type: "aborted", chunkId });
    } else {
      parentPort.postMessage({ error: err.message || String(err), chunkId });
    }
  } finally {
    if (progressTimer) { clearInterval(progressTimer); progressTimer = null; }
    if (stream) { try { stream.close(); } catch {} }
  }
}

run();