/* ================================================================
 *  Flow — download engine (optimized)
 *  - Adaptive thread count based on file size
 *  - Minimum chunk size to prevent thread explosion
 *  - Robust probe (HEAD → GET+Range fallback for signed URLs)
 *  - Filename sanitization + collision handling
 *  - Per-file locks
 *  - Chunk-level retry with backoff
 *  - Worker generation tracking (stale messages ignored)
 *  - Atomic state writes, corrupted-state detection
 *  - Cross-device rename fallback
 *  - Progress throttle
 * ================================================================ */

const axios = require("axios");
const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");
const { Worker } = require("worker_threads");

/* ---------------- Config ---------------- */
const MAX_THREADS = 20;                     // hard ceiling
const MIN_CHUNK_SIZE = 2 * 1024 * 1024;     // 2 MB — nothing smaller per worker
const STALL_TIMEOUT_MS = 45000;
const WATCHDOG_INTERVAL_MS = 5000;
const FORCE_KILL_MS = 3000;
const MAX_CHUNK_ATTEMPTS = 3;
const RETRY_BACKOFF_MS = 1500;
const PROGRESS_THROTTLE_MS = 100;
const PROBE_TIMEOUT_MS = 20000;
const MB = 1024 * 1024;
const GB = 1024 * MB;

/* ---------------- Global state ---------------- */
const tasks = new Map();
const fileLocks = new Map();

/* ================================================================
 *  Adaptive thread count
 * ================================================================ */
function computeThreadCount(totalSize) {
  let desired;
  if (totalSize < 10 * MB)         desired = 2;
  else if (totalSize < 100 * MB)   desired = 4;
  else if (totalSize < 500 * MB)   desired = 8;
  else if (totalSize < 2 * GB)     desired = 12;
  else if (totalSize < 5 * GB)     desired = 16;
  else                             desired = MAX_THREADS;

  // Don't spawn more workers than we have data to fill
  const maxBySize = Math.max(1, Math.floor(totalSize / MIN_CHUNK_SIZE));
  return Math.max(1, Math.min(desired, maxBySize, MAX_THREADS));
}

/* ================================================================
 *  Utility
 * ================================================================ */
function safeFilename(name) {
  if (!name || typeof name !== "string") return "download.bin";
  let n = name
    .replace(/[\x00-\x1f\x7f]/g, "")
    .replace(/[\\/:*?"<>|]/g, "_")
    .replace(/^[\s.]+|[\s.]+$/g, "");
  const base = n.split(".")[0].toUpperCase();
  const reserved = ["CON","PRN","AUX","NUL","COM1","COM2","COM3","COM4","COM5","COM6","COM7","COM8","COM9","LPT1","LPT2","LPT3","LPT4","LPT5","LPT6","LPT7","LPT8","LPT9"];
  if (reserved.includes(base)) n = "_" + n;
  if (n.length > 200) {
    const ext = path.extname(n).slice(0, 20);
    n = n.slice(0, 200 - ext.length) + ext;
  }
  return n || "download.bin";
}

function parseFilename(disposition, finalUrl) {
  if (disposition && typeof disposition === "string") {
    const rfc = disposition.match(/filename\*\s*=\s*([^']+)'[^']*'([^;]+)/i);
    if (rfc) {
      try { return safeFilename(decodeURIComponent(rfc[2].trim())); } catch {}
    }
    const plain = disposition.match(/filename\s*=\s*(?:"([^"]*)"|([^;]+))/i);
    if (plain) {
      const val = (plain[1] || plain[2] || "").trim();
      if (val) return safeFilename(val);
    }
  }
  try {
    const u = new URL(finalUrl);
    const base = path.basename(u.pathname);
    if (base) return safeFilename(decodeURIComponent(base));
  } catch {}
  return "download.bin";
}

function uniquePath(dir, filename) {
  const full = path.join(dir, filename);
  const exists = (p) => fs.existsSync(p) || fs.existsSync(p + ".fastdl");
  if (!exists(full)) return full;
  const ext = path.extname(filename);
  const base = filename.slice(0, filename.length - ext.length);
  for (let i = 1; i < 1000; i++) {
    const candidate = path.join(dir, `${base} (${i})${ext}`);
    if (!exists(candidate)) return candidate;
  }
  return path.join(dir, `${base}-${Date.now()}${ext}`);
}

async function renameCrossDevice(oldPath, newPath) {
  try {
    await fsp.rename(oldPath, newPath);
    return;
  } catch (err) {
    if (err.code !== "EXDEV") throw err;
  }
  await fsp.copyFile(oldPath, newPath);
  try { await fsp.unlink(oldPath); } catch {}
}

async function renameWithRetry(oldPath, newPath, retries = 5) {
  let lastErr = null;
  for (let i = 0; i < retries; i++) {
    try {
      await renameCrossDevice(oldPath, newPath);
      return;
    } catch (err) {
      lastErr = err;
      await new Promise((r) => setTimeout(r, 400 * (i + 1)));
    }
  }
  throw lastErr;
}

function atomicWriteJson(filePath, obj) {
  const tmp = filePath + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(obj));
  fs.renameSync(tmp, filePath);
}

function persistState(task) {
  try {
    atomicWriteJson(task.statePath, task.sharedState);
    task.lastSave = Date.now();
  } catch (err) {
    console.error("[downloadManager] state write failed:", err.message);
  }
}

function computeChunkLayout(totalSize, numChunks) {
  if (totalSize <= 0) return [];
  if (numChunks <= 1) {
    return [{ id: 0, start: 0, end: totalSize - 1, downloaded: 0, lastActivity: Date.now(), attempts: 0 }];
  }
  const chunkSize = Math.floor(totalSize / numChunks);
  const chunks = [];
  for (let i = 0; i < numChunks; i++) {
    const start = i * chunkSize;
    const end = i === numChunks - 1 ? totalSize - 1 : start + chunkSize - 1;
    chunks.push({ id: i, start, end, downloaded: 0, lastActivity: Date.now(), attempts: 0 });
  }
  return chunks;
}

function isValidState(state, totalSize) {
  if (!state || typeof state !== "object") return false;
  if (!Array.isArray(state.chunks) || state.chunks.length === 0) return false;
  if (state.totalSize !== totalSize) return false;
  let sum = 0;
  for (const c of state.chunks) {
    if (!Number.isFinite(c.start) || !Number.isFinite(c.end) || !Number.isFinite(c.downloaded)) return false;
    if (c.end < c.start) return false;
    if (c.downloaded < 0 || c.downloaded > c.end - c.start + 1) return false;
    sum += (c.end - c.start + 1);
  }
  return sum === totalSize;
}

function chunksFullyDownloaded(sharedState) {
  return sharedState.chunks.every((c) => c.downloaded >= c.end - c.start + 1);
}

/* ================================================================
 *  prepareDownload
 * ================================================================ */
async function prepareDownload(url, saveDirectory, extraHeaders = {}) {
  if (!url || typeof url !== "string") throw new Error("Invalid URL");
  try { new URL(url); } catch { throw new Error("Malformed URL"); }

  try { await fsp.mkdir(saveDirectory, { recursive: true }); }
  catch (err) {
    throw new Error(`Cannot access save directory: ${err.message}`);
  }

  let totalSize = null;
  let acceptRanges = null;
  let disposition = null;
  let finalUrl = url;

  /* ---- Attempt 1: HEAD ---- */
  let headFailed = false;
  try {
    const res = await axios.head(url, {
      timeout: PROBE_TIMEOUT_MS,
      maxRedirects: 10,
      headers: extraHeaders,
      validateStatus: () => true,
    });

    if (res.status >= 200 && res.status < 300) {
      acceptRanges = res.headers["accept-ranges"];
      const len = parseInt(res.headers["content-length"], 10);
      if (Number.isFinite(len) && len > 0) totalSize = len;
      disposition = res.headers["content-disposition"];
      finalUrl = res.request?.res?.responseUrl || url;
    } else if (res.status === 404) {
      throw new Error("File not found (HTTP 404).");
    } else {
      headFailed = true;
    }
  } catch (err) {
    if (err.code === "ENOTFOUND") throw new Error("Host not found. Check your connection.");
    if (err.code === "ECONNREFUSED") throw new Error("Connection refused by server.");
    if (err.message && err.message.includes("HTTP 404")) throw err;
    headFailed = true;
  }

  /* ---- Attempt 2: GET with Range: bytes=0-0 ---- */
  if (headFailed || !totalSize || !acceptRanges || acceptRanges === "none") {
    let probe;
    try {
      probe = await axios.get(url, {
        timeout: PROBE_TIMEOUT_MS,
        maxRedirects: 10,
        headers: { ...extraHeaders, Range: "bytes=0-0", "Accept-Encoding": "identity" },
        responseType: "stream",
        validateStatus: () => true,
      });
    } catch (err) {
      throw new Error(`Could not reach server: ${err.message}`);
    }

    try { probe.data.destroy(); } catch {}

    if (probe.status === 401 || probe.status === 403) {
      throw new Error(`Server rejected the request (HTTP ${probe.status}). The link may have expired or require authentication.`);
    }
    if (probe.status === 404) throw new Error("File not found (HTTP 404).");
    if (probe.status >= 400) throw new Error(`Server error (HTTP ${probe.status}).`);

    const contentRange = probe.headers["content-range"];
    if (contentRange) {
      const m = contentRange.match(/bytes\s+\d+-\d+\/(\d+)/i);
      if (m) totalSize = parseInt(m[1], 10);
      acceptRanges = "bytes";
    }
    if (!totalSize) {
      const len = parseInt(probe.headers["content-length"], 10);
      if (Number.isFinite(len) && len > 0 && probe.status === 200) totalSize = len;
    }
    if (!disposition) disposition = probe.headers["content-disposition"];
    if (!acceptRanges) acceptRanges = probe.headers["accept-ranges"];
    finalUrl = probe.request?.res?.responseUrl || url;
  }

  if (!acceptRanges || acceptRanges === "none") {
    throw new Error("Server does not support resumable downloads (no Range support).");
  }
  if (!Number.isFinite(totalSize) || totalSize <= 0) {
    throw new Error("Could not determine file size from the server.");
  }

  /* ---- Disk space check ---- */
  try {
    if (typeof fsp.statfs === "function") {
      const stats = await fsp.statfs(saveDirectory);
      const freeBytes = Number(stats.bavail) * Number(stats.bsize);
      if (freeBytes > 0 && freeBytes < totalSize * 1.1) {
        const need = (totalSize / 1e9).toFixed(2);
        const free = (freeBytes / 1e9).toFixed(2);
        throw new Error(`Not enough disk space. Need ~${need} GB, only ${free} GB free.`);
      }
    }
  } catch (err) {
    if (err.message && err.message.includes("disk space")) throw err;
  }

  const rawName = parseFilename(disposition, finalUrl);
  const filePath = uniquePath(saveDirectory, rawName);
  const fileName = path.basename(filePath);

  const threads = computeThreadCount(totalSize);
  console.log(`[prepareDownload] size=${totalSize} (${(totalSize/MB).toFixed(1)} MB) ranges=${acceptRanges} threads=${threads} name="${fileName}"`);
  return { fileName, filePath, totalSize };
}

/* ================================================================
 *  startTask
 * ================================================================ */
function startTask(id, url, filePath, totalSize, sender, extraHeaders = {}) {
  const lockedBy = fileLocks.get(filePath);
  if (lockedBy !== undefined && lockedBy !== id) {
    return Promise.reject(new Error("Another download is already writing to this file."));
  }
  fileLocks.set(filePath, id);

  const existing = tasks.get(id);
  if (existing && existing.state !== "finalized") {
    fileLocks.delete(filePath);
    return Promise.reject(new Error("A download is already running with this id."));
  }

  const statePath = filePath + ".fastdl";
  const tempFilePath = filePath + ".download";

  let sharedState = null;
  if (fs.existsSync(statePath) && fs.existsSync(tempFilePath)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(statePath, "utf8"));
      if (isValidState(parsed, totalSize) && (!parsed.url || parsed.url === url)) {
        sharedState = parsed;
        console.log(`[downloadManager id=${id}] resuming with ${parsed.chunks.length} chunks`);
      }
    } catch (err) {
      console.warn("[downloadManager] discarding corrupted state file:", err.message);
    }
  }

  if (!sharedState) {
    try {
      const fd = fs.openSync(tempFilePath, "w");
      try { fs.ftruncateSync(fd, totalSize); } finally { fs.closeSync(fd); }
    } catch (err) {
      fileLocks.delete(filePath);
      return Promise.reject(new Error(`Cannot create temp file: ${err.message}`));
    }
    const numThreads = computeThreadCount(totalSize);
    sharedState = { url, totalSize, chunks: computeChunkLayout(totalSize, numThreads) };
    try { atomicWriteJson(statePath, sharedState); } catch {}
    console.log(`[downloadManager id=${id}] starting fresh with ${numThreads} threads`);
  }

  const task = {
    id, url, filePath, statePath, tempFilePath,
    totalSize: sharedState.totalSize,
    sharedState,
    state: "downloading",
    pendingAction: null,
    workers: [],
    currentWorker: new Map(),
    chunkFinished: new Set(),
    chunksTotal: sharedState.chunks.length,
    totalDownloaded: sharedState.chunks.reduce((a, c) => a + c.downloaded, 0),
    initialDownloaded: sharedState.chunks.reduce((a, c) => a + c.downloaded, 0),
    firstError: null,
    watchdog: null,
    forceKillTimer: null,
    lastSave: 0,
    lastProgressSent: 0,
    startTime: Date.now(),
    resolveTask: null,
    _pauseResolve: null,
    _cancelResolve: null,
    finalized: false,
    _maybeFinalize: null,
    extraHeaders,
  };
  tasks.set(id, task);

  const saveStateThrottled = () => {
    if (Date.now() - task.lastSave > 1000) persistState(task);
  };

  const clearTimers = () => {
    if (task.watchdog) { clearInterval(task.watchdog); task.watchdog = null; }
    if (task.forceKillTimer) { clearTimeout(task.forceKillTimer); task.forceKillTimer = null; }
  };
  const terminateAllWorkers = () => {
    for (const w of task.workers) { try { w.terminate(); } catch {} }
    task.workers = [];
    task.currentWorker.clear();
  };

  /* ---- Finalizers ---- */
  const finalizeSuccess = async () => {
    if (task.finalized) return;
    task.finalized = true;
    task.state = "finalized";
    clearTimers();
    terminateAllWorkers();
    tasks.delete(id);
    fileLocks.delete(filePath);

    try {
      if (!chunksFullyDownloaded(task.sharedState)) {
        throw new Error("Cannot finalize: not all chunks are complete.");
      }
      try { if (fs.existsSync(statePath)) fs.unlinkSync(statePath); } catch {}
      await renameWithRetry(tempFilePath, filePath);
      task.resolveTask?.({ success: true, filePath });
      task._pauseResolve?.({ success: false, error: "Download completed" });
      task._cancelResolve?.({ success: false, error: "Download completed" });
    } catch (err) {
      task.resolveTask?.({ success: false, error: "Finalization failed: " + err.message });
      task._pauseResolve?.({ success: false, error: "Finalization failed" });
      task._cancelResolve?.({ success: false, error: "Finalization failed" });
    }
    task._pauseResolve = null;
    task._cancelResolve = null;
  };

  const finalizePause = () => {
    if (task.finalized) return;
    task.finalized = true;
    task.state = "finalized";
    clearTimers();
    terminateAllWorkers();
    persistState(task);
    tasks.delete(id);
    fileLocks.delete(filePath);

    task.resolveTask?.({ success: false, paused: true });
    task._pauseResolve?.({ success: true });
    task._cancelResolve?.({ success: false, error: "Paused instead of cancelled" });
    task._pauseResolve = null;
    task._cancelResolve = null;
  };

  const finalizeCancel = () => {
    if (task.finalized) return;
    task.finalized = true;
    task.state = "finalized";
    clearTimers();
    terminateAllWorkers();
    tasks.delete(id);
    fileLocks.delete(filePath);

    task.resolveTask?.({ success: false, cancelled: true });
    task._cancelResolve?.({ success: true });
    task._pauseResolve?.({ success: false, error: "Cancelled instead of paused" });
    task._pauseResolve = null;
    task._cancelResolve = null;
  };

  const finalizeFailure = (message) => {
    if (task.finalized) return;
    task.finalized = true;
    task.state = "finalized";
    clearTimers();
    terminateAllWorkers();
    persistState(task);
    tasks.delete(id);
    fileLocks.delete(filePath);

    task.resolveTask?.({ success: false, error: message });
    task._pauseResolve?.({ success: false, error: message });
    task._cancelResolve?.({ success: false, error: message });
    task._pauseResolve = null;
    task._cancelResolve = null;
  };

  const maybeFinalize = () => {
    if (task.finalized) return;
    if (task.chunkFinished.size < task.chunksTotal) return;
    if (!task.firstError && chunksFullyDownloaded(task.sharedState)) return finalizeSuccess();
    if (task.pendingAction === "cancel") return finalizeCancel();
    if (task.pendingAction === "pause") return finalizePause();
    if (task.firstError) return finalizeFailure(task.firstError);
    return finalizeFailure("A worker stopped unexpectedly");
  };
  task._maybeFinalize = maybeFinalize;

  const emitProgress = () => {
    if (!sender || task.state !== "downloading") return;
    const now = Date.now();
    if (now - task.lastProgressSent < PROGRESS_THROTTLE_MS) return;
    task.lastProgressSent = now;

    const elapsed = (now - task.startTime) / 1000;
    const sessionBytes = task.totalDownloaded - task.initialDownloaded;
    const speedBps = elapsed > 0 ? sessionBytes / elapsed : 0;
    const speedMBps = (speedBps / MB).toFixed(2);

    let percent = task.totalSize > 0 ? (task.totalDownloaded / task.totalSize) * 100 : 0;
    if (percent > 100) percent = 100;
    if (percent >= 100 && !chunksFullyDownloaded(task.sharedState)) percent = 99.9;

    const remaining = Math.max(0, task.totalSize - task.totalDownloaded);
    const etaSeconds = speedBps > 0 ? Math.round(remaining / speedBps) : 0;

    try {
      sender.send("download-progress", {
        id: task.id,
        percent: percent.toFixed(1),
        speedMBps,
        etaSeconds,
        downloaded: task.totalDownloaded,
        totalSize: task.totalSize,
      });
    } catch {}
  };

  task.watchdog = setInterval(() => {
    if (task.state !== "downloading") return;
    const now = Date.now();
    const stalled = sharedState.chunks.some(
      (c) => c.downloaded < c.end - c.start + 1 &&
             now - (c.lastActivity || 0) > STALL_TIMEOUT_MS
    );
    if (!stalled) return;
    task.firstError = "Network stalled: no data received for over 45 seconds.";
    for (const w of task.workers) { try { w.postMessage({ type: "abort" }); } catch {} }
    task.forceKillTimer = setTimeout(() => {
      terminateAllWorkers();
      maybeFinalize();
    }, FORCE_KILL_MS);
  }, WATCHDOG_INTERVAL_MS);

  const isRetryable = (errMsg) => {
    if (!errMsg) return true;
    const non = ["Server ignored range", "403", "404", "HTML", "auth", "expired", "Cannot"];
    return !non.some((s) => errMsg.includes(s));
  };

  const spawnChunkWorker = (chunk) => {
    const expected = chunk.end - chunk.start + 1;
    const workerStart = chunk.start + chunk.downloaded;

    const worker = new Worker(path.join(__dirname, "worker.js"), {
      workerData: {
        url: task.url,
        start: workerStart,
        end: chunk.end,
        tempFilePath: task.tempFilePath,
        chunkId: chunk.id,
        headers: task.extraHeaders,
      },
    });
    task.workers.push(worker);
    task.currentWorker.set(chunk.id, worker);

    let markedDone = false;
    const markFinished = () => {
      if (markedDone) return;
      markedDone = true;
      task.currentWorker.delete(chunk.id);
      task.chunkFinished.add(chunk.id);
      maybeFinalize();
    };

    const handleRetryOrFail = (errMsg) => {
      if (markedDone) return;
      task.currentWorker.delete(chunk.id);

      const canRetry =
        task.state === "downloading" &&
        isRetryable(errMsg) &&
        (chunk.attempts || 0) < MAX_CHUNK_ATTEMPTS;

      if (canRetry) {
        chunk.attempts = (chunk.attempts || 0) + 1;
        const delay = RETRY_BACKOFF_MS * chunk.attempts;
        console.warn(`[downloadManager id=${id}] retry chunk ${chunk.id} (attempt ${chunk.attempts}) in ${delay}ms: ${errMsg}`);
        setTimeout(() => {
          if (task.state === "downloading" && !task.finalized) {
            spawnChunkWorker(chunk);
          } else {
            markFinished();
          }
        }, delay);
        return;
      }

      if (!task.firstError) task.firstError = errMsg || `Chunk ${chunk.id} failed`;
      markedDone = true;
      task.chunkFinished.add(chunk.id);
      maybeFinalize();
    };

    worker.on("message", (msg) => {
      if (!msg) return;
      if (task.currentWorker.get(chunk.id) !== worker) return;

      if (msg.type === "progress") {
        if (task.state !== "downloading") return;
        chunk.downloaded += msg.bytes;
        chunk.lastActivity = Date.now();
        task.totalDownloaded += msg.bytes;
        saveStateThrottled();
        emitProgress();
      } else if (msg.type === "done") {
        if (chunk.downloaded < expected) {
          task.totalDownloaded += (expected - chunk.downloaded);
          chunk.downloaded = expected;
        }
        markFinished();
      } else if (msg.type === "aborted") {
        markFinished();
      } else if (msg.error) {
        handleRetryOrFail(msg.error);
      }
    });

    worker.on("error", (err) => {
      handleRetryOrFail(err.message || String(err));
    });

    worker.on("exit", (code) => {
      if (task.currentWorker.get(chunk.id) !== worker) return;
      task.currentWorker.delete(chunk.id);
      if (!markedDone && code !== 0) {
        handleRetryOrFail(`Worker exited with code ${code}`);
      } else if (!markedDone) {
        handleRetryOrFail("Worker exited without completing");
      }
    });
  };

  return new Promise((resolve) => {
    task.resolveTask = resolve;

    if (totalSize === 0) {
      fs.writeFileSync(tempFilePath, "");
      setImmediate(maybeFinalize);
      return;
    }

    let spawned = 0;
    for (const chunk of sharedState.chunks) {
      const expected = chunk.end - chunk.start + 1;
      if (chunk.downloaded >= expected) {
        task.chunkFinished.add(chunk.id);
        continue;
      }
      chunk.attempts = 0;
      spawnChunkWorker(chunk);
      spawned++;
    }
    if (spawned === 0) setImmediate(maybeFinalize);
  });
}

/* ================================================================
 *  Pause / Cancel / Cleanup
 * ================================================================ */
function pauseTask(id) {
  return new Promise((resolve) => {
    const task = tasks.get(id);
    if (!task) return resolve({ success: false, error: "No active download with this id." });
    if (task.state !== "downloading") {
      return resolve({ success: false, error: `Cannot pause from state '${task.state}'.` });
    }
    task.state = "pausing";
    task.pendingAction = "pause";
    task._pauseResolve = resolve;
    for (const w of task.workers) { try { w.postMessage({ type: "abort" }); } catch {} }
    task.forceKillTimer = setTimeout(() => {
      for (const w of task.workers) { try { w.terminate(); } catch {} }
      task._maybeFinalize?.();
    }, FORCE_KILL_MS);
  });
}

function cancelTask(id) {
  return new Promise((resolve) => {
    const task = tasks.get(id);
    if (!task) return resolve({ success: false, error: "No active download with this id." });
    if (task.state !== "downloading" && task.state !== "pausing") {
      return resolve({ success: false, error: `Cannot cancel from state '${task.state}'.` });
    }
    task.state = "cancelling";
    task.pendingAction = "cancel";
    task._cancelResolve = resolve;
    for (const w of task.workers) { try { w.postMessage({ type: "abort" }); } catch {} }
    task.forceKillTimer = setTimeout(() => {
      for (const w of task.workers) { try { w.terminate(); } catch {} }
      task._maybeFinalize?.();
    }, FORCE_KILL_MS);
  });
}

async function pauseAll() {
  const ids = Array.from(tasks.keys());
  await Promise.all(ids.map((id) => pauseTask(id).catch(() => {})));
}

function removePartialFiles(filePath) {
  for (const p of [filePath + ".fastdl", filePath + ".download", filePath + ".fastdl.tmp"]) {
    try { if (fs.existsSync(p)) fs.unlinkSync(p); } catch (err) {
      console.error("[downloadManager] cleanup failed:", p, err.message);
    }
  }
}

function isTaskActive(id) {
  const t = tasks.get(id);
  return !!t && t.state !== "finalized";
}

module.exports = {
  prepareDownload,
  startTask,
  pauseTask,
  cancelTask,
  pauseAll,
  removePartialFiles,
  isTaskActive,
};