/* ================================================================
   Flow — Renderer
   Surgical DOM updates so hover/click state is never destroyed.
   ================================================================ */

/* ---------------- Icons ---------------- */
const SVG = {
  file:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`,
  video:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>`,
  audio:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>`,
  image:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>`,
  archive:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5"/><line x1="10" y1="12" x2="14" y2="12"/></svg>`,
  doc:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>`,
  code:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>`,
  app:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>`,
  pause:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>`,
  play:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>`,
  x:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
  folder: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>`,
  external:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>`,
  retry:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>`,
  trash:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`,
  info:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`,
  success:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`,
  error:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`,
  warning:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
  downloadEmpty: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
};

/* ---------------- Helpers ---------------- */
const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

function on(sel, event, handler) {
  const el = typeof sel === "string" ? $(sel) : sel;
  if (!el) {
    console.warn("[flow] missing element for binding:", sel);
    return null;
  }
  el.addEventListener(event, handler);
  return el;
}

/* ---------------- State ---------------- */
const state = {
  view: "dashboard",
  directory: null,
  defaultDirectory: null,
  active: new Map(),
  history: [],
  theme: localStorage.getItem("flow-theme") || "dark",
  inflight: new Set(),
};

/* ---------------- Formatters ---------------- */
function formatBytes(bytes) {
  const n = Number(bytes) || 0;
  if (n <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let i = 0, v = n;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(v < 10 && i > 0 ? 2 : 1)} ${units[i]}`;
}

function formatEta(seconds) {
  if (!seconds || seconds <= 0 || !isFinite(seconds)) return "--";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

function formatDate(ts) {
  if (!ts) return "--";
  let d;
  if (typeof ts === "string") {
    d = new Date(ts.includes("T") ? ts : ts.replace(" ", "T") + "Z");
  } else {
    d = new Date(ts);
  }
  if (isNaN(d.getTime())) return "--";
  const diff = Date.now() - d.getTime();
  if (diff < 60_000) return "Just now";
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`;
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

/* ---------------- File type ---------------- */
const TYPE_MAP = {
  video:   { ext: ["mp4","mkv","avi","mov","webm","flv","m4v","wmv","mpg","mpeg"], color: "#8b5cf6" },
  audio:   { ext: ["mp3","wav","flac","aac","ogg","m4a","wma","opus"],            color: "#ec4899" },
  image:   { ext: ["jpg","jpeg","png","gif","webp","svg","bmp","tiff","ico"],     color: "#06b6d4" },
  archive: { ext: ["zip","rar","7z","tar","gz","bz2","xz","iso"],                 color: "#f59e0b" },
  doc:     { ext: ["pdf","doc","docx","txt","rtf","odt","md","xls","xlsx","ppt","pptx"], color: "#ef4444" },
  code:    { ext: ["js","ts","py","java","c","cpp","html","css","json","xml","sh","go","rs"], color: "#22c55e" },
  app:     { ext: ["exe","msi","dmg","pkg","deb","appimage","apk"],               color: "#6366f1" },
};

function fileVisual(filename) {
  const ext = (String(filename || "").split(".").pop() || "").toLowerCase();
  for (const [type, cfg] of Object.entries(TYPE_MAP)) {
    if (cfg.ext.includes(ext)) return { svg: SVG[type] || SVG.file, color: cfg.color };
  }
  return { svg: SVG.file, color: "#6b7280" };
}

function isValidUrl(str) {
  try {
    const u = new URL(str);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch { return false; }
}

/* ---------------- Theme ---------------- */
function applyTheme() {
  document.documentElement.setAttribute("data-theme", state.theme);
  const moon = $("#theme-icon-moon");
  const sun  = $("#theme-icon-sun");
  if (moon) moon.hidden = state.theme !== "dark";
  if (sun)  sun.hidden  = state.theme === "dark";
  const label = $("#settings-theme-label");
  if (label) label.textContent = state.theme === "dark" ? "Dark" : "Light";
}

function toggleTheme() {
  state.theme = state.theme === "dark" ? "light" : "dark";
  localStorage.setItem("flow-theme", state.theme);
  applyTheme();
}

/* ---------------- Toasts ---------------- */
function toast(message, type = "info") {
  const container = $("#toast-container");
  if (!container) return;
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.innerHTML = `${SVG[type] || SVG.info}<span>${escapeHtml(message)}</span>`;
  container.appendChild(el);
  requestAnimationFrame(() => el.classList.add("show"));
  setTimeout(() => {
    el.classList.remove("show");
    setTimeout(() => el.remove(), 250);
  }, 3200);
}

/* ---------------- View routing ---------------- */
const VIEW_META = {
  dashboard: { title: "Dashboard",     sub: "Start a new download or check your progress" },
  all:       { title: "All Downloads", sub: "Everything you have downloaded" },
  active:    { title: "Active",        sub: "Downloads currently in progress" },
  completed: { title: "Completed",     sub: "Downloads that finished successfully" },
  settings:  { title: "Settings",      sub: "Preferences and download location" },
};

function setView(view) {
  state.view = view;
  $$(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.view === view));
  $$(".view").forEach((v) => v.classList.toggle("active", v.dataset.view === view));
  const meta = VIEW_META[view] || VIEW_META.dashboard;
  const titleEl = $("#page-title");
  const subEl = $("#page-subtitle");
  if (titleEl) titleEl.textContent = meta.title;
  if (subEl) subEl.textContent = meta.sub;
  render();
}

/* ================================================================
 *  Rendering — SURGICAL
 *
 *  Active cards are created ONCE and updated in place. We never
 *  touch the DOM node of an existing card except to set text,
 *  classes, styles, or swap the pause/resume button in a way that
 *  keeps the same element. This preserves :hover state and lets
 *  the browser fire click events reliably.
 * ================================================================ */

function statusBadge(status) {
  const s = String(status || "").toLowerCase();
  const map = {
    downloading: { label: "Downloading", cls: "downloading" },
    preparing:   { label: "Preparing",   cls: "preparing" },
    paused:      { label: "Paused",      cls: "paused" },
    completed:   { label: "Completed",   cls: "completed" },
    cancelled:   { label: "Cancelled",   cls: "cancelled" },
    error:       { label: "Failed",      cls: "error" },
  };
  const m = map[s] || { label: status || "Unknown", cls: "" };
  return `<span class="badge ${m.cls}"><span class="badge-dot"></span>${escapeHtml(m.label)}</span>`;
}

function fileIconHtml(filename) {
  const { svg, color } = fileVisual(filename);
  return `<div class="file-icon" style="background:${color}1f; color:${color}">${svg}</div>`;
}

/* ---- Active card creation (called once per download) ---- */
function buildActiveCard(dl) {
  const card = document.createElement("div");
  card.className = "download-card";
  card.dataset.id = String(dl.id);
  const { svg, color } = fileVisual(dl.filename);

  card.innerHTML = `
    <div class="dl-head">
      <div class="file-icon" style="background:${color}1f; color:${color}">${svg}</div>
      <div class="dl-info">
        <div class="dl-name"></div>
        <div class="dl-sub"></div>
      </div>
      <div class="hi-status"></div>
      <div class="dl-actions">
        <button class="btn-icon" data-action="pause" data-id="${dl.id}" title="Pause">${SVG.pause}</button>
        <button class="btn-icon danger" data-action="cancel" data-id="${dl.id}" title="Cancel">${SVG.x}</button>
      </div>
    </div>
    <div class="progress-track">
      <div class="progress-bar"></div>
    </div>
    <div class="dl-stats">
      <span class="stat stat-size"></span>
      <span class="stat stat-speed"></span>
      <span class="stat stat-eta"></span>
    </div>
  `;
  updateActiveCard(card, dl, /* initial */ true);
  return card;
}

/* ---- Active card update (called on every progress tick) ---- */
function updateActiveCard(card, dl, initial = false) {
  const percent = Math.max(0, Math.min(100, Number(dl.percent) || 0));
  const isPaused = dl.status === "Paused";
  const isPreparing = dl.status === "Preparing";

  const nameEl = card.querySelector(".dl-name");
  if (nameEl && nameEl.textContent !== dl.filename) {
    nameEl.textContent = dl.filename || "";
    nameEl.title = dl.filename || "";
  }

  const subEl = card.querySelector(".dl-sub");
  if (subEl) {
    const wantSub = isPreparing ? "Preparing download…" : (dl.filePath || "");
    if (subEl.textContent !== wantSub) subEl.textContent = wantSub;
  }

  // Status badge — only rebuild when the label changes
  const statusEl = card.querySelector(".hi-status");
  if (statusEl) {
    const currentStatus = statusEl.dataset.status || "";
    const nextStatus = String(dl.status || "Downloading");
    if (currentStatus !== nextStatus) {
      statusEl.dataset.status = nextStatus;
      statusEl.innerHTML = statusBadge(nextStatus);
    }
  }

  // Progress bar
  const bar = card.querySelector(".progress-bar");
  if (bar) {
    if (isPreparing) {
      if (!bar.classList.contains("indeterminate")) {
        bar.classList.add("indeterminate");
        bar.style.width = "";
      }
    } else {
      if (bar.classList.contains("indeterminate")) bar.classList.remove("indeterminate");
      const width = `${percent}%`;
      if (bar.style.width !== width) bar.style.width = width;
    }
  }

  // Stats
  const totalStr = dl.totalSize ? formatBytes(dl.totalSize) : "Unknown size";
  const downloaded = dl.totalSize ? (dl.totalSize * percent) / 100 : 0;
  const speedStr = (!isPaused && !isPreparing && dl.speedMBps) ? `${dl.speedMBps} MB/s` : "—";
  const etaStr = (!isPaused && !isPreparing) ? formatEta(dl.etaSeconds) : "--";
  const shownPercent = isPreparing ? "—" : `${percent}%`;

  const sizeStat = card.querySelector(".stat-size");
  if (sizeStat) {
    const want = `<b>${shownPercent}</b>&nbsp;•&nbsp;${formatBytes(downloaded)} / ${totalStr}`;
    if (sizeStat.dataset.v !== want) {
      sizeStat.dataset.v = want;
      sizeStat.innerHTML = want;
    }
  }
  const speedStat = card.querySelector(".stat-speed");
  if (speedStat && speedStat.textContent !== speedStr) speedStat.textContent = speedStr;

  const etaStat = card.querySelector(".stat-eta");
  if (etaStat) {
    const want = `ETA <b>${etaStr}</b>`;
    if (etaStat.dataset.v !== want) {
      etaStat.dataset.v = want;
      etaStat.innerHTML = want;
    }
  }

  // Pause / Resume button — mutate in place so we never lose the DOM node
  const actionsEl = card.querySelector(".dl-actions");
  if (actionsEl) {
    const primaryBtn = actionsEl.querySelector('[data-action="pause"], [data-action="resume"]');
    const wantAction = isPaused ? "resume" : "pause";
    if (!primaryBtn) {
      // Shouldn't happen after build, but just in case:
      const btn = document.createElement("button");
      btn.className = "btn-icon";
      btn.dataset.action = wantAction;
      btn.dataset.id = dl.id;
      btn.innerHTML = isPaused ? SVG.play : SVG.pause;
      btn.title = isPaused ? "Resume" : "Pause";
      actionsEl.insertBefore(btn, actionsEl.firstChild);
    } else if (primaryBtn.dataset.action !== wantAction) {
      primaryBtn.dataset.action = wantAction;
      primaryBtn.title = isPaused ? "Resume" : "Pause";
      primaryBtn.innerHTML = isPaused ? SVG.play : SVG.pause;
    }
  }

  if (initial) {
    card.dataset.inited = "1";
  }
}

/* ---- Reconcile a list of active downloads into a container ---- */
function renderActive(container, list) {
  if (!container) return;

  // 1. Remove cards that are no longer in the list
  const wanted = new Set(list.map((d) => String(d.id)));
  Array.from(container.querySelectorAll(".download-card")).forEach((card) => {
    if (!wanted.has(card.dataset.id)) card.remove();
  });

  // 2. Empty state
  if (!list.length) {
    // Remove any stale cards, insert empty state once
    if (!container.querySelector(".empty")) {
      container.innerHTML = emptyState("No active downloads", "Paste a link above to get started.");
    }
    return;
  }
  const emptyEl = container.querySelector(".empty");
  if (emptyEl) emptyEl.remove();

  // 3. Create or update cards, and reorder
  list.forEach((dl, idx) => {
    const idStr = String(dl.id);
    let card = container.querySelector(`.download-card[data-id="${idStr}"]`);
    if (!card) {
      card = buildActiveCard(dl);
    } else {
      updateActiveCard(card, dl);
    }
    const currentAt = container.children[idx];
    if (currentAt !== card) {
      container.insertBefore(card, currentAt || null);
    }
  });
}

/* ---- History items — full innerHTML is fine; they don't tick ---- */
function historyItemHtml(item) {
  const { filename, totalSize, status, timestamp } = item;
  const s = String(status || "").toLowerCase();
  const isCompleted = s === "completed";
  const isPaused    = s === "paused";
  const isError     = s === "error";
  const isCancelled = s === "cancelled";

  let actions = "";
  if (isCompleted) {
    actions += `<button class="btn-icon" data-action="open" data-id="${item.id}" title="Open file">${SVG.external}</button>`;
    actions += `<button class="btn-icon" data-action="folder" data-id="${item.id}" title="Show in folder">${SVG.folder}</button>`;
  } else if (isPaused) {
    actions += `<button class="btn-icon" data-action="resume" data-id="${item.id}" title="Resume">${SVG.play}</button>`;
  } else if (isError || isCancelled) {
    actions += `<button class="btn-icon" data-action="retry" data-id="${item.id}" title="Retry">${SVG.retry}</button>`;
  }
  actions += `<button class="btn-icon danger" data-action="remove" data-id="${item.id}" title="Remove from history">${SVG.trash}</button>`;

  const meta = `${formatBytes(totalSize)}<span class="dot"></span>${formatDate(timestamp)}`;

  return `
    <div class="history-item" data-id="${item.id}">
      ${fileIconHtml(filename)}
      <div class="hi-info" data-action="details" data-id="${item.id}">
        <div class="hi-name" title="${escapeHtml(filename)}">${escapeHtml(filename)}</div>
        <div class="hi-meta">${meta}</div>
      </div>
      <div class="hi-status">${statusBadge(status)}</div>
      <div class="hi-actions">${actions}</div>
    </div>
  `;
}

function emptyState(title, desc) {
  return `
    <div class="empty">
      <div class="empty-icon">${SVG.downloadEmpty}</div>
      <div class="empty-title">${escapeHtml(title)}</div>
      <div class="empty-desc">${escapeHtml(desc)}</div>
    </div>
  `;
}

function renderHistory(container, list, emptyTitle = "Nothing here yet", emptyDesc = "Your downloads will appear here.") {
  if (!container) return;
  if (!list.length) {
    container.innerHTML = emptyState(emptyTitle, emptyDesc);
    return;
  }
  container.innerHTML = list.map(historyItemHtml).join("");
}

function getActiveList() {
  return Array.from(state.active.values()).sort((a, b) => (b.startedAt || 0) - (a.startedAt || 0));
}

/* ---- Update only the active containers (cheap, called on progress) ---- */
function renderActiveContainers() {
  const list = getActiveList();
  renderActive($("#active-list"), list);
  renderActive($("#active-view-list"), list);
  updateGlobalStatus();
}

/* ---- Full render (called on view change or status change) ---- */
function render() {
  const view = state.view;
  const all = state.history;

  if (view === "dashboard" || view === "active") {
    renderActiveContainers();
  }
  if (view === "dashboard") {
    renderHistory($("#recent-list"), all.slice(0, 5), "No downloads yet", "Your recent downloads will appear here.");
  }
  if (view === "all") {
    renderHistory($("#all-list"), all);
  }
  if (view === "completed") {
    const completed = all.filter((x) => String(x.status).toLowerCase() === "completed");
    renderHistory($("#completed-list"), completed, "No completed downloads", "Finished downloads will appear here.");
  }

  updateGlobalStatus();
  updateDirectoryLabels();
}

function updateGlobalStatus() {
  const badge = $("#active-badge");
  const n = state.active.size;
  if (badge) {
    badge.hidden = n === 0;
    badge.textContent = String(n);
  }
  const hint = $("#active-count-hint");
  if (hint) hint.textContent = n === 1 ? "1 active" : `${n} active`;

  const pill = $("#global-status");
  const pillText = $("#global-status-text");
  if (pill && pillText) {
    if (n > 0) {
      pill.classList.add("busy");
      pillText.textContent = n === 1 ? "Downloading" : `${n} downloading`;
    } else {
      pill.classList.remove("busy");
      pillText.textContent = "Ready";
    }
  }
}

function updateDirectoryLabels() {
  const label = state.directory || "Default Downloads";
  const saveDir = $("#save-dir-display");
  const settingsDir = $("#settings-dir");
  const sidebarEl = $("#sidebar-dir");
  if (saveDir) saveDir.textContent = label;
  if (settingsDir) settingsDir.textContent = label;
  if (sidebarEl) {
    sidebarEl.textContent = label;
    sidebarEl.title = state.directory || "";
  }
}

/* ================================================================
 *  History refresh + active pruning
 *
 *  IMPORTANT: keep Paused entries in the active list so the user can
 *  resume them from the Current Downloads section.
 * ================================================================ */
async function refreshHistory() {
  if (!window.api || !api.getHistory) return;
  try {
    state.history = await api.getHistory();

    for (const [id, entry] of Array.from(state.active.entries())) {
      const row = state.history.find((x) => x.id === id);
      if (!row) { state.active.delete(id); continue; }

      const st = String(row.status || "").toLowerCase();
      if (st === "downloading" || st === "preparing") {
        entry.status = st === "preparing" ? "Preparing" : "Downloading";
      } else if (st === "paused") {
        // Keep it visible so Resume is reachable from the active section
        entry.status = "Paused";
        entry.speedMBps = 0;
        entry.etaSeconds = 0;
      } else {
        // completed / cancelled / error — terminal, remove from active
        state.active.delete(id);
      }
    }

    render();
  } catch (err) {
    console.error("[flow] refreshHistory failed:", err);
  }
}

/* ---------------- Clipboard / input ---------------- */
async function handlePaste() {
  try {
    if (!window.api || !api.readClipboard) throw new Error("Clipboard API not available");
    const text = await api.readClipboard();
    if (!text || !text.trim()) { toast("Clipboard is empty", "warning"); return; }
    const input = $("#url-input");
    if (!input) return;
    input.value = text.trim();
    input.focus();
    input.setSelectionRange(input.value.length, input.value.length);
    toast("URL pasted successfully", "success");
  } catch (err) {
    console.error(err);
    toast("Could not read clipboard", "error");
  }
}

/* ---------------- Start download ---------------- */
async function handleDownload() {
  const input = $("#url-input");
  if (!input) return;
  const url = input.value.trim();

  if (!url) { toast("Please enter a URL", "warning"); input.focus(); return; }
  if (!isValidUrl(url)) { toast("Please enter a valid http(s) URL", "error"); input.focus(); return; }
  if (!window.api || !api.newDownload) { toast("Backend not available", "error"); return; }

  const btn = $("#download-btn");
  const original = btn ? btn.innerHTML : "";
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner"></span><span>Preparing…</span>`;
  }

  try {
    const res = await api.newDownload({ url, saveDirectory: state.directory });
    if (res && res.error) {
      toast(res.error, "error");
    } else if (res && res.id) {
      input.value = "";
      toast("Download started", "success");
      await refreshHistory();
    }
  } catch (err) {
    console.error(err);
    toast(err.message || "Failed to start download", "error");
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = original;
    }
  }
}

/* ---------------- Action dispatch ---------------- */
function findItem(id) {
  const numId = Number(id);
  const row = state.history.find((x) => x.id === numId);
  if (row) return row;
  const entry = state.active.get(numId);
  if (entry) {
    return {
      id: numId,
      filename: entry.filename,
      directory: entry.filePath,
      url: entry.url,
      totalSize: entry.totalSize,
      status: entry.status,
    };
  }
  return null;
}

async function handleAction(action, id) {
  const numId = Number(id);

  const key = `${action}:${numId}`;
  if (state.inflight.has(key)) return;
  state.inflight.add(key);

  try {
    switch (action) {
      /* ============ PAUSE ============ */
      case "pause": {
        const entry = state.active.get(numId);
        const res = await api.pauseDownload(numId);
        if (!res || res.success === false) {
          toast((res && res.error) || "Could not pause download", "error");
        } else {
          if (entry) entry.status = "Paused";
          // Reflect immediately without waiting for IPC round-trip
          renderActiveContainers();
          toast("Download paused", "info");
        }
        await refreshHistory();
        break;
      }

      /* ============ RESUME ============ */
      case "resume": {
        const item = findItem(numId);
        const res = await api.resumeDownload(numId);
        if (!res || res.success === false) {
          toast((res && res.error) || "Could not resume download", "error");
        } else {
          if (item) {
            state.active.set(numId, {
              id: numId,
              filename: item.filename,
              filePath: item.directory,
              totalSize: item.totalSize,
              percent: 0,
              speedMBps: 0,
              etaSeconds: 0,
              status: "Downloading",
              startedAt: Date.now(),
            });
            renderActiveContainers();
          }
          toast("Download resumed", "info");
        }
        await refreshHistory();
        break;
      }

      /* ============ CANCEL ============ */
      case "cancel": {
        const res = await api.cancelDownload(numId, true);
        if (!res || res.success === false) {
          toast((res && res.error) || "Could not cancel download", "error");
        } else {
          state.active.delete(numId);
          renderActiveContainers();
          toast("Download cancelled", "info");
        }
        await refreshHistory();
        break;
      }

      /* ============ REMOVE ============ */
      case "remove": {
        const res = await api.deleteDownload(numId, true);
        if (res && res.success) toast("Removed from history", "info");
        else if (res && res.error) toast(res.error, "warning");
        await refreshHistory();
        break;
      }

      /* ============ RETRY ============ */
      case "retry": {
        const res = await api.resumeDownload(numId);
        if (!res || res.success === false) {
          toast((res && res.error) || "Could not retry download", "error");
        } else {
          toast("Retrying download", "info");
        }
        await refreshHistory();
        break;
      }

      /* ============ OPEN / FOLDER / DETAILS ============ */
      case "open": {
        const item = findItem(numId);
        if (!item) break;
        const res = await api.openFile(item.directory);
        if (res && !res.success) toast(res.error || "File not found", "error");
        break;
      }
      case "folder": {
        const item = findItem(numId);
        if (!item) break;
        api.openFolder(item.directory);
        break;
      }
      case "details": {
        const item = findItem(numId);
        if (!item) break;
        openDetails(item);
        break;
      }

      default:
        break;
    }
  } catch (err) {
    console.error("[flow] action failed:", action, err);
    toast(err.message || "Action failed", "error");
  } finally {
    state.inflight.delete(key);
  }
}

/* ---------------- Details modal ---------------- */
function openDetails(item) {
  const set = (id, val) => { const el = $(id); if (el) el.textContent = val; };
  set("#det-name", item.filename || "—");
  const statusEl = $("#det-status");
  if (statusEl) statusEl.innerHTML = statusBadge(item.status);
  set("#det-size", formatBytes(item.totalSize));
  set("#det-date", formatDate(item.timestamp));
  set("#det-path", item.directory || "—");
  set("#det-url",  item.url || "—");
  const modal = $("#details-modal");
  if (modal) modal.classList.add("open");
}

function closeDetails() {
  const modal = $("#details-modal");
  if (modal) modal.classList.remove("open");
}

/* ---------------- Directory ---------------- */
async function chooseDirectory() {
  if (!window.api || !api.selectDirectory) return;
  const dir = await api.selectDirectory();
  if (!dir) return;
  state.directory = dir;
  updateDirectoryLabels();
  toast("Save folder updated", "success");
}

function resetDirectory() {
  state.directory = null;
  updateDirectoryLabels();
  toast("Reset to default folder", "info");
}

/* ================================================================
 *  IPC event wiring
 * ================================================================ */
function registerIpcListeners() {
  api.onDownloadStart((data) => {
    const id = data.id;
    state.active.set(id, {
      id,
      filename: data.fileName || data.filename || "download",
      filePath: data.filePath,
      totalSize: data.totalSize || 0,
      percent: 0,
      speedMBps: 0,
      etaSeconds: 0,
      status: "Downloading",
      startedAt: Date.now(),
    });
    renderActiveContainers();
    // History needs a refresh to show the new row
    refreshHistory();
  });

  api.onDownloadProgress((data) => {
    const id = data.id;
    let entry = state.active.get(id);
    if (!entry) {
      const row = state.history.find((x) => x.id === id);
      if (!row) return;
      // Don't resurrect cancelled/completed entries
      const s = String(row.status || "").toLowerCase();
      if (s !== "downloading" && s !== "preparing") return;
      entry = {
        id,
        filename: row.filename,
        filePath: row.directory,
        totalSize: row.totalSize,
        status: "Downloading",
        startedAt: Date.now(),
      };
      state.active.set(id, entry);
    }

    // Stale guard: don't overwrite a Paused status
    if (entry.status === "Paused") return;

    entry.percent    = Math.max(0, Math.min(100, parseFloat(data.percent) || 0));
    entry.speedMBps  = data.speedMBps || 0;
    entry.etaSeconds = data.etaSeconds || 0;
    entry.status     = "Downloading";

    // Cheap in-place update — never rebuild cards here.
    renderActiveContainers();
  });

  api.onDownloadError((data) => {
    state.active.delete(data.id);
    toast(data.message || "Download failed", "error");
    renderActiveContainers();
    refreshHistory();
  });

  api.onStatusChange(() => {
    refreshHistory();
  });
}

/* ================================================================
 *  Event listeners
 * ================================================================ */
function bindEvents() {
  $$(".nav-item").forEach((btn) => {
    btn.addEventListener("click", () => setView(btn.dataset.view));
  });

  document.addEventListener("click", (e) => {
    const goto = e.target.closest("[data-goto]");
    if (goto) setView(goto.dataset.goto);
  });

  on("#theme-toggle", "click", toggleTheme);
  on("#settings-theme-toggle", "click", toggleTheme);

  on("#paste-btn", "click", handlePaste);
  on("#download-btn", "click", handleDownload);
  on("#url-input", "keydown", (e) => {
    if (e.key === "Enter") handleDownload();
  });

  on("#quick-dir-btn", "click", chooseDirectory);
  on("#settings-choose-dir", "click", chooseDirectory);
  on("#settings-reset-dir", "click", resetDirectory);

  on("#modal-close", "click", closeDetails);
  on("#details-modal", "click", (e) => {
    if (e.target.id === "details-modal") closeDetails();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeDetails();
  });

  // Delegated download / history actions
  document.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-action]");
    if (!btn) return;
    const { action, id } = btn.dataset;
    if (!id) return;
    handleAction(action, id);
  });
}

/* ================================================================
 *  Fatal error display
 * ================================================================ */
function showFatal(message) {
  console.error("[flow] FATAL:", message);
  document.body.innerHTML = `
    <div style="padding:40px;font-family:ui-monospace,Menlo,monospace;color:#ef4444;background:#0b0d12;min-height:100vh;box-sizing:border-box;">
      <h1 style="margin:0 0 12px;">⚠️ Flow failed to start</h1>
      <pre style="white-space:pre-wrap;color:#f0f0f0;font-size:13px;">${escapeHtml(message)}</pre>
      <p style="color:#8a93a4;font-size:12px;margin-top:20px;">
        Open DevTools (Ctrl+Shift+I / Cmd+Option+I) to see the full error.
      </p>
    </div>`;
}

/* ================================================================
 *  Boot
 * ================================================================ */
async function boot() {
  if (!window.api) {
    showFatal(
      "window.api is undefined.\n\n" +
      "The preload script did not expose the API. Check:\n" +
      "  • preload.js exists next to main.js\n" +
      "  • main.js webPreferences.preload points to it\n" +
      "  • preload.js has no syntax errors (check DevTools)"
    );
    return;
  }

  try { applyTheme(); } catch (e) { console.error("[flow] applyTheme:", e); }
  try { bindEvents(); } catch (e) { console.error("[flow] bindEvents:", e); }

  try { registerIpcListeners(); } catch (e) {
    console.error("[flow] registerIpcListeners:", e);
    showFatal("Failed to register IPC listeners: " + e.message);
    return;
  }

  try {
    if (api.getDefaultDirectory) {
      state.defaultDirectory = await api.getDefaultDirectory();
    }
  } catch (e) { console.error("[flow] getDefaultDirectory:", e); }

  try { await refreshHistory(); } catch (e) { console.error(e); }
  try { setView("dashboard"); } catch (e) { console.error("[flow] setView:", e); }

  // No periodic full re-render — history items get updated via status-change
  // events from the main process, and active cards are updated by progress
  // events. This eliminates the flash on the history list during hover.
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", boot, { once: true });
} else {
  boot();
}