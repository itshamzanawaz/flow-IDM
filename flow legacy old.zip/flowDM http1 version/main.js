/* ================================================================
 *  Flow — Electron main process
 *  - IPC for UI + downloads + history
 *  - HTTP bridge for browser extension
 *  - Robust probe (HEAD → GET+Range fallback)
 *  - Linux-friendly window raising
 *  - Graceful shutdown (pauses all tasks)
 * ================================================================ */

const { app, BrowserWindow, ipcMain, dialog, shell, clipboard } = require("electron");
const path = require("path");
const Database = require("better-sqlite3");
const fs = require("fs");
const http = require("http");
const { exec } = require("child_process");

const {
  prepareDownload,
  startTask,
  pauseTask,
  cancelTask,
  pauseAll,
  removePartialFiles,
} = require("./downloader/downloadManager");

/* ---------------- Optional YouTube manager ---------------- */
let prepareYoutubeDownload, startYoutubeTask, pauseYoutubeTask;
try {
  ({
    prepareYoutubeDownload,
    startYoutubeTask,
    pauseYoutubeTask,
  } = require("./downloader/youtubeManager"));
} catch (err) {
  console.warn("[flow] youtubeManager not available:", err.message);
  prepareYoutubeDownload = async () => {
    throw new Error("YouTube downloads are not available in this build");
  };
  startYoutubeTask = async () => {
    throw new Error("YouTube downloads are not available in this build");
  };
  pauseYoutubeTask = () => {};
}

/* ---------------- Globals ---------------- */
let db;
let mainWindow;
let isQuitting = false;

const BRIDGE_PORT = 27812;
const BRIDGE_TOKEN = "flow-download-manager-secret-change-me"; // must match extension

/* ================================================================
 *  Database
 * ================================================================ */
function initDB() {
  const dbPath = path.join(app.getPath("userData"), "downloads.db");
  db = new Database(dbPath);

  db.exec(`
    CREATE TABLE IF NOT EXISTS history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      filename TEXT,
      directory TEXT,
      url TEXT,
      totalSize INTEGER,
      status TEXT,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  try { db.exec(`ALTER TABLE history ADD COLUMN url TEXT;`); } catch (e) {}
  try { db.exec(`ALTER TABLE history ADD COLUMN totalSize INTEGER;`); } catch (e) {}
}

/* ================================================================
 *  Window
 * ================================================================ */
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1100,
    height: 780,
    minWidth: 860,
    minHeight: 600,
    backgroundColor: "#0b0d12",
    titleBarStyle: process.platform === "darwin" ? "hiddenInset" : "default",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  mainWindow.loadFile("index.html");

  mainWindow.on("closed", () => {
    mainWindow = null;
  });

  return mainWindow;
}

/* ================================================================
 *  App lifecycle
 * ================================================================ */
app.whenReady().then(() => {
  initDB();
  startHttpBridge();
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

// Graceful shutdown: pause all running downloads so state is persisted
app.on("before-quit", async (e) => {
  if (isQuitting) return;
  isQuitting = true;
  e.preventDefault();
  try {
    await pauseAll();
  } catch (err) {
    console.error("[shutdown] pauseAll failed:", err.message);
  }
  app.exit(0);
});

/* ================================================================
 *  Utils
 * ================================================================ */
function isYouTubeUrl(url) {
  return (
    typeof url === "string" &&
    (url.includes("youtube.com") || url.includes("youtu.be"))
  );
}

/* ================================================================
 *  IPC: clipboard / directories / files
 * ================================================================ */
ipcMain.handle("read-clipboard", () => clipboard.readText());
ipcMain.handle("get-default-directory", () => app.getPath("downloads"));

ipcMain.handle("select-directory", async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog({
    properties: ["openDirectory"],
  });
  return canceled ? null : filePaths[0];
});

ipcMain.on("open-folder", (_event, filePath) => {
  if (filePath && fs.existsSync(filePath)) shell.showItemInFolder(filePath);
});

ipcMain.handle("open-file", async (_event, filePath) => {
  if (!filePath || !fs.existsSync(filePath)) {
    return { success: false, error: "File not found" };
  }
  const err = await shell.openPath(filePath);
  return err ? { success: false, error: err } : { success: true };
});

/* ================================================================
 *  IPC: history
 * ================================================================ */
ipcMain.handle("get-history", () => {
  try {
    return db.prepare("SELECT * FROM history ORDER BY timestamp DESC").all();
  } catch (err) {
    return [];
  }
});

ipcMain.handle("delete-download", async (event, id, deleteFile) => {
  const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
  if (!item) return { success: false, error: "Item not found" };

  const st = String(item.status || "").toLowerCase();
  if (st === "downloading" || st === "paused") {
    if (isYouTubeUrl(item.url)) {
      try { pauseYoutubeTask(id); } catch {}
    } else {
      try { await cancelTask(id); } catch {}
    }
  }

  db.prepare(`DELETE FROM history WHERE id = ?`).run(id);

  if (deleteFile) {
    try {
      if (fs.existsSync(item.directory)) fs.unlinkSync(item.directory);
      removePartialFiles(item.directory);
    } catch (err) {
      console.error("Failed to delete file:", err);
      event.sender.send("status-change");
      return {
        success: false,
        error: "Removed from history, but failed to delete physical file.",
      };
    }
  }

  event.sender.send("status-change");
  return { success: true };
});

/* ================================================================
 *  Task completion wrapper
 * ================================================================ */
async function handleTaskCompletion(id, taskPromise, sender) {
  const safeSender = sender && typeof sender.send === "function"
    ? sender
    : { send: () => {} };

  try {
    const result = await taskPromise;
    if (!result) return;

    if (result.success) {
      db.prepare(`UPDATE history SET status = 'Completed' WHERE id = ?`).run(id);
      safeSender.send("status-change");
    } else if (result.paused) {
      safeSender.send("status-change");
    } else if (result.cancelled) {
      safeSender.send("status-change");
    } else if (result.error) {
      db.prepare(`UPDATE history SET status = 'Error' WHERE id = ?`).run(id);
      safeSender.send("download-error", { id, message: result.error });
      safeSender.send("status-change");
    }
  } catch (err) {
    db.prepare(`UPDATE history SET status = 'Error' WHERE id = ?`).run(id);
    safeSender.send("download-error", { id, message: err.message || String(err) });
    safeSender.send("status-change");
  }
}

/* ================================================================
 *  IPC: new-download
 * ================================================================ */
ipcMain.handle("new-download", async (event, { url, saveDirectory }) => {
  try {
    if (!url || typeof url !== "string") {
      return { error: "Missing or invalid URL." };
    }

    const dir = saveDirectory || app.getPath("downloads");
    const isYt = isYouTubeUrl(url);

    let fileInfo;
    if (isYt) {
      fileInfo = await prepareYoutubeDownload(url, dir);
    } else {
      fileInfo = await prepareDownload(url, dir);
    }

    const stmt = db.prepare(
      `INSERT INTO history (filename, directory, url, totalSize, status)
       VALUES (?, ?, ?, ?, ?)`
    );
    const info = stmt.run(
      fileInfo.fileName,
      fileInfo.filePath,
      url,
      fileInfo.totalSize || 0,
      "Downloading"
    );
    const dbId = info.lastInsertRowid;

    event.sender.send("download-start", { id: dbId, ...fileInfo });
    event.sender.send("status-change");

    if (isYt) {
      handleTaskCompletion(
        dbId,
        startYoutubeTask(dbId, url, fileInfo.filePath, event.sender),
        event.sender
      );
    } else {
      handleTaskCompletion(
        dbId,
        startTask(dbId, url, fileInfo.filePath, fileInfo.totalSize, event.sender),
        event.sender
      );
    }

    return { id: dbId };
  } catch (err) {
    return { error: err.message || String(err) };
  }
});

/* ================================================================
 *  IPC: pause-download
 * ================================================================ */
ipcMain.handle("pause-download", async (event, id) => {
  const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
  if (!item) return { success: false, error: "Item not found" };

  const st = String(item.status || "").toLowerCase();
  if (st === "paused") return { success: true, alreadyPaused: true };
  if (st === "completed") return { success: false, error: "Download already completed" };
  if (st === "cancelled") return { success: false, error: "Download was cancelled" };

  let res;
  if (isYouTubeUrl(item.url)) {
    try { pauseYoutubeTask(id); } catch {}
    res = { success: true };
  } else {
    res = await pauseTask(id);
  }

  if (res && res.success === false) {
    return { success: false, error: res.error || "Could not pause download" };
  }

  db.prepare(`UPDATE history SET status = 'Paused' WHERE id = ?`).run(id);
  event.sender.send("status-change");
  return { success: true };
});

/* ================================================================
 *  IPC: resume-download
 * ================================================================ */
ipcMain.handle("resume-download", async (event, id) => {
  const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
  if (!item) return { success: false, error: "Item not found" };

  const st = String(item.status || "").toLowerCase();
  if (st === "downloading" || st === "preparing") {
    return { success: false, error: "Already downloading" };
  }
  if (st === "completed") {
    return { success: false, error: "Download already completed" };
  }

  db.prepare(`UPDATE history SET status = 'Downloading' WHERE id = ?`).run(id);
  event.sender.send("status-change");

  if (isYouTubeUrl(item.url)) {
    handleTaskCompletion(
      id,
      startYoutubeTask(id, item.url, item.directory, event.sender),
      event.sender
    );
  } else {
    handleTaskCompletion(
      id,
      startTask(id, item.url, item.directory, item.totalSize, event.sender),
      event.sender
    );
  }
  return { success: true };
});

/* ================================================================
 *  IPC: cancel-download
 * ================================================================ */
ipcMain.handle("cancel-download", async (event, id, deletePartial = true) => {
  const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
  if (!item) return { success: false, error: "Item not found" };

  const st = String(item.status || "").toLowerCase();
  if (st === "completed") {
    return { success: false, error: "Download already completed" };
  }

  if (isYouTubeUrl(item.url)) {
    try { pauseYoutubeTask(id); } catch {}
  } else {
    const res = await cancelTask(id);
    if (res && res.success === false) {
      console.warn("[main] cancelTask:", res.error);
    }
  }

  db.prepare(`UPDATE history SET status = 'Cancelled' WHERE id = ?`).run(id);

  if (deletePartial) removePartialFiles(item.directory);

  event.sender.send("status-change");
  return { success: true };
});

/* ================================================================
 *  IPC: refresh-link
 * ================================================================ */
ipcMain.handle("refresh-link", async (event, id, newUrl) => {
  if (!newUrl || typeof newUrl !== "string") {
    return { success: false, error: "Invalid URL" };
  }

  db.prepare(`UPDATE history SET url = ? WHERE id = ?`).run(newUrl, id);
  const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
  if (!item) return { success: false, error: "Item not found" };

  db.prepare(`UPDATE history SET status = 'Downloading' WHERE id = ?`).run(id);
  event.sender.send("status-change");

  if (isYouTubeUrl(item.url)) {
    handleTaskCompletion(
      id,
      startYoutubeTask(id, item.url, item.directory, event.sender),
      event.sender
    );
  } else {
    handleTaskCompletion(
      id,
      startTask(id, item.url, item.directory, item.totalSize, event.sender),
      event.sender
    );
  }
  return { success: true };
});

/* ================================================================
 *  Bring app window to front (Linux-friendly)
 * ================================================================ */
function bringToFront() {
  if (!mainWindow || mainWindow.isDestroyed()) {
    console.warn("[focus] no main window to raise");
    return;
  }

  try {
    if (mainWindow.isMinimized()) mainWindow.restore();
    if (!mainWindow.isVisible()) mainWindow.show();

    mainWindow.setAlwaysOnTop(true, "floating");
    mainWindow.focus();
    mainWindow.moveTop();
    mainWindow.flashFrame(true);

    // X11 fallback for window managers that ignore alwaysOnTop
    if (process.platform === "linux" && process.env.DISPLAY) {
      exec(
        `xdotool search --name "Flow" windowactivate --sync %@ 2>/dev/null || true`,
        () => {}
      );
    }

    setTimeout(() => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.setAlwaysOnTop(false);
        mainWindow.flashFrame(false);
      }
    }, 700);

    console.log("[focus] bringToFront invoked");
  } catch (err) {
    console.warn("[focus] failed:", err.message);
  }
}

/* ================================================================
 *  HTTP Bridge for browser extension
 * ================================================================ */
function startHttpBridge() {
  const server = http.createServer((req, res) => {
    // CORS
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-Flow-Token");

    console.log(`[http-bridge] ${req.method} ${req.url}`);

    if (req.method === "OPTIONS") {
      res.writeHead(204);
      return res.end();
    }

    // Health check
    if (req.method === "GET" && req.url === "/health") {
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ ok: true, app: "flow" }));
    }

    if (req.method !== "POST" || req.url !== "/download") {
      res.writeHead(404, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ error: "Not found" }));
    }

    const token = req.headers["x-flow-token"];
    if (token !== BRIDGE_TOKEN) {
      console.warn("[http-bridge] Rejecting request: bad or missing token");
      res.writeHead(403, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ error: "Forbidden — token mismatch" }));
    }

    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 5 * 1024 * 1024) req.destroy();
    });
    req.on("end", async () => {
      try {
        const parsed = JSON.parse(body);
        console.log("[http-bridge] Payload:", {
          url: parsed.url,
          cookiesLen: (parsed.cookies || "").length,
          referrer: parsed.referrer,
        });

        const result = await handleBridgeDownload(parsed);

        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify(result));
      } catch (err) {
        console.error("[http-bridge] Handler error:", err.message);
        res.writeHead(400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ success: false, error: err.message }));
      }
    });
  });

  server.on("error", (err) => {
    console.error("[http-bridge] Server error:", err.message);
    if (err.code === "EADDRINUSE") {
      console.error(
        `[http-bridge] Port ${BRIDGE_PORT} already in use. Kill the other process or change the port.`
      );
    }
  });

  server.listen(BRIDGE_PORT, "127.0.0.1", () => {
    console.log(`[http-bridge] Listening on http://127.0.0.1:${BRIDGE_PORT}`);
  });
}

/* ================================================================
 *  Bridge download handler
 * ================================================================ */
async function handleBridgeDownload({ url, cookies, referrer, filename }) {
  if (!url || typeof url !== "string") {
    throw new Error("Missing or invalid 'url' in payload.");
  }

  console.log("[bridge] handleBridgeDownload start for", url);

  // Bring the window forward FIRST
  bringToFront();

  const dir = app.getPath("downloads");
  const extraHeaders = {};
  if (cookies) extraHeaders["Cookie"] = String(cookies).slice(0, 8000);
  if (referrer) extraHeaders["Referer"] = referrer;
  if (filename) extraHeaders["X-Flow-Filename-Hint"] = filename;

  // Probe the server
  let fileInfo;
  try {
    fileInfo = await prepareDownload(url, dir, extraHeaders);
    console.log("[bridge] prepareDownload OK:", fileInfo);
  } catch (err) {
    console.error("[bridge] prepareDownload FAILED:", err.message);

    if (mainWindow && !mainWindow.isDestroyed()) {
      try {
        mainWindow.webContents.send("download-error", {
          id: -1,
          message: `Could not start captured download: ${err.message}`,
        });
      } catch {}
    }

    // Re-throw so the HTTP response carries the error
    throw err;
  }

  // Insert into DB
  const stmt = db.prepare(
    `INSERT INTO history (filename, directory, url, totalSize, status)
     VALUES (?, ?, ?, ?, ?)`
  );
  const info = stmt.run(
    fileInfo.fileName,
    fileInfo.filePath,
    url,
    fileInfo.totalSize || 0,
    "Downloading"
  );
  const dbId = info.lastInsertRowid;
  console.log("[bridge] Inserted history row id =", dbId);

  const sender =
    mainWindow && !mainWindow.isDestroyed() && mainWindow.webContents
      ? mainWindow.webContents
      : { send: () => {} };

  try {
    sender.send("download-start", { id: dbId, ...fileInfo });
    sender.send("status-change");
  } catch (e) {
    console.warn("[bridge] Could not notify renderer:", e.message);
  }

  handleTaskCompletion(
    dbId,
    startTask(dbId, url, fileInfo.filePath, fileInfo.totalSize, sender, extraHeaders),
    sender
  );

  return { success: true, id: dbId, filename: fileInfo.fileName };
}