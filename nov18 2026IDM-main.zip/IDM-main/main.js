/* ================================================================
 *  Flow — Electron main process entry point
 *
 *  This file is a thin shim. All logic lives under ./main/.
 * ================================================================ */

require("./main/index.js");