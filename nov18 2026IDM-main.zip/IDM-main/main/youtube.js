/* ================================================================
 *  Flow — optional YouTube manager loader
 *
 *  If ./downloader/youtubeManager.js is missing (e.g. yt-dlp not
 *  installed in a minimal build), we install no-op fallbacks so the
 *  rest of the app still boots cleanly.
 * ================================================================ */

let prepareYoutubeDownload, startYoutubeTask, pauseYoutubeTask;

try {
  ({
    prepareYoutubeDownload,
    startYoutubeTask,
    pauseYoutubeTask,
  } = require("../downloader/youtubeManager"));
} catch (err) {
  console.warn("[flow] youtubeManager not available:", err.message);
  prepareYoutubeDownload = async () => {
    throw new Error("YouTube downloads are not available in this build");
  };
  startYoutubeTask = async () => {
    throw new Error("YouTube downloads are not available in this build");
  };
  pauseYoutubeTask = () => {};
}

module.exports = { prepareYoutubeDownload, startYoutubeTask, pauseYoutubeTask };