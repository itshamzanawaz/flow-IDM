/* ================================================================
 *  Flow — SQLite history store
 *
 *  initDB() runs once at app startup. The startup reconciliation
 *  downgrades ALL incomplete rows to "Paused" so the app NEVER
 *  auto-starts downloads on boot.
 *
 *  The `error` column stores the last terminal error message so the
 *  renderer can distinguish "URL expired" (needs fresh URL) from a
 *  generic network failure (plain retry is fine).
 * ================================================================ */

const path = require("path");
const Database = require("better-sqlite3");
const { app } = require("electron");

let db = null;

function initDB() {
  const dbPath = path.join(app.getPath("userData"), "downloads.db");
  db = new Database(dbPath);

  db.exec(`
    CREATE TABLE IF NOT EXISTS history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      filename TEXT,
      directory TEXT,
      url TEXT,
      totalSize INTEGER,
      status TEXT,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  try { db.exec(`ALTER TABLE history ADD COLUMN url TEXT;`); } catch (e) {}
  try { db.exec(`ALTER TABLE history ADD COLUMN totalSize INTEGER;`); } catch (e) {}
  try { db.exec(`ALTER TABLE history ADD COLUMN error TEXT;`); } catch (e) {}

  try {
    const res = db.prepare(`
      UPDATE history 
      SET status = 'Paused' 
      WHERE LOWER(status) NOT IN ('completed', 'cancelled', 'error')
    `).run();

    if (res.changes > 0) {
      console.log(`[flow] Reconciled ${res.changes} interrupted download(s) to Paused`);
    }
  } catch (err) {
    console.warn("[flow] startup reconciliation failed:", err.message);
  }
}

function getDB() {
  if (!db) throw new Error("Database not initialized");
  return db;
}

module.exports = { initDB, getDB };