/* ================================================================
 *  Flow — main-process constants
 * ================================================================ */

module.exports = {
  BRIDGE_PORT: 27812,
  BRIDGE_TOKEN: "flow-download-manager-secret-change-me",
};