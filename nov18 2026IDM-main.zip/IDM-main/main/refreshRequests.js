/* ================================================================
 *  Flow — pending URL refresh requests
 *
 *  When a download needs a fresh URL (expired signed link), the
 *  renderer calls IPC `request-fresh-url`. That registers a pending
 *  entry here. The extension polls the bridge's /pending-refresh
 *  endpoint and sees the entry, shows a browser notification, and —
 *  when the user re-clicks Download on the site — sends the new URL
 *  back to the bridge with `resumeId: <pendingId>`.
 *
 *  The bridge calls `resolve(pendingId, url)` which emits the
 *  "resolved" event, unblocking the IPC handler's promise.
 * ================================================================ */

const { EventEmitter } = require("events");
const crypto = require("crypto");

class RefreshRequestStore extends EventEmitter {
  constructor() {
    super();
    /** @type {Map<string, object>} */
    this.pending = new Map();
  }

  add({ downloadId, filename, totalSize, refererOrigin, timeoutMs = 120000 }) {
    const id = crypto.randomBytes(12).toString("hex");
    const entry = {
      id,
      downloadId: Number(downloadId),
      filename: filename || "download",
      totalSize: Number(totalSize) || 0,
      refererOrigin: refererOrigin || "",
      createdAt: Date.now(),
      timer: null,
    };
    entry.timer = setTimeout(() => {
      if (this.pending.has(id)) {
        this.pending.delete(id);
        this.emit("expired", { id, downloadId: entry.downloadId });
      }
    }, timeoutMs);
    if (entry.timer.unref) entry.timer.unref();
    this.pending.set(id, entry);
    return id;
  }

  list() {
    return Array.from(this.pending.values()).map((e) => ({
      id: e.id,
      downloadId: e.downloadId,
      filename: e.filename,
      totalSize: e.totalSize,
      refererOrigin: e.refererOrigin,
      requestedAt: e.createdAt,
    }));
  }

  /** Called from bridge when extension POSTs /download with resumeId. */
  resolve(id, url, cookies, referrer) {
    const entry = this.pending.get(id);
    if (!entry) return null;
    this.pending.delete(id);
    if (entry.timer) clearTimeout(entry.timer);
    this.emit("resolved", {
      id,
      downloadId: entry.downloadId,
      url,
      cookies: cookies || null,
      referrer: referrer || null,
    });
    return entry;
  }

  cancel(id) {
    const entry = this.pending.get(id);
    if (!entry) return false;
    this.pending.delete(id);
    if (entry.timer) clearTimeout(entry.timer);
    this.emit("cancelled", { id, downloadId: entry.downloadId });
    return true;
  }

  cancelForDownload(downloadId) {
    const n = Number(downloadId);
    let cancelled = 0;
    for (const [id, e] of Array.from(this.pending.entries())) {
      if (e.downloadId === n) {
        this.cancel(id);
        cancelled++;
      }
    }
    return cancelled;
  }

  findForDownload(downloadId) {
    const n = Number(downloadId);
    for (const e of this.pending.values()) {
      if (e.downloadId === n) return e;
    }
    return null;
  }
}

module.exports = new RefreshRequestStore();