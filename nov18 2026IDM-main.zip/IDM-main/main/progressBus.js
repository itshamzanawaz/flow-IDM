/* ================================================================
 *  Flow — progress event bus
 *
 *  Decouples the download manager's sender from any particular
 *  BrowserWindow. bridge.js and ipc/downloads.js wrap their senders
 *  to emit `download-progress` here; downloadWindow.js subscribes
 *  and forwards to the matching per-download window. taskCompletion
 *  emits `state-change` here on every terminal transition.
 *
 *  Payload shape for "progress": { id:<number>, percent, speedMBps,
 *    etaSeconds, downloaded, totalSize }
 *  Payload shape for "state-change": { id:<number>, to:<string>,
 *    error?:<string> }
 * ================================================================ */

const { EventEmitter } = require("events");

const bus = new EventEmitter();
bus.setMaxListeners(64);

module.exports = bus;