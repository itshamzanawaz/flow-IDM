/* ================================================================
 *  Flow — system tray
 *
 *  The tray is the user's access point whenever the window is
 *  hidden. Left/double click raise the window; the context menu
 *  exposes "Show Flow", the current active count, "Pause all"
 *  (visible only when something is downloading), the two settings
 *  toggles, and "Quit Flow".
 *
 *  The icon is generated programmatically so no asset files are
 *  required. A 32×32 PNG is assembled from a handful of scanlines,
 *  zlib-deflated, and wrapped in proper IHDR/IDAT/IEND chunks.
 *
 *  The active count is refreshed every 2 s from SQLite. The menu is
 *  only rebuilt when the count or a toggle changes, to avoid menu
 *  flicker on Linux.
 * ================================================================ */

const zlib = require("zlib");

/* ---------------- CRC32 (PNG) ---------------- */
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, "ascii");
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

/* ---------------- Programmatic tray icon ---------------- */
function buildTrayIcon(nativeImage) {
  const SIZE = 32;
  const raw = Buffer.alloc((SIZE * 4 + 1) * SIZE);
  let p = 0;
  for (let y = 0; y < SIZE; y++) {
    raw[p++] = 0; // filter byte
    for (let x = 0; x < SIZE; x++) {
      let r = 0, g = 0, b = 0, a = 0;
      const dx = x - 15.5;
      const dy = y - 15.5;
      const inside = dx * dx + dy * dy <= 15 * 15;
      if (inside) {
        // White downward-arrow glyph inside a brand-indigo circle.
        const stem = x >= 14 && x <= 17 && y >= 8 && y <= 17;
        const tY = y - 16;
        let tri = false;
        if (tY >= 0 && tY < 8) {
          const halfW = 8 - tY;
          tri = Math.abs(x - 15.5) <= halfW;
        }
        if (stem || tri) {
          r = 255; g = 255; b = 255; a = 255;
        } else {
          r = 99; g = 102; b = 241; a = 255; // #6366f1
        }
      }
      raw[p++] = r;
      raw[p++] = g;
      raw[p++] = b;
      raw[p++] = a;
    }
  }

  const idat = zlib.deflateSync(raw);
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(SIZE, 0);
  ihdr.writeUInt32BE(SIZE, 4);
  ihdr[8] = 8;   // bit depth
  ihdr[9] = 6;   // color type: RGBA
  ihdr[10] = 0;  // compression
  ihdr[11] = 0;  // filter
  ihdr[12] = 0;  // interlace

  const png = Buffer.concat([
    sig,
    pngChunk("IHDR", ihdr),
    pngChunk("IDAT", idat),
    pngChunk("IEND", Buffer.alloc(0)),
  ]);

  return nativeImage.createFromBuffer(png);
}

/* ---------------- Tray lifecycle ---------------- */
let tray = null;
let pollTimer = null;
let onShowCb = null;
let lastSig = "";

function createTray({ onShow }) {
  const { Tray, nativeImage } = require("electron");
  onShowCb = onShow;

  tray = new Tray(buildTrayIcon(nativeImage));
  tray.setToolTip("Flow — download manager");

  // Best-effort on Linux; the menu is the primary access path there.
  tray.on("click", () => onShowCb && onShowCb());
  tray.on("double-click", () => onShowCb && onShowCb());

  refreshMenu();
  pollTimer = setInterval(refreshMenu, 2000);
  if (pollTimer.unref) pollTimer.unref();
  return true;
}

function refreshMenu() {
  if (!tray) return;
  const { Menu } = require("electron");
  const settings = require("./settings");
  const { getDB } = require("./database");

  let active = 0;
  try {
    active = getDB()
      .prepare(
        "SELECT COUNT(*) AS n FROM history WHERE LOWER(status) IN ('downloading','preparing')"
      )
      .get().n || 0;
  } catch {}

  const startAtLogin = !!settings.get("startAtLogin");
  const minimizeToTray = !!settings.get("minimizeToTray");
  const sig = `${active}|${startAtLogin}|${minimizeToTray}`;
  if (sig === lastSig) return;
  lastSig = sig;

  const template = [
    {
      label: "Show Flow",
      click: () => onShowCb && onShowCb(),
    },
    { type: "separator" },
    {
      label: active > 0 ? `Active: ${active}` : "No active downloads",
      enabled: false,
    },
  ];

  if (active > 0) {
    template.push({
      label: "Pause all",
      click: async () => {
        try {
          await require("../downloader/downloadManager").pauseAll();
        } catch (err) {
          console.warn("[tray] pauseAll failed:", err.message);
        }
        lastSig = ""; // force refresh
        refreshMenu();
      },
    });
  }

  template.push(
    { type: "separator" },
    {
      label: "Start at login",
      type: "checkbox",
      checked: startAtLogin,
      click: (item) => {
        settings.set("startAtLogin", !!item.checked);
        lastSig = "";
        refreshMenu();
      },
    },
    {
      label: "Minimize to tray on close",
      type: "checkbox",
      checked: minimizeToTray,
      click: (item) => {
        settings.set("minimizeToTray", !!item.checked);
        lastSig = "";
        refreshMenu();
      },
    },
    { type: "separator" },
    {
      label: "Quit Flow",
      click: () => {
        try { require("electron").app.quit(); } catch {}
      },
    }
  );

  tray.setContextMenu(Menu.buildFromTemplate(template));
}

function destroyTray() {
  if (pollTimer) {
    clearInterval(pollTimer);
    pollTimer = null;
  }
  if (tray) {
    try { tray.destroy(); } catch {}
    tray = null;
  }
  lastSig = "";
}

module.exports = { createTray, destroyTray };