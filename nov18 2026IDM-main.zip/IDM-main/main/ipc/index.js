/* ================================================================
 *  Flow — register all IPC handlers in one place
 * ================================================================ */

const { registerClipboardHandlers }   = require("./clipboard");
const { registerDirectoryHandlers }   = require("./directories");
const { registerFileHandlers }        = require("./files");
const { registerHistoryHandlers }     = require("./history");
const { registerDownloadHandlers }    = require("./downloads");
const { registerSettingsHandlers }    = require("./settings");

function registerAllIpcHandlers() {
  registerClipboardHandlers();
  registerDirectoryHandlers();
  registerFileHandlers();
  registerHistoryHandlers();
  registerDownloadHandlers();
  registerSettingsHandlers();
}

module.exports = { registerAllIpcHandlers };