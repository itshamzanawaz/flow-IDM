/* ================================================================
 *  Flow — settings IPC handlers
 * ================================================================ */

const { ipcMain, app } = require("electron");
const settings = require("../settings");

function registerSettingsHandlers() {
  ipcMain.on("open-settings-window", () => {
    require("../window").createSettingsWindow();
  });

  ipcMain.handle("get-settings", () => ({
    startAtLogin: !!settings.get("startAtLogin"),
    minimizeToTray: !!settings.get("minimizeToTray"),
    platform: process.platform,
  }));

  ipcMain.handle("set-start-at-login", (_event, value) => {
    try {
      settings.set("startAtLogin", !!value);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  ipcMain.handle("set-minimize-to-tray", (_event, value) => {
    try {
      settings.set("minimizeToTray", !!value);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  ipcMain.handle("quit-app", () => {
    setImmediate(() => app.quit());
    return { success: true };
  });
}

module.exports = { registerSettingsHandlers };