/* ================================================================
 *  Flow — download lifecycle IPC handlers
 *
 *  New IPC:
 *    request-fresh-url  — renderer asks main to auto-capture a fresh
 *                         URL from the browser extension. Returns a
 *                         promise that resolves when the extension
 *                         delivers a URL (or times out).
 *    cancel-fresh-url-request  — renderer cancels the wait.
 *
 *  Auto-open: every NEW download opens its dedicated window.
 * ================================================================ */

const { ipcMain, app, BrowserWindow } = require("electron");
const fs = require("fs");
const path = require("path");

const { getDB } = require("../database");
const { isYouTubeUrl } = require("../media");
const {
  prepareYoutubeDownload,
  startYoutubeTask,
  pauseYoutubeTask,
} = require("../youtube");
const {
  prepareDownload,
  startTask,
  pauseTask,
  cancelTask,
  removePartialFiles,
} = require("../../downloader/downloadManager");
const {
  clearLingeringTask,
  handleTaskCompletion,
} = require("../taskCompletion");
const { getMainWindow } = require("../window");
const progressBus = require("../progressBus");
const { createDownloadWindow, ensureWindowOpen } = require("../downloadWindow");
const refreshRequests = require("../refreshRequests");

const PREPARE_TIMEOUT_MS = 60000;
const RESUME_CLEANUP_TIMEOUT_MS = 6000;

function withTimeout(promise, ms, label) {
  return Promise.race([
    promise,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`${label} timed out after ${ms / 1000}s`)), ms)
    ),
  ]);
}

function busSender(webContents) {
  const alive = () => webContents && !webContents.isDestroyed();
  return {
    send: (channel, payload) => {
      if (channel === "download-progress" && payload) {
        try { progressBus.emit("progress", payload); } catch {}
      }
      if (alive()) {
        try { webContents.send(channel, payload); } catch {}
      }
    },
    isDestroyed: () => !alive(),
  };
}

function primarySender(event) {
  const mainWin = getMainWindow();
  if (mainWin && !mainWin.isDestroyed()) return busSender(mainWin.webContents);
  return busSender(event.sender);
}

function broadcastStatusChange() {
  for (const win of BrowserWindow.getAllWindows()) {
    if (win && !win.isDestroyed()) {
      try { win.webContents.send("status-change"); } catch {}
    }
  }
}

function validatorsFromProbe(fileInfo, saveDirectory) {
  return {
    etag: fileInfo.etag || null,
    lastModified: fileInfo.lastModified || null,
    validator: fileInfo.validator || null,
    contentType: fileInfo.contentType || null,
    finalUrl: fileInfo.finalUrl || null,
    resumable: fileInfo.resumable !== false,
    saveDirectory: saveDirectory || null,
  };
}

function registerDownloadHandlers() {
  /* ---------------- new-download ---------------- */
  ipcMain.handle("new-download", async (event, { url, saveDirectory }) => {
    try {
      if (!url || typeof url !== "string") return { error: "Missing or invalid URL." };

      const dir = saveDirectory || app.getPath("downloads");
      const isYt = isYouTubeUrl(url);

      const fileInfo = isYt
        ? await prepareYoutubeDownload(url, dir)
        : await withTimeout(prepareDownload(url, dir), PREPARE_TIMEOUT_MS, "Preparing download");

      const stmt = getDB().prepare(
        `INSERT INTO history (filename, directory, url, totalSize, status, error)
         VALUES (?, ?, ?, ?, ?, NULL)`
      );
      const info = stmt.run(
        fileInfo.fileName,
        fileInfo.filePath,
        url,
        fileInfo.totalSize || 0,
        "Downloading"
      );
      const dbId = info.lastInsertRowid;

      const sender = primarySender(event);
      sender.send("download-start", { id: dbId, ...fileInfo });
      broadcastStatusChange();

      if (isYt) {
        handleTaskCompletion(
          dbId,
          startYoutubeTask(dbId, url, fileInfo.filePath, event.sender),
          sender
        );
      } else {
        handleTaskCompletion(
          dbId,
          startTask(
            dbId, url, fileInfo.filePath, fileInfo.totalSize,
            sender, {}, validatorsFromProbe(fileInfo, dir)
          ),
          sender
        );
      }

      // Auto-open the dedicated window for every new download.
      try { ensureWindowOpen(dbId); } catch (err) {
        console.warn("[main] could not open download window:", err.message);
      }

      return { id: dbId };
    } catch (err) {
      return { error: err.message || String(err) };
    }
  });

  /* ---------------- pause-download ---------------- */
  ipcMain.handle("pause-download", async (event, id) => {
    const db = getDB();
    const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
    if (!item) return { success: false, error: "Item not found" };

    const st = String(item.status || "").toLowerCase();
    if (st === "paused") return { success: true, alreadyPaused: true };
    if (st === "completed") return { success: false, error: "Download already completed" };
    if (st === "cancelled") return { success: false, error: "Download was cancelled" };

    db.prepare(`UPDATE history SET status = 'Paused' WHERE id = ?`).run(id);

    if (isYouTubeUrl(item.url)) {
      try { pauseYoutubeTask(id); } catch (err) {
        console.warn("[main] pauseYoutubeTask:", err.message);
      }
      progressBus.emit("state-change", { id: Number(id), to: "paused" });
    } else {
      try {
        const res = await pauseTask(id);
        if (res && res.success === false) console.warn("[main] pauseTask:", res.error);
        else progressBus.emit("state-change", { id: Number(id), to: "paused" });
      } catch (err) {
        console.warn("[main] pauseTask failed:", err.message);
      }
    }

    broadcastStatusChange();
    return { success: true };
  });

  /* ---------------- resume-download ---------------- */
  ipcMain.handle("resume-download", async (event, id) => {
    const db = getDB();
    const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
    if (!item) return { success: false, error: "Item not found" };

    const st = String(item.status || "").toLowerCase();
    if (st === "downloading" || st === "preparing") return { success: false, error: "Already downloading" };
    if (st === "completed") return { success: false, error: "Download already completed" };

    try {
      await withTimeout(clearLingeringTask(id), RESUME_CLEANUP_TIMEOUT_MS, "Resume cleanup");
    } catch (err) {
      console.warn("[main] clearLingeringTask time-boxed out:", err.message);
    }

    db.prepare(`UPDATE history SET status = 'Downloading', error = NULL WHERE id = ?`).run(id);
    broadcastStatusChange();
    progressBus.emit("state-change", { id: Number(id), to: "downloading" });

    const sender = primarySender(event);
    const saveDir = path.dirname(item.directory || "");

    let taskPromise;
    try {
      if (isYouTubeUrl(item.url)) {
        taskPromise = startYoutubeTask(id, item.url, item.directory, event.sender);
      } else {
        taskPromise = startTask(
          id, item.url, item.directory, item.totalSize,
          sender, {}, { saveDirectory: saveDir }
        );
      }
    } catch (err) {
      db.prepare(`UPDATE history SET status = 'Paused' WHERE id = ?`).run(id);
      broadcastStatusChange();
      progressBus.emit("state-change", { id: Number(id), to: "paused" });
      return { success: false, error: err.message || String(err) };
    }

    handleTaskCompletion(id, taskPromise, sender, { restoreOnError: "Paused" });
    return { success: true };
  });

  /* ---------------- cancel-download ---------------- */
  ipcMain.handle("cancel-download", async (event, id, deletePartial = true) => {
    const db = getDB();
    const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
    if (!item) return { success: false, error: "Item not found" };

    const st = String(item.status || "").toLowerCase();
    if (st === "completed") return { success: false, error: "Download already completed" };

    db.prepare(`UPDATE history SET status = 'Cancelled', error = NULL WHERE id = ?`).run(id);
    refreshRequests.cancelForDownload(id);

    if (isYouTubeUrl(item.url)) {
      try { pauseYoutubeTask(id); } catch {}
    } else {
      try {
        const res = await cancelTask(id);
        if (res && res.success === false) console.warn("[main] cancelTask:", res.error);
      } catch (err) {
        console.warn("[main] cancelTask failed:", err.message);
      }
    }

    progressBus.emit("state-change", { id: Number(id), to: "cancelled" });

    if (deletePartial) {
      setTimeout(() => {
        try { removePartialFiles(item.directory); } catch {}
      }, 300);
    }

    broadcastStatusChange();
    return { success: true };
  });

  /* ---------------- refresh-link (manual paste) ---------------- */
  ipcMain.handle("refresh-link", async (event, id, newUrl) => {
    if (!newUrl || typeof newUrl !== "string") {
      return { success: false, error: "Invalid URL" };
    }

    try {
      await withTimeout(clearLingeringTask(id), RESUME_CLEANUP_TIMEOUT_MS, "Refresh cleanup");
    } catch (err) {
      console.warn("[main] clearLingeringTask time-boxed out:", err.message);
    }

    const db = getDB();
    const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
    if (!item) return { success: false, error: "Item not found" };

    const saveDir = path.dirname(item.directory || "");
    let fileInfo;
    try {
      fileInfo = await withTimeout(prepareDownload(newUrl, saveDir), PREPARE_TIMEOUT_MS, "Refreshing link");
    } catch (err) {
      return { success: false, error: err.message || String(err) };
    }

    const sizeMatches = Number(fileInfo.totalSize) === Number(item.totalSize);
    let taskFilePath, taskTotalSize;
    if (sizeMatches && item.directory) {
      taskFilePath = item.directory;
      taskTotalSize = item.totalSize;
    } else {
      try { fs.unlinkSync(item.directory + ".fastdl"); } catch {}
      try { fs.unlinkSync(item.directory + ".download"); } catch {}
      taskFilePath = fileInfo.filePath;
      taskTotalSize = fileInfo.totalSize;
    }

    db.prepare(
      `UPDATE history SET url = ?, status = 'Downloading', error = NULL, ` +
      `directory = ?, totalSize = ? WHERE id = ?`
    ).run(newUrl, taskFilePath, taskTotalSize, id);

    broadcastStatusChange();
    progressBus.emit("state-change", { id: Number(id), to: "downloading" });

    const sender = primarySender(event);
    let taskPromise;
    try {
      taskPromise = startTask(
        id, newUrl, taskFilePath, taskTotalSize,
        sender, {}, validatorsFromProbe(fileInfo, saveDir)
      );
    } catch (err) {
      db.prepare(`UPDATE history SET status = 'Paused' WHERE id = ?`).run(id);
      broadcastStatusChange();
      return { success: false, error: err.message || String(err) };
    }

    handleTaskCompletion(id, taskPromise, sender);
    return { success: true };
  });

  /* ---------------- request-fresh-url (NEW) ---------------- */
  ipcMain.handle("request-fresh-url", async (event, id, opts = {}) => {
    const db = getDB();
    const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
    if (!item) return { success: false, error: "Item not found" };

    // Already pending? Return the existing request id.
    const existing = refreshRequests.findForDownload(id);
    const requestId = existing
      ? existing.id
      : refreshRequests.add({
          downloadId: Number(id),
          filename: item.filename,
          totalSize: item.totalSize,
          refererOrigin: extractOrigin(item.url),
          timeoutMs: opts.timeoutMs || 120000,
        });

    console.log(`[main] request-fresh-url id=${id} requestId=${requestId}`);

    return await new Promise((resolve) => {
      const onResolved = (payload) => {
        if (payload.id !== requestId) return;
        cleanup();
        resolve({ success: true, url: payload.url, downloadId: payload.downloadId, resumed: true });
      };
      const onExpired = (payload) => {
        if (payload.id !== requestId) return;
        cleanup();
        resolve({ success: false, error: "Extension did not respond in time." });
      };
      const onCancelled = (payload) => {
        if (payload.id !== requestId) return;
        cleanup();
        resolve({ success: false, error: "Cancelled." });
      };
      const cleanup = () => {
        refreshRequests.off("resolved", onResolved);
        refreshRequests.off("expired", onExpired);
        refreshRequests.off("cancelled", onCancelled);
      };
      refreshRequests.on("resolved", onResolved);
      refreshRequests.on("expired", onExpired);
      refreshRequests.on("cancelled", onCancelled);
    });
  });

  /* ---------------- cancel-fresh-url-request (NEW) ---------------- */
  ipcMain.handle("cancel-fresh-url-request", (_event, id) => {
    const pending = refreshRequests.findForDownload(id);
    if (pending) {
      refreshRequests.cancel(pending.id);
      return { success: true };
    }
    return { success: false, error: "No pending request" };
  });

  /* ---------------- open-download-window ---------------- */
  ipcMain.handle("open-download-window", async (_event, id) => {
    try {
      const numId = Number(id);
      if (!Number.isFinite(numId)) return { success: false, error: "Invalid download id" };
      ensureWindowOpen(numId);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message || "Could not open window" };
    }
  });
}

function extractOrigin(url) {
  try { return new URL(url).origin; } catch { return ""; }
}

module.exports = { registerDownloadHandlers };