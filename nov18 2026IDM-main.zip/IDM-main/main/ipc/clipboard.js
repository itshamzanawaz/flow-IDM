/* ================================================================
 *  Flow — clipboard + default-directory IPC handlers
 * ================================================================ */

const { ipcMain, clipboard, app } = require("electron");

function registerClipboardHandlers() {
  ipcMain.handle("read-clipboard", () => clipboard.readText());
  ipcMain.handle("get-default-directory", () => app.getPath("downloads"));
}

module.exports = { registerClipboardHandlers };