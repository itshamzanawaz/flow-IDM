/* ================================================================
 *  Flow — history IPC handlers
 *    get-history       : list all rows
 *    delete-download   : remove row (optionally unlink file + parts)
 *    clear-completed   : delete all "Completed" rows
 * ================================================================ */

const { ipcMain } = require("electron");
const fs = require("fs");

const { getDB } = require("../database");
const { isYouTubeUrl } = require("../media");
const { pauseYoutubeTask } = require("../youtube");
const {
  cancelTask,
  removePartialFiles,
} = require("../../downloader/downloadManager");

function registerHistoryHandlers() {
  ipcMain.handle("get-history", () => {
    try {
      return getDB()
        .prepare("SELECT * FROM history ORDER BY timestamp DESC")
        .all();
    } catch (err) {
      return [];
    }
  });

  ipcMain.handle("delete-download", async (event, id, deleteFile) => {
    const db = getDB();
    const item = db.prepare(`SELECT * FROM history WHERE id = ?`).get(id);
    if (!item) return { success: false, error: "Item not found" };

    const st = String(item.status || "").toLowerCase();
    if (st === "downloading" || st === "preparing") {
      if (isYouTubeUrl(item.url)) {
        try { pauseYoutubeTask(id); } catch {}
      } else {
        Promise.resolve()
          .then(() => cancelTask(id))
          .catch((err) => console.warn("[main] cancelTask (delete):", err.message));
      }
      await new Promise((r) => setTimeout(r, 250));
    }

    db.prepare(`DELETE FROM history WHERE id = ?`).run(id);

    if (deleteFile) {
      try {
        if (fs.existsSync(item.directory)) fs.unlinkSync(item.directory);
        removePartialFiles(item.directory);
      } catch (err) {
        console.error("Failed to delete file:", err);
        event.sender.send("status-change");
        return {
          success: false,
          error: "Removed from history, but failed to delete physical file.",
        };
      }
    }

    event.sender.send("status-change");
    return { success: true };
  });

  ipcMain.handle("clear-completed", (event) => {
    try {
      const info = getDB()
        .prepare(`DELETE FROM history WHERE LOWER(status) = 'completed'`)
        .run();
      event.sender.send("status-change");
      return { success: true, removed: info.changes };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });
}

module.exports = { registerHistoryHandlers };