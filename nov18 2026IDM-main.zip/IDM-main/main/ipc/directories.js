/* ================================================================
 *  Flow — folder picker IPC handler
 * ================================================================ */

const { ipcMain, dialog } = require("electron");

function registerDirectoryHandlers() {
  ipcMain.handle("select-directory", async () => {
    const { canceled, filePaths } = await dialog.showOpenDialog({
      properties: ["openDirectory"],
    });
    return canceled ? null : filePaths[0];
  });
}

module.exports = { registerDirectoryHandlers };