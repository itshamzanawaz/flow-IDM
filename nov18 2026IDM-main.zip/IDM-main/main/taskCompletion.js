/* ================================================================
 *  Flow — task completion + lingering-task cleanup
 *
 *  Persists `history.error` on failure so renderer can detect
 *  expired URLs and prompt for a fresh link. Clears `error` on
 *  success and cancel.
 * ================================================================ */

const { cancelTask } = require("../downloader/downloadManager");
const { getDB } = require("./database");
const progressBus = require("./progressBus");

async function clearLingeringTask(id) {
  try {
    const res = await Promise.race([
      cancelTask(id),
      new Promise((r) =>
        setTimeout(() => r({ success: false, error: "timeout" }), 5000)
      ),
    ]);
    if (res && res.success === false && res.error !== "timeout") {
      console.log(`[main] cancelTask(${id}) note:`, res.error);
    }
  } catch (err) {
    console.log(`[main] cancelTask(${id}) skipped:`, err.message);
  }
  await new Promise((r) => setTimeout(r, 80));
}

function fireNotification(filename) {
  try {
    const { Notification } = require("electron");
    if (!Notification.isSupported()) return;
    new Notification({
      title: "Download Complete",
      body: filename || "Download finished",
      silent: false,
    }).show();
  } catch (err) {
    console.warn("[taskCompletion] notification failed:", err.message);
  }
}

async function handleTaskCompletion(id, taskPromise, sender, opts = {}) {
  const out =
    sender && typeof sender.send === "function" ? sender : { send: () => {} };
  const errorStatus = opts.restoreOnError || "Error";
  const db = getDB();
  const numericId = Number(id);

  try {
    const result = await taskPromise;
    if (!result) return;

    if (result.success) {
      let filename = "download";
      try {
        const row = db.prepare(`SELECT filename FROM history WHERE id = ?`).get(id);
        if (row && row.filename) filename = row.filename;
      } catch {}

      const sortedPath = result.filePath || null;
      try {
        if (sortedPath) {
          db.prepare(
            `UPDATE history SET status = 'Completed', error = NULL, directory = ? WHERE id = ?`
          ).run(sortedPath, id);
        } else {
          db.prepare(
            `UPDATE history SET status = 'Completed', error = NULL WHERE id = ?`
          ).run(id);
        }
      } catch (err) {
        console.error("[taskCompletion] DB update failed:", err.message);
      }

      fireNotification(filename);
      progressBus.emit("state-change", { id: numericId, to: "completed" });
      out.send("status-change");
    } else if (result.paused) {
      progressBus.emit("state-change", { id: numericId, to: "paused" });
      out.send("status-change");
    } else if (result.cancelled) {
      try {
        db.prepare(`UPDATE history SET error = NULL WHERE id = ?`).run(id);
      } catch {}
      progressBus.emit("state-change", { id: numericId, to: "cancelled" });
      out.send("status-change");
    } else if (result.error) {
      db.prepare(`UPDATE history SET status = ?, error = ? WHERE id = ?`)
        .run(errorStatus, result.error, id);

      if (errorStatus !== "Paused") {
        out.send("download-error", { id, message: result.error });
      } else {
        out.send("download-error", { id, message: result.error, silent: true });
      }
      progressBus.emit("state-change", {
        id: numericId,
        to: "failed",
        error: result.error,
      });
      out.send("status-change");
    }
  } catch (err) {
    const message = err.message || String(err);
    try {
      db.prepare(`UPDATE history SET status = ?, error = ? WHERE id = ?`)
        .run(errorStatus, message, id);
    } catch {}
    if (errorStatus !== "Paused") {
      out.send("download-error", { id, message });
    } else {
      out.send("download-error", { id, message, silent: true });
    }
    progressBus.emit("state-change", { id: numericId, to: "failed", error: message });
    out.send("status-change");
  }
}

module.exports = { clearLingeringTask, handleTaskCompletion };