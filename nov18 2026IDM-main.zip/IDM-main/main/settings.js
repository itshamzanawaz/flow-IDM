/* ================================================================
 *  Flow — persistent user settings
 *
 *  Stored as JSON at userData/settings.json. Currently:
 *    • minimizeToTray   — close button hides to tray instead of quit
 *    • startAtLogin     — register the app as a login item
 *
 *  applyAll() is called once at app ready. set() applies the
 *  startAtLogin change immediately so toggling in the UI has an
 *  effect without a restart.
 *
 *  Linux autostart:
 *    ~/.config/autostart/flow.desktop  (XDG standard, works on
 *    GNOME/KDE/Xfce/i3/etc). Exec includes --hidden so the window
 *    starts minimised in the tray. If the app is packaged as an
 *    AppImage, APPIMAGE is preferred over execPath.
 * ================================================================ */

const path = require("path");
const fs = require("fs");
const os = require("os");
const { app } = require("electron");

const DEFAULTS = {
  minimizeToTray: true,
  startAtLogin: false,
};

let settingsPath = null;
let cache = null;

function getPath() {
  if (!settingsPath) {
    settingsPath = path.join(app.getPath("userData"), "settings.json");
  }
  return settingsPath;
}

function load() {
  if (cache) return cache;
  try {
    const raw = fs.readFileSync(getPath(), "utf8");
    cache = { ...DEFAULTS, ...JSON.parse(raw) };
  } catch {
    cache = { ...DEFAULTS };
  }
  return cache;
}

function save() {
  if (!cache) return;
  try {
    fs.mkdirSync(path.dirname(getPath()), { recursive: true });
    fs.writeFileSync(getPath(), JSON.stringify(cache, null, 2));
  } catch (err) {
    console.error("[settings] save failed:", err.message);
  }
}

function get(key) {
  return load()[key];
}

function set(key, value) {
  load()[key] = value;
  save();
  if (key === "startAtLogin") applyStartAtLogin(!!value);
}

/* ---------------- Login item installation ---------------- */
function applyStartAtLogin(enabled) {
  if (process.platform === "darwin" || process.platform === "win32") {
    try {
      if (app.isPackaged) {
        app.setLoginItemSettings({
          openAtLogin: enabled,
          args: ["--hidden"],
        });
      } else {
        app.setLoginItemSettings({
          openAtLogin: enabled,
          path: process.execPath,
          args: [app.getAppPath(), "--hidden"],
        });
      }
    } catch (err) {
      console.error("[settings] setLoginItemSettings failed:", err.message);
    }
    return;
  }

  if (process.platform === "linux") {
    try {
      const autostartDir = path.join(os.homedir(), ".config", "autostart");
      const desktopPath = path.join(autostartDir, "flow.desktop");

      if (!enabled) {
        if (fs.existsSync(desktopPath)) fs.unlinkSync(desktopPath);
        return;
      }

      fs.mkdirSync(autostartDir, { recursive: true });

      let execLine;
      if (process.env.APPIMAGE) {
        execLine = `"${process.env.APPIMAGE}" --hidden`;
      } else if (app.isPackaged) {
        execLine = `"${process.execPath}" --hidden`;
      } else {
        execLine = `"${process.execPath}" "${app.getAppPath()}" --hidden`;
      }

      const content =
        "[Desktop Entry]\n" +
        "Type=Application\n" +
        "Name=Flow\n" +
        "Comment=Flow download manager\n" +
        `Exec=${execLine}\n` +
        "X-GNOME-Autostart-enabled=true\n" +
        "Terminal=false\n";

      fs.writeFileSync(desktopPath, content, { mode: 0o644 });
    } catch (err) {
      console.error("[settings] Linux autostart write failed:", err.message);
    }
  }
}

function applyAll() {
  applyStartAtLogin(!!load().startAtLogin);
}

module.exports = { get, set, load, applyAll };