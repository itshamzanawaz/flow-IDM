/* ================================================================
 *  Flow — URL classification helpers
 * ================================================================ */

function isYouTubeUrl(url) {
  return (
    typeof url === "string" &&
    (url.includes("youtube.com") || url.includes("youtu.be"))
  );
}

module.exports = { isYouTubeUrl };