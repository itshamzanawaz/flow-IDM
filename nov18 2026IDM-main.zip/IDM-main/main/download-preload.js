/* ================================================================
 *  Flow — preload for the dedicated download progress window
 *
 *  Exposes a minimal `window.downloadAPI`. Pause / Cancel / Resume
 *  reuse the same IPC channels as the main window (pause-download,
 *  cancel-download, resume-download) so all state changes go through
 *  one code path in main.
 * ================================================================ */

const { contextBridge, ipcRenderer } = require("electron");

function subscribe(channel, cb) {
  const handler = (_e, data) => cb(data);
  ipcRenderer.on(channel, handler);
  return () => ipcRenderer.removeListener(channel, handler);
}

contextBridge.exposeInMainWorld("downloadAPI", {
  /* Subscribe to live progress (fed by progressBus in main). */
  onProgress: (cb) => subscribe("download-progress", cb),

  /* Subscribe to state changes (paused / cancelled / completed / failed). */
  onStateChange: (cb) => subscribe("download-state-change", cb),

  /* Initial snapshot for this download id. */
  getInfo: (id) => ipcRenderer.invoke("download-window-get-info", id),

  /* Reuse existing main-window IPC handlers. */
  pause:  (id) => ipcRenderer.invoke("pause-download", id),
  resume: (id) => ipcRenderer.invoke("resume-download", id),
  cancel: (id) => ipcRenderer.invoke("cancel-download", id, true),
});