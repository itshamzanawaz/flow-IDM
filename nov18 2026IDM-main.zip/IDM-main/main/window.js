/* ================================================================
 *  Flow — main window lifecycle + Linux-friendly raise
 * ================================================================ */

const { BrowserWindow } = require("electron");
const path = require("path");
const { exec } = require("child_process");

let mainWindow = null;
let settingsWindow = null;
let isQuitting = false;

function setQuitting(v) {
  isQuitting = !!v;
}

function createWindow(opts = {}) {
  const shouldHideOnClose =
    typeof opts.shouldHideOnClose === "function"
      ? opts.shouldHideOnClose
      : () => false;

  mainWindow = new BrowserWindow({
    width: 1180,
    height: 800,
    minWidth: 860,
    minHeight: 600,
    backgroundColor: "#0b0d12",
    titleBarStyle: process.platform === "darwin" ? "hiddenInset" : "default",
    webPreferences: {
      preload: path.join(__dirname, "..", "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  mainWindow.loadFile("index.html");

  mainWindow.on("close", (e) => {
    if (isQuitting) return;
    if (shouldHideOnClose()) {
      e.preventDefault();
      try { mainWindow.hide(); } catch {}
    }
  });

  mainWindow.on("closed", () => {
    mainWindow = null;
  });

  return mainWindow;
}

function createSettingsWindow() {
  if (settingsWindow && !settingsWindow.isDestroyed()) {
    settingsWindow.focus();
    return;
  }

  settingsWindow = new BrowserWindow({
    width: 620,
    height: 750,
    parent: mainWindow,
    modal: false,
    show: false,
    backgroundColor: "#0b0d12",
    titleBarStyle: process.platform === "darwin" ? "hiddenInset" : "default",
    webPreferences: {
      preload: path.join(__dirname, "..", "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  settingsWindow.loadFile("settings.html");
  settingsWindow.once("ready-to-show", () => settingsWindow.show());
  settingsWindow.on("closed", () => { settingsWindow = null; });
}

function getMainWindow() {
  return mainWindow;
}

function showWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) return false;
  try {
    if (mainWindow.isMinimized()) mainWindow.restore();
    if (!mainWindow.isVisible()) mainWindow.show();
    mainWindow.focus();
    return true;
  } catch {
    return false;
  }
}

function bringToFront() {
  if (!mainWindow || mainWindow.isDestroyed()) {
    console.warn("[focus] no main window to raise");
    return;
  }

  try {
    if (mainWindow.isMinimized()) mainWindow.restore();
    if (!mainWindow.isVisible()) mainWindow.show();

    mainWindow.setAlwaysOnTop(true, "floating");
    mainWindow.focus();
    mainWindow.moveTop();
    mainWindow.flashFrame(true);

    if (process.platform === "linux" && process.env.DISPLAY) {
      exec(
        `xdotool search --name "Flow" windowactivate --sync %@ 2>/dev/null || true`,
        () => {}
      );
    }

    setTimeout(() => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.setAlwaysOnTop(false);
        mainWindow.flashFrame(false);
      }
    }, 700);
  } catch (err) {
    console.warn("[focus] failed:", err.message);
  }
}

module.exports = {
  createWindow,
  createSettingsWindow,
  getMainWindow,
  showWindow,
  bringToFront,
  setQuitting,
};