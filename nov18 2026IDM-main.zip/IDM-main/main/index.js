/* ================================================================
 *  Flow — Electron main process entry point
 *
 *  Background mode:
 *    • Tray is created after the window. Closing the window hides
 *      it (when minimizeToTray is on and the tray exists); the app
 *      keeps running until "Quit Flow" is chosen from the tray or
 *      the settings UI.
 *    • --hidden (written into the autostart entry) starts the app
 *      with the window hidden.
 *
 *  Shutdown:
 *    • before-quit still pauses all tasks with a 3 s grace window.
 *    • setQuitting(true) is called FIRST so the window close handler
 *      stops intercepting and the tray is torn down cleanly.
 * ================================================================ */

const { app, BrowserWindow } = require("electron");

const { initDB } = require("./database");
const {
  createWindow,
  getMainWindow,
  showWindow,
  setQuitting,
} = require("./window");
const { registerAllIpcHandlers } = require("./ipc");
const { startHttpBridge } = require("./bridge");
const { pauseAll } = require("../downloader/downloadManager");
const settings = require("./settings");
const { createTray, destroyTray } = require("./tray");

const SHUTDOWN_GRACE_MS = 3000;
const START_HIDDEN = process.argv.includes("--hidden");

let isQuitting = false;
let trayAvailable = false;

function shouldHideOnClose() {
  return trayAvailable && !!settings.get("minimizeToTray");
}

function launchWindow() {
  return createWindow({ shouldHideOnClose });
}

function showMainWindow() {
  if (showWindow()) return;
  // Window was destroyed — recreate then show.
  launchWindow();
}

app.whenReady().then(() => {
  initDB();
  registerAllIpcHandlers();
  startHttpBridge();

  // Apply persisted autostart preference on every launch, so a
  // manually deleted ~/.config/autostart/flow.desktop is restored.
  try { settings.applyAll(); } catch (err) {
    console.error("[startup] settings.applyAll failed:", err.message);
  }

  const win = launchWindow();

  try {
    trayAvailable = createTray({ onShow: showMainWindow });
  } catch (err) {
    console.warn("[tray] unavailable:", err.message);
    trayAvailable = false;
  }

  if (START_HIDDEN && trayAvailable) {
    try { win.hide(); } catch {}
  }

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      launchWindow();
    } else {
      showMainWindow();
    }
  });
});

app.on("window-all-closed", () => {
  // On macOS the app already stays alive with no windows.
  if (process.platform === "darwin") return;

  // If tray is present and background mode is on, the window should
  // never reach "closed" (the close handler hides instead). But if it
  // did — e.g. hide-on-close was toggled off mid-session — follow the
  // current preference and quit.
  if (trayAvailable && settings.get("minimizeToTray")) return;
  app.quit();
});

app.on("before-quit", async (e) => {
  if (isQuitting) return;
  isQuitting = true;

  // Order matters: tell the window to stop intercepting close,
  // tear down the tray, then run the bounded pauseAll shutdown.
  setQuitting(true);
  destroyTray();

  e.preventDefault();

  try {
    await Promise.race([
      pauseAll(),
      new Promise((r) => setTimeout(r, SHUTDOWN_GRACE_MS)),
    ]);
  } catch (err) {
    console.error("[shutdown] pauseAll failed:", err.message);
  }
  app.exit(0);
});