/* ================================================================
 *  Flow — HTTP bridge for the browser extension
 * ================================================================ */

const http = require("http");
const fs = require("fs");
const path = require("path");
const { app, BrowserWindow } = require("electron");

const { BRIDGE_PORT, BRIDGE_TOKEN } = require("./constants");
const { getDB } = require("./database");
const { getMainWindow, bringToFront } = require("./window");
const { prepareDownload, startTask } = require("../downloader/downloadManager");
const {
  isHlsUrl,
  prepareHlsDownload,
  startHlsTask,
  pauseHlsTask,
} = require("../downloader/hlsManager");
const { clearLingeringTask, handleTaskCompletion } = require("./taskCompletion");
const progressBus = require("./progressBus");
const refreshRequests = require("./refreshRequests");
const { ensureWindowOpen } = require("./downloadWindow");

const PREPARE_TIMEOUT_MS = 60000;
const MB4 = 4 * 1024 * 1024;

function withTimeout(promise, ms, label) {
  return Promise.race([
    promise,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`${label} timed out after ${ms / 1000}s`)), ms)
    ),
  ]);
}

function busSender(webContents) {
  const alive = () => webContents && !webContents.isDestroyed();
  return {
    send: (channel, payload) => {
      if (channel === "download-progress" && payload) {
        try { progressBus.emit("progress", payload); } catch {}
      }
      if (alive()) {
        try { webContents.send(channel, payload); } catch {}
      }
    },
    isDestroyed: () => !alive(),
  };
}

function broadcastStatusChange() {
  for (const win of BrowserWindow.getAllWindows()) {
    if (win && !win.isDestroyed()) {
      try { win.webContents.send("status-change"); } catch {}
    }
  }
}

function validatorsFromProbe(fileInfo, saveDirectory) {
  return {
    etag: fileInfo.etag || null,
    lastModified: fileInfo.lastModified || null,
    validator: fileInfo.validator || null,
    contentType: fileInfo.contentType || null,
    finalUrl: fileInfo.finalUrl || null,
    resumable: fileInfo.resumable !== false,
    saveDirectory: saveDirectory || null,
  };
}

function findPendingByFilename(filename) {
  if (!filename) return null;
  const normalized = String(filename).trim().toLowerCase();
  if (!normalized) return null;
  for (const p of refreshRequests.list()) {
    if (String(p.filename || "").trim().toLowerCase() === normalized) return p;
  }
  return null;
}

function findResumableRow(db, filename, totalSize) {
  if (!filename || !totalSize) return null;
  try {
    const rows = db.prepare(`
      SELECT * FROM history
      WHERE filename = ?
        AND totalSize = ?
        AND LOWER(status) IN ('error', 'paused')
      ORDER BY timestamp DESC
      LIMIT 1
    `).all(filename, totalSize);
    if (!rows.length) return null;
    const row = rows[0];
    if (!row.directory) return null;
    if (!fs.existsSync(row.directory + ".download") &&
        !fs.existsSync(row.directory + ".fastdl")) return null;
    return row;
  } catch { return null; }
}

async function resumeExistingRow(db, row, newUrl, fileInfo, extraHeaders, sender) {
  const id = row.id;
  const dir = path.dirname(row.directory);
  console.log(`[bridge] Resuming #${id} "${row.filename}" with fresh URL`);

  await clearLingeringTask(id);

  db.prepare(
    `UPDATE history SET url = ?, status = 'Downloading', error = NULL WHERE id = ?`
  ).run(newUrl, id);

  sender.send("download-start", {
    id,
    fileName: row.filename,
    filePath: row.directory,
    totalSize: row.totalSize,
  });
  broadcastStatusChange();
  progressBus.emit("state-change", { id: Number(id), to: "downloading" });

  handleTaskCompletion(
    id,
    startTask(
      id, newUrl, row.directory, row.totalSize,
      sender, extraHeaders, validatorsFromProbe(fileInfo, dir)
    ),
    sender
  );

  return { success: true, id, filename: row.filename, resumed: true };
}

function startHttpBridge() {
  const server = http.createServer((req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-Flow-Token");

    if (req.method === "OPTIONS") { res.writeHead(204); return res.end(); }

    const token = req.headers["x-flow-token"];

    if (req.method === "GET" && req.url === "/health") {
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ ok: true, app: "flow" }));
    }

    if (req.method === "GET" && req.url === "/pending-refresh") {
      if (token !== BRIDGE_TOKEN) {
        res.writeHead(403, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ error: "Forbidden" }));
      }
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ pending: refreshRequests.list() }));
    }

    if (req.method !== "POST" || req.url !== "/download") {
      res.writeHead(404, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ error: "Not found" }));
    }

    if (token !== BRIDGE_TOKEN) {
      res.writeHead(403, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ error: "Forbidden" }));
    }

    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 5 * 1024 * 1024) req.destroy();
    });
    req.on("end", async () => {
      try {
        const parsed = JSON.parse(body);
        console.log("[http-bridge] Payload:", {
          url: parsed.url,
          hasResumeId: !!parsed.resumeId,
          filename: parsed.filename,
          isHls: !!parsed.isHls,
          useYtDlp: !!parsed.useYtDlp,
          hasAudioUrl: !!parsed.audioUrl,
          cookiesLen: (parsed.cookies || "").length,
        });
        const result = await handleBridgeDownload(parsed);
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify(result));
      } catch (err) {
        console.error("[http-bridge] CRITICAL ERROR:", err.message, "\nStack:", err.stack);
        res.writeHead(400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ success: false, error: err.message }));
      }
    });
  });

  server.on("error", (err) => console.error("[http-bridge] Server error:", err.message));
  server.listen(BRIDGE_PORT, "127.0.0.1", () => {
    console.log(`[http-bridge] Listening on http://127.0.0.1:${BRIDGE_PORT}`);
  });
  return server;
}

function sanitizeReferrer(referrer) {
  if (!referrer || typeof referrer !== "string") return "";
  const trimmed = referrer.trim();
  if (!trimmed) return "";
  try {
    const u = new URL(trimmed);
    if (u.protocol !== "http:" && u.protocol !== "https:") return "";
  } catch { return ""; }
  return trimmed;
}

async function handleHlsDownload(url, filename, dir, extraHeaders, sender, audioUrl) {
  let hlsInfo;
  try {
    hlsInfo = await withTimeout(
      prepareHlsDownload(url, dir, extraHeaders, { filename, audioUrl }),
      PREPARE_TIMEOUT_MS, "Preparing HLS/Tunnel download"
    );
  } catch (err) {
    throw new Error(`Could not prepare HLS/Tunnel download: ${err.message}`);
  }

  const db = getDB();
  const stmt = db.prepare(
    `INSERT INTO history (filename, directory, url, totalSize, status, error)
     VALUES (?, ?, ?, ?, ?, NULL)`
  );
  const info = stmt.run(hlsInfo.fileName, hlsInfo.filePath, url, 0, "Downloading");
  const dbId = info.lastInsertRowid;

  sender.send("download-start", { id: dbId, ...hlsInfo });
  broadcastStatusChange();
  progressBus.emit("state-change", { id: Number(dbId), to: "downloading" });

  handleTaskCompletion(
    dbId,
    startHlsTask(dbId, url, hlsInfo.filePath, sender, extraHeaders, { audioUrl }),
    sender
  );

  try { ensureWindowOpen(dbId); }
  catch (err) { console.warn("[bridge] could not open download window:", err.message); }

  return { success: true, id: dbId, filename: hlsInfo.fileName, hls: true };
}

async function handleBridgeDownload(payload) {
  const {
    url, cookies, referrer, filename, resumeId,
    audioUrl = null, isHls: isHlsFlag = false, useYtDlp = false,
  } = payload;

  if (!url || typeof url !== "string") {
    throw new Error("Missing or invalid 'url' in payload.");
  }

  if (!resumeId && filename) {
    const pending = findPendingByFilename(filename);
    if (pending) {
      resumeId = pending.id;
    }
  }

  bringToFront();

  const dir = app.getPath("downloads");
  const extraHeaders = {};
  if (cookies && String(cookies).trim()) {
    extraHeaders["Cookie"] = String(cookies).trim().slice(0, 8000);
  }
  
  let safeReferrer = sanitizeReferrer(referrer);
  const isTunnel = url.includes("yt-dl.click") || url.includes("y2mate") || url.includes("tunnel");
  if (isTunnel && !safeReferrer) {
      safeReferrer = "https://www-y2mate.com/";
  }
  if (safeReferrer) extraHeaders["Referer"] = safeReferrer;
  
  if (filename && String(filename).trim()) {
    extraHeaders["X-Flow-Filename-Hint"] = String(filename).trim();
  }

  const mainWindow = getMainWindow();
  const targetWc = mainWindow && !mainWindow.isDestroyed() ? mainWindow.webContents : null;
  const sender = targetWc ? busSender(targetWc) : { send: () => {}, isDestroyed: () => true };

  const hlsRequest = isHlsFlag || isHlsUrl(url) || isTunnel || useYtDlp;

  if (resumeId) {
    const pending = refreshRequests.pending.get(resumeId);
    if (!pending) {
      console.warn(`[bridge] Unknown/expired resumeId ${resumeId}`);
    } else {
      const db = getDB();
      const row = db.prepare(`SELECT * FROM history WHERE id = ?`).get(pending.downloadId);
      if (!row) {
        refreshRequests.cancel(resumeId);
        throw new Error("Original download row no longer exists.");
      }

      if (hlsRequest) {
        refreshRequests.resolve(resumeId, url, cookies, referrer);
        await clearLingeringTask(row.id);

        db.prepare(
          `UPDATE history SET url = ?, status = 'Downloading', error = NULL WHERE id = ?`
        ).run(url, row.id);

        sender.send("download-start", {
          id: row.id,
          fileName: row.filename,
          filePath: row.directory,
          totalSize: 0,
          hls: true,
        });
        broadcastStatusChange();
        progressBus.emit("state-change", { id: Number(row.id), to: "downloading" });

        handleTaskCompletion(
          row.id,
          startHlsTask(row.id, url, row.directory, sender, extraHeaders, { audioUrl }),
          sender
        );

        return { success: true, id: row.id, filename: row.filename, resumed: true, hls: true };
      }

      let fileInfo;
      try {
        fileInfo = await withTimeout(
          prepareDownload(url, path.dirname(row.directory || dir), extraHeaders),
          PREPARE_TIMEOUT_MS, "Refreshing link"
        );
      } catch (err) {
        throw new Error(`Fresh URL rejected: ${err.message}`);
      }

      if (Number(fileInfo.totalSize) !== Number(row.totalSize)) {
        throw new Error(
          `Fresh URL points to a different file (${fileInfo.totalSize} vs ${row.totalSize} bytes).`
        );
      }

      refreshRequests.resolve(resumeId, url, cookies, referrer);
      return await resumeExistingRow(db, row, url, fileInfo, extraHeaders, sender);
    }
  }

  if (hlsRequest) {
    return await handleHlsDownload(url, filename, dir, extraHeaders, sender, audioUrl);
  }

  // Standard download path
  let fileInfo;
  try {
    fileInfo = await withTimeout(
      prepareDownload(url, dir, extraHeaders),
      PREPARE_TIMEOUT_MS, "Preparing captured download"
    );
  } catch (err) {
    const msg = err.message || "";
    // FALLBACK: If size is unknown, it's a streaming link. Try yt-dlp.
    if (/Could not determine file size/i.test(msg)) {
      console.log(`[bridge] Unknown file size. Falling back to yt-dlp...`);
      return await handleHlsDownload(url, filename, dir, extraHeaders, sender, audioUrl);
    }

    if (/403|expired|auth/i.test(msg)) {
      throw new Error(
        "URL expired before download could start. Re-click Download on the site to capture a fresh link."
      );
    }
    throw err;
  }

  // Enforce 4MB rule on Electron side
  const size = Number(fileInfo.totalSize);
  if (size > 0 && size < MB4) {
    throw new Error("File is smaller than 4MB. Browser should download this.");
  }

  const db = getDB();
  const candidate = findResumableRow(db, fileInfo.fileName, fileInfo.totalSize);
  if (candidate) {
    try {
      return await resumeExistingRow(db, candidate, url, fileInfo, extraHeaders, sender);
    } catch (err) {
      console.error("[bridge] auto-resume-by-size failed:", err.message);
    }
  }

  const stmt = db.prepare(
    `INSERT INTO history (filename, directory, url, totalSize, status, error)
     VALUES (?, ?, ?, ?, ?, NULL)`
  );
  const info = stmt.run(
    fileInfo.fileName, fileInfo.filePath, url, fileInfo.totalSize || 0, "Downloading"
  );
  const dbId = info.lastInsertRowid;

  try {
    sender.send("download-start", { id: dbId, ...fileInfo });
    broadcastStatusChange();
  } catch (e) { console.warn("[bridge] notify renderer failed:", e.message); }

  handleTaskCompletion(
    dbId,
    startTask(
      dbId, url, fileInfo.filePath, fileInfo.totalSize,
      sender, extraHeaders, validatorsFromProbe(fileInfo, dir)
    ),
    sender
  );

  try { ensureWindowOpen(dbId); }
  catch (err) { console.warn("[bridge] could not open download window:", err.message); }

  return { success: true, id: dbId, filename: fileInfo.fileName };
}

module.exports = { startHttpBridge, handleBridgeDownload };