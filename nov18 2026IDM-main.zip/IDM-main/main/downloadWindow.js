/* ================================================================
 *  Flow — dedicated download progress window
 * ================================================================ */

const { BrowserWindow, ipcMain } = require("electron");
const path = require("path");

const progressBus = require("./progressBus");
const dm = require("../downloader/downloadManager");

/* Defensive: if downloadManager is an older build without getTaskInfo,
 * return null instead of crashing the whole app when a window opens. */
const getTaskInfo = typeof dm.getTaskInfo === "function" ? dm.getTaskInfo : () => null;
const pauseTask  = dm.pauseTask;
const cancelTask = dm.cancelTask;

const windows = new Map();
let handlersReady = false;

function ensureHandlers() {
  if (handlersReady) return;
  handlersReady = true;

  ipcMain.handle("download-window-get-info", async (_event, id) => {
    const numId = Number(id);
    const live = getTaskInfo(numId);
    if (live) return live;
    try {
      const { getDB } = require("./database");
      const row = getDB()
        .prepare(`SELECT filename, directory, totalSize, status, error FROM history WHERE id = ?`)
        .get(numId);
      if (row) {
        const st = String(row.status || "").toLowerCase();
        return {
          id: numId,
          filename: row.filename,
          filePath: row.directory,
          totalSize: row.totalSize || 0,
          percent: st === "completed" ? 100 : 0,
          speedMBps: 0,
          etaSeconds: 0,
          state: row.status,
          error: row.error || null,
        };
      }
    } catch {}
    return null;
  });

  progressBus.on("progress", (payload) => {
    if (!payload || payload.id == null) return;
    const win = windows.get(Number(payload.id));
    if (win && !win.isDestroyed()) {
      try { win.webContents.send("download-progress", payload); } catch {}
    }
  });

  progressBus.on("state-change", (payload) => {
    if (!payload || payload.id == null) return;
    const win = windows.get(Number(payload.id));
    if (win && !win.isDestroyed()) {
      try { win.webContents.send("download-state-change", payload); } catch {}
    }
  });
}

function createDownloadWindow(downloadId) {
  ensureHandlers();
  const numId = Number(downloadId);
  if (!Number.isFinite(numId)) throw new Error("Invalid download id");

  const existing = windows.get(numId);
  if (existing && !existing.isDestroyed()) {
    try { existing.focus(); } catch {}
    return existing;
  }

  const info = getTaskInfo(numId);
  const title = info && info.filename
    ? `Downloading — ${info.filename}` : "Downloading";

  const win = new BrowserWindow({
    width: 400, height: 300, minWidth: 340, minHeight: 260,
    resizable: true, minimizable: true, maximizable: false, fullscreenable: false,
    title, show: false, backgroundColor: "#0b0d12",
    webPreferences: {
      preload: path.join(__dirname, "download-preload.js"),
      contextIsolation: true, nodeIntegration: false, sandbox: false,
    },
  });

  win.loadFile(path.join(__dirname, "..", "renderer", "download.html"), {
    query: { id: String(numId) },
  });

  win.once("ready-to-show", () => { try { win.show(); } catch {} });
  win.on("closed", () => { windows.delete(numId); });

  windows.set(numId, win);
  return win;
}

function ensureWindowOpen(downloadId) {
  const numId = Number(downloadId);
  const win = windows.get(numId);
  if (win && !win.isDestroyed()) return win;
  return createDownloadWindow(numId);
}

function closeDownloadWindow(downloadId) {
  const numId = Number(downloadId);
  const win = windows.get(numId);
  if (win && !win.isDestroyed()) { try { win.close(); } catch {} }
  windows.delete(numId);
}

module.exports = { createDownloadWindow, ensureWindowOpen, closeDownloadWindow };