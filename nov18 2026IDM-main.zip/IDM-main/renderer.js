/* ================================================================
   Flow — Renderer
   - Single source of truth: state.active (live) + state.history (DB)
   - Progress ticks update ONLY active cards + live row meta surgically
     (no full list rebuild → no hover flicker)
   - History lists re-render only when the row-set signature changes
   - Optimistic pause/resume/cancel/retry with snapshot restore
   ================================================================ */

/* ---------------- Icons ---------------- */
const SVG = {
  file:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`,
  video:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>`,
  audio:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>`,
  image:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>`,
  archive:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5"/><line x1="10" y1="12" x2="14" y2="12"/></svg>`,
  doc:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>`,
  code:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>`,
  app:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>`,
  pause:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>`,
  play:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>`,
  x:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
  folder: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>`,
  external:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>`,
  retry:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>`,
  trash:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`,
  copy:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`,
  info:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`,
  success:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`,
  error:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`,
  warning:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
  downloadEmpty: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
};

/* ---------------- Helpers ---------------- */
const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

function on(sel, event, handler) {
  const el = typeof sel === "string" ? $(sel) : sel;
  if (!el) { console.warn("[flow] missing element for binding:", sel); return null; }
  el.addEventListener(event, handler);
  return el;
}

/* ---------------- State ---------------- */
const state = {
  view: "dashboard",
  directory: null,
  defaultDirectory: null,
  active: new Map(),
  history: [],
  theme: localStorage.getItem("flow-theme") || "dark",
  inflight: new Set(),

  allFilter: "all",
  allSearch: "",
  allSort: "newest",
  selectMode: false,
  selected: new Set(),
};

/* ---------------- Formatters ---------------- */
function formatBytes(bytes) {
  const n = Number(bytes) || 0;
  if (n <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let i = 0, v = n;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(v < 10 && i > 0 ? 2 : 1)} ${units[i]}`;
}

function formatEta(seconds) {
  if (!seconds || seconds <= 0 || !isFinite(seconds)) return "--";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

function formatDate(ts) {
  if (!ts) return "--";
  let d;
  if (typeof ts === "string") {
    d = new Date(ts.includes("T") ? ts : ts.replace(" ", "T") + "Z");
  } else {
    d = new Date(ts);
  }
  if (isNaN(d.getTime())) return "--";
  const diff = Date.now() - d.getTime();
  if (diff < 60_000) return "Just now";
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`;
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

/* ---------------- File type ---------------- */
const TYPE_MAP = {
  video:   { ext: ["mp4","mkv","avi","mov","webm","flv","m4v","wmv","mpg","mpeg"], color: "#8b5cf6" },
  audio:   { ext: ["mp3","wav","flac","aac","ogg","m4a","wma","opus"],            color: "#ec4899" },
  image:   { ext: ["jpg","jpeg","png","gif","webp","svg","bmp","tiff","ico"],     color: "#06b6d4" },
  archive: { ext: ["zip","rar","7z","tar","gz","bz2","xz","iso"],                 color: "#f59e0b" },
  doc:     { ext: ["pdf","doc","docx","txt","rtf","odt","md","xls","xlsx","ppt","pptx"], color: "#ef4444" },
  code:    { ext: ["js","ts","py","java","c","cpp","html","css","json","xml","sh","go","rs"], color: "#22c55e" },
  app:     { ext: ["exe","msi","dmg","pkg","deb","appimage","apk"],               color: "#6366f1" },
};

function fileVisual(filename) {
  const ext = (String(filename || "").split(".").pop() || "").toLowerCase();
  for (const [type, cfg] of Object.entries(TYPE_MAP)) {
    if (cfg.ext.includes(ext)) return { svg: SVG[type] || SVG.file, color: cfg.color };
  }
  return { svg: SVG.file, color: "#6b7280" };
}

function isValidUrl(str) {
  try {
    const u = new URL(str);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch { return false; }
}

function normalizeStatus(s) {
  const v = String(s || "").toLowerCase();
  if (v === "downloading" || v === "preparing" || v === "resuming") return "downloading";
  if (v === "paused") return "paused";
  if (v === "completed") return "completed";
  if (v === "error") return "error";
  if (v === "cancelled" || v === "canceled") return "cancelled";
  return v || "unknown";
}

/* ---------------- Theme ---------------- */
function applyTheme() {
  document.documentElement.setAttribute("data-theme", state.theme);
  const moon = $("#theme-icon-moon");
  const sun  = $("#theme-icon-sun");
  if (moon) moon.hidden = state.theme !== "dark";
  if (sun)  sun.hidden  = state.theme === "dark";
  const label = $("#settings-theme-label");
  if (label) label.textContent = state.theme === "dark" ? "Dark" : "Light";
}

function toggleTheme() {
  state.theme = state.theme === "dark" ? "light" : "dark";
  localStorage.setItem("flow-theme", state.theme);
  applyTheme();
}

/* ---------------- Toasts ---------------- */
function toast(message, type = "info") {
  const container = $("#toast-container");
  if (!container) return;
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.innerHTML = `${SVG[type] || SVG.info}<span>${escapeHtml(message)}</span>`;
  container.appendChild(el);
  requestAnimationFrame(() => el.classList.add("show"));
  setTimeout(() => {
    el.classList.remove("show");
    setTimeout(() => el.remove(), 250);
  }, 3200);
}

/* ---------------- Confirm dialog ---------------- */
let _confirmResolver = null;
function confirmDialog(title, message, { confirmLabel = "Confirm", danger = true } = {}) {
  return new Promise((resolve) => {
    _confirmResolver = resolve;
    const t = $("#confirm-title"); if (t) t.textContent = title;
    const m = $("#confirm-msg");  if (m) m.textContent = message;
    const ok = $("#confirm-ok");
    if (ok) {
      ok.textContent = confirmLabel;
      ok.classList.toggle("btn-danger", danger);
      ok.classList.toggle("btn-primary", !danger);
    }
    $("#confirm-modal")?.classList.add("open");
  });
}
function closeConfirm(result) {
  $("#confirm-modal")?.classList.remove("open");
  if (_confirmResolver) { _confirmResolver(result); _confirmResolver = null; }
}

/* ---------------- View routing ---------------- */
const VIEW_META = {
  dashboard: { title: "Dashboard",     sub: "Start a new download or check your progress" },
  all:       { title: "All Downloads", sub: "Every download in one place — filter, search, and manage" },
  active:    { title: "Active",        sub: "Downloads currently in progress" },
  recent:    { title: "Recent",        sub: "Your most recent downloads with quick controls" },
  completed: { title: "Completed",     sub: "Downloads that finished successfully" },
  settings:  { title: "Settings",      sub: "Preferences and download location" },
};

function setView(view) {
  state.view = view;
  $$(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.view === view));
  $$(".view").forEach((v) => v.classList.toggle("active", v.dataset.view === view));
  const meta = VIEW_META[view] || VIEW_META.dashboard;
  const titleEl = $("#page-title");
  const subEl = $("#page-subtitle");
  if (titleEl) titleEl.textContent = meta.title;
  if (subEl) subEl.textContent = meta.sub;
  render();
}

/* ================================================================
 *  Merged data model
 * ================================================================ */
function getEffectiveStatus(item) {
  const live = state.active.get(item.id);
  if (live) return live.status;
  const s = String(item.status || "").toLowerCase();
  if (s === "downloading" || s === "preparing") return "Paused";
  return item.status;
}

function getMergedList() {
  return state.history.map((item) => {
    const live = state.active.get(item.id);
    return {
      ...item,
      status: getEffectiveStatus(item),
      percent: live ? (live.percent || 0) : 0,
      speedMBps: live ? (live.speedMBps || 0) : 0,
      etaSeconds: live ? (live.etaSeconds || 0) : 0,
      isLive: !!live,
    };
  });
}

function getActiveList() {
  return Array.from(state.active.values()).sort(
    (a, b) => (b.startedAt || 0) - (a.startedAt || 0)
  );
}

/* ================================================================
 *  Rendering — Active cards
 * ================================================================ */
function statusBadge(status) {
  const s = String(status || "").toLowerCase();
  const map = {
    downloading: { label: "Downloading", cls: "downloading" },
    preparing:   { label: "Preparing",   cls: "preparing" },
    paused:      { label: "Paused",      cls: "paused" },
    completed:   { label: "Completed",   cls: "completed" },
    cancelled:   { label: "Canceled",    cls: "cancelled" },
    canceled:    { label: "Canceled",    cls: "cancelled" },
    error:       { label: "Failed",      cls: "error" },
  };
  const m = map[s] || { label: status || "Unknown", cls: "" };
  return `<span class="badge ${m.cls}"><span class="badge-dot"></span>${escapeHtml(m.label)}</span>`;
}

function fileIconHtml(filename) {
  const { svg, color } = fileVisual(filename);
  return `<div class="file-icon" style="background:${color}1f; color:${color}">${svg}</div>`;
}

function buildActiveCard(dl) {
  const card = document.createElement("div");
  card.className = "download-card";
  card.dataset.id = String(dl.id);
  const { svg, color } = fileVisual(dl.filename);

  card.innerHTML = `
    <div class="dl-head">
      <div class="file-icon" style="background:${color}1f; color:${color}">${svg}</div>
      <div class="dl-info">
        <div class="dl-name"></div>
        <div class="dl-sub"></div>
      </div>
      <div class="hi-status"></div>
      <div class="dl-actions">
        <button class="btn-icon" data-action="pause" data-id="${dl.id}" title="Pause">${SVG.pause}</button>
        <button class="btn-icon danger" data-action="cancel" data-id="${dl.id}" title="Cancel">${SVG.x}</button>
      </div>
    </div>
    <div class="progress-track">
      <div class="progress-bar"></div>
    </div>
    <div class="dl-stats">
      <span class="stat stat-size"></span>
      <span class="stat stat-speed"></span>
      <span class="stat stat-eta"></span>
    </div>
  `;
  updateActiveCard(card, dl, true);
  return card;
}

function updateActiveCard(card, dl, initial = false) {
  const percent = Math.max(0, Math.min(100, Number(dl.percent) || 0));
  const isPaused = dl.status === "Paused";
  const isPreparing = dl.status === "Preparing";

  const nameEl = card.querySelector(".dl-name");
  if (nameEl && nameEl.textContent !== dl.filename) {
    nameEl.textContent = dl.filename || "";
    nameEl.title = dl.filename || "";
  }

  const subEl = card.querySelector(".dl-sub");
  if (subEl) {
    const wantSub = isPreparing ? "Preparing download…" : (dl.filePath || "");
    if (subEl.textContent !== wantSub) subEl.textContent = wantSub;
  }

  const statusEl = card.querySelector(".hi-status");
  if (statusEl) {
    const currentStatus = statusEl.dataset.status || "";
    const nextStatus = String(dl.status || "Downloading");
    if (currentStatus !== nextStatus) {
      statusEl.dataset.status = nextStatus;
      statusEl.innerHTML = statusBadge(nextStatus);
    }
  }

  const bar = card.querySelector(".progress-bar");
  if (bar) {
    if (isPreparing) {
      if (!bar.classList.contains("indeterminate")) {
        bar.classList.add("indeterminate");
        bar.style.width = "";
      }
    } else {
      if (bar.classList.contains("indeterminate")) bar.classList.remove("indeterminate");
      const width = `${percent}%`;
      if (bar.style.width !== width) bar.style.width = width;
    }
  }

  const totalStr = dl.totalSize ? formatBytes(dl.totalSize) : "Unknown size";
  const downloaded = dl.totalSize ? (dl.totalSize * percent) / 100 : 0;
  const speedStr = (!isPaused && !isPreparing && dl.speedMBps) ? `${dl.speedMBps} MB/s` : "—";
  const etaStr = (!isPaused && !isPreparing) ? formatEta(dl.etaSeconds) : "--";
  const shownPercent = isPreparing ? "—" : `${percent}%`;

  const sizeStat = card.querySelector(".stat-size");
  if (sizeStat) {
    const want = `<b>${shownPercent}</b>&nbsp;•&nbsp;${formatBytes(downloaded)} / ${totalStr}`;
    if (sizeStat.dataset.v !== want) { sizeStat.dataset.v = want; sizeStat.innerHTML = want; }
  }
  const speedStat = card.querySelector(".stat-speed");
  if (speedStat && speedStat.textContent !== speedStr) speedStat.textContent = speedStr;

  const etaStat = card.querySelector(".stat-eta");
  if (etaStat) {
    const want = `ETA <b>${etaStr}</b>`;
    if (etaStat.dataset.v !== want) { etaStat.dataset.v = want; etaStat.innerHTML = want; }
  }

  const actionsEl = card.querySelector(".dl-actions");
  if (actionsEl) {
    const primaryBtn = actionsEl.querySelector('[data-action="pause"], [data-action="resume"]');
    const wantAction = isPaused ? "resume" : "pause";
    if (!primaryBtn) {
      const btn = document.createElement("button");
      btn.className = "btn-icon";
      btn.dataset.action = wantAction;
      btn.dataset.id = dl.id;
      btn.innerHTML = isPaused ? SVG.play : SVG.pause;
      btn.title = isPaused ? "Resume" : "Pause";
      actionsEl.insertBefore(btn, actionsEl.firstChild);
    } else if (primaryBtn.dataset.action !== wantAction) {
      primaryBtn.dataset.action = wantAction;
      primaryBtn.title = isPaused ? "Resume" : "Pause";
      primaryBtn.innerHTML = isPaused ? SVG.play : SVG.pause;
    }
  }

  if (initial) card.dataset.inited = "1";
}

function renderActive(container, list) {
  if (!container) return;

  const wanted = new Set(list.map((d) => String(d.id)));
  Array.from(container.querySelectorAll(".download-card")).forEach((card) => {
    if (!wanted.has(card.dataset.id)) card.remove();
  });

  if (!list.length) {
    if (!container.querySelector(".empty")) {
      container.innerHTML = emptyState("No active downloads", "Paste a link above to get started.");
    }
    return;
  }
  const emptyEl = container.querySelector(".empty");
  if (emptyEl) emptyEl.remove();

  list.forEach((dl, idx) => {
    const idStr = String(dl.id);
    let card = container.querySelector(`.download-card[data-id="${idStr}"]`);
    if (!card) card = buildActiveCard(dl);
    else updateActiveCard(card, dl);
    const currentAt = container.children[idx];
    if (currentAt !== card) container.insertBefore(card, currentAt || null);
  });
}

/* ================================================================
 *  Rendering — History items
 * ================================================================ */
const ICON_BTN = (action, id, title, svg, danger = false) =>
  `<button class="btn-icon${danger ? " danger" : ""}" data-action="${action}" data-id="${id}" title="${title}" aria-label="${title}">${svg}</button>`;

function historyActions(item) {
  const id = item.id;
  const st = normalizeStatus(item.status);

  if (st === "downloading") {
    return ICON_BTN("pause",  id, "Pause", SVG.pause)
         + ICON_BTN("cancel", id, "Cancel", SVG.x, true)
         + ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
  }
  if (st === "paused") {
    return ICON_BTN("resume", id, "Resume", SVG.play)
         + ICON_BTN("cancel", id, "Cancel", SVG.x, true)
         + ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
  }
  if (st === "completed") {
    return ICON_BTN("open",   id, "Open file", SVG.external)
         + ICON_BTN("folder", id, "Show in folder", SVG.folder)
         + ICON_BTN("copy",   id, "Copy URL", SVG.copy)
         + ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
  }
  if (st === "error" || st === "cancelled") {
    return ICON_BTN("retry",  id, "Retry", SVG.retry)
         + ICON_BTN("copy",   id, "Copy URL", SVG.copy)
         + ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
  }
  return ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
}

function historyItemHtml(item, { selectable = false } = {}) {
  const st = normalizeStatus(item.status);
  const isLive = item.isLive && st === "downloading";
  const percent = isLive ? Math.max(0, Math.min(100, item.percent || 0)) : 0;

  const check = selectable
    ? `<label class="check-wrap"><input type="checkbox" class="row-check" data-id="${item.id}" ${
        state.selected.has(Number(item.id)) ? "checked" : ""
      }><span class="check-box"></span></label>`
    : "";

  const metaParts = [];
  if (isLive) {
    metaParts.push(
      `<span class="hi-progress" data-live-progress="${item.id}">${Math.round(percent)}% · ${item.speedMBps || 0} MB/s</span>`
    );
  }
  metaParts.push(escapeHtml(formatBytes(item.totalSize)));
  metaParts.push(escapeHtml(formatDate(item.timestamp)));
  const meta = metaParts.join(`<span class="dot"></span>`);

  const selectedCls = state.selected.has(Number(item.id)) ? " selected" : "";

  return `
    <div class="history-item${selectedCls}" data-id="${item.id}">
      ${check}
      ${fileIconHtml(item.filename)}
      <div class="hi-info" data-action="details" data-id="${item.id}">
        <div class="hi-name" title="${escapeHtml(item.filename)}">${escapeHtml(item.filename)}</div>
        <div class="hi-meta">${meta}</div>
      </div>
      <div class="hi-status">${statusBadge(item.status)}</div>
      <div class="hi-actions">${historyActions(item)}</div>
    </div>
  `;
}

function emptyState(title, desc) {
  return `
    <div class="empty">
      <div class="empty-icon">${SVG.downloadEmpty}</div>
      <div class="empty-title">${escapeHtml(title)}</div>
      <div class="empty-desc">${escapeHtml(desc)}</div>
    </div>
  `;
}

/* Signature keeps us from rebuilding lists when nothing changed. */
function historySignature(list, opts = {}) {
  const sel = opts.selectable
    ? Array.from(state.selected).sort((a, b) => a - b).join(",")
    : "";
  const rows = list
    .map((x) => `${x.id}:${normalizeStatus(x.status)}:${x.isLive ? "L" : "-"}`)
    .join("|");
  return `${rows}#${sel}`;
}

function renderHistory(container, list, emptyTitle = "Nothing here yet", emptyDesc = "Your downloads will appear here.", opts = {}) {
  if (!container) return;
  const sig = historySignature(list, opts);
  if (container.dataset.sig === sig) return;   // no churn → no flicker
  container.dataset.sig = sig;

  if (!list.length) {
    container.innerHTML = emptyState(emptyTitle, emptyDesc);
    return;
  }
  container.innerHTML = list.map((item) => historyItemHtml(item, opts)).join("");
}

/* ================================================================
 *  Surgical live-progress updates
 * ================================================================ */
function updateLiveHistoryProgress() {
  if (state.active.size === 0) return;
  for (const [id, entry] of state.active.entries()) {
    const els = document.querySelectorAll(`[data-live-progress="${id}"]`);
    if (!els.length) continue;
    const percent = Math.max(0, Math.min(100, entry.percent || 0));
    const text = `${Math.round(percent)}% · ${entry.speedMBps || 0} MB/s`;
    els.forEach((el) => {
      if (el.textContent !== text) el.textContent = text;
    });
  }
}

/* ================================================================
 *  All Downloads — filter / search / sort
 * ================================================================ */
function applyAllControls(list) {
  let out = list.slice();

  if (state.allFilter !== "all") {
    out = out.filter((item) => normalizeStatus(item.status) === state.allFilter);
  }

  const q = state.allSearch.trim().toLowerCase();
  if (q) {
    out = out.filter((item) =>
      String(item.filename || "").toLowerCase().includes(q) ||
      String(item.url || "").toLowerCase().includes(q) ||
      String(item.status || "").toLowerCase().includes(q)
    );
  }

  const cmp = {
    newest:     (a, b) => new Date(b.timestamp || 0) - new Date(a.timestamp || 0),
    oldest:     (a, b) => new Date(a.timestamp || 0) - new Date(b.timestamp || 0),
    "name-asc": (a, b) => String(a.filename || "").localeCompare(String(b.filename || "")),
    "name-desc":(a, b) => String(b.filename || "").localeCompare(String(a.filename || "")),
    "size-desc":(a, b) => (Number(b.totalSize) || 0) - (Number(a.totalSize) || 0),
    "size-asc": (a, b) => (Number(a.totalSize) || 0) - (Number(b.totalSize) || 0),
    status:     (a, b) => normalizeStatus(a.status).localeCompare(normalizeStatus(b.status)),
  }[state.allSort];
  if (cmp) out.sort(cmp);

  return out;
}

function updateFilterCounts(list) {
  const counts = { all: 0, downloading: 0, paused: 0, completed: 0, error: 0, cancelled: 0 };
  for (const item of list) {
    counts.all++;
    const s = normalizeStatus(item.status);
    if (counts[s] != null) counts[s]++;
  }
  $$(".filter-tab .count").forEach((el) => {
    const key = el.dataset.count;
    if (key && counts[key] != null) el.textContent = String(counts[key]);
  });
}

function updateBulkBar() {
  const bar = $("#bulk-bar");
  const count = state.selected.size;
  if (bar) bar.hidden = count === 0;
  const label = $("#bulk-count");
  if (label) label.textContent = count === 1 ? "1 selected" : `${count} selected`;
}

function renderAll() {
  const merged = getMergedList();
  updateFilterCounts(merged);
  const list = applyAllControls(merged);
  const opts = { selectable: state.selectMode };
  renderHistory(
    $("#all-list"),
    list,
    state.allSearch ? "No matches" : "No downloads yet",
    state.allSearch
      ? "Try a different search term or clear the filter."
      : "Downloads you start will appear here.",
    opts
  );
  updateBulkBar();
}

/* ================================================================
 *  Top-level render
 * ================================================================ */
function renderActiveContainers() {
  const list = getActiveList();
  renderActive($("#active-list"), list);
  renderActive($("#active-view-list"), list);
  updateGlobalStatus();
}

function render() {
  const view = state.view;
  const merged = getMergedList();

  if (view === "dashboard") {
    renderActiveContainers();
    renderHistory($("#recent-list"), merged.slice(0, 5),
      "No downloads yet", "Your recent downloads will appear here.");
  }
  if (view === "all") {
    renderAll();
  }
  if (view === "active") {
    renderActiveContainers();
  }
  if (view === "recent") {
    renderHistory($("#recent-view-list"), merged.slice(0, 25),
      "No downloads yet", "Your recent downloads will appear here.");
  }
  if (view === "completed") {
    const completed = merged.filter((x) => normalizeStatus(x.status) === "completed");
    renderHistory($("#completed-list"), completed,
      "No completed downloads", "Finished downloads will appear here.");
  }

  updateGlobalStatus();
  updateDirectoryLabels();
  updateNavBadges(merged);
}

function updateNavBadges(merged) {
  const activeCount = state.active.size;
  const activeBadge = $("#active-badge");
  if (activeBadge) {
    activeBadge.hidden = activeCount === 0;
    activeBadge.textContent = String(activeCount);
  }

  const allBadge = $("#all-badge");
  if (allBadge) {
    allBadge.hidden = merged.length === 0;
    allBadge.textContent = String(merged.length);
  }

  const completedCount = merged.filter((x) => normalizeStatus(x.status) === "completed").length;
  const completedBadge = $("#completed-badge");
  if (completedBadge) {
    completedBadge.hidden = completedCount === 0;
    completedBadge.textContent = String(completedCount);
  }

  const completedCountEl = $("#settings-completed-count");
  if (completedCountEl) completedCountEl.textContent = String(completedCount);
}

function updateGlobalStatus() {
  const hint = $("#active-count-hint");
  const n = state.active.size;
  if (hint) hint.textContent = n === 1 ? "1 active" : `${n} active`;

  const pill = $("#global-status");
  const pillText = $("#global-status-text");
  if (pill && pillText) {
    if (n > 0) {
      pill.classList.add("busy");
      pillText.textContent = n === 1 ? "Downloading" : `${n} downloading`;
    } else {
      pill.classList.remove("busy");
      pillText.textContent = "Ready";
    }
  }
}

function updateDirectoryLabels() {
  const label = state.directory || "Default Downloads";
  const saveDir = $("#save-dir-display");
  const settingsDir = $("#settings-dir");
  const sidebarEl = $("#sidebar-dir");
  if (saveDir) saveDir.textContent = label;
  if (settingsDir) settingsDir.textContent = label;
  if (sidebarEl) {
    sidebarEl.textContent = label;
    sidebarEl.title = state.directory || "";
  }
}

/* ================================================================
 *  History refresh + active pruning
 * ================================================================ */
function hasPendingAction(id) {
  return (
    state.inflight.has(`pause:${id}`) ||
    state.inflight.has(`resume:${id}`) ||
    state.inflight.has(`cancel:${id}`)
  );
}

async function refreshHistory() {
  if (!window.api || !api.getHistory) return;
  try {
    state.history = await api.getHistory();

    for (const [id, entry] of Array.from(state.active.entries())) {
      if (hasPendingAction(id)) continue;

      const row = state.history.find((x) => x.id === id);
      if (!row) { state.active.delete(id); continue; }

      const st = String(row.status || "").toLowerCase();
      if (st === "downloading" || st === "preparing") {
        entry.status = st === "preparing" ? "Preparing" : "Downloading";
      } else if (st === "paused") {
        entry.status = "Paused";
        entry.speedMBps = 0;
        entry.etaSeconds = 0;
      } else {
        state.active.delete(id);
      }
    }

    render();
  } catch (err) {
    console.error("[flow] refreshHistory failed:", err);
  }
}

/* ---------------- Clipboard / input ---------------- */
async function handlePaste() {
  try {
    if (!window.api || !api.readClipboard) throw new Error("Clipboard API not available");
    const text = await api.readClipboard();
    if (!text || !text.trim()) { toast("Clipboard is empty", "warning"); return; }
    const input = $("#url-input");
    if (!input) return;
    input.value = text.trim();
    input.focus();
    input.setSelectionRange(input.value.length, input.value.length);
    toast("URL pasted successfully", "success");
  } catch (err) {
    console.error(err);
    toast("Could not read clipboard", "error");
  }
}

/* ---------------- Start download ---------------- */
async function handleDownload() {
  const input = $("#url-input");
  if (!input) return;
  const url = input.value.trim();

  if (!url) { toast("Please enter a URL", "warning"); input.focus(); return; }
  if (!isValidUrl(url)) { toast("Please enter a valid http(s) URL", "error"); input.focus(); return; }
  if (!window.api || !api.newDownload) { toast("Backend not available", "error"); return; }

  const btn = $("#download-btn");
  const original = btn ? btn.innerHTML : "";
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner"></span><span>Preparing…</span>`;
  }

  try {
    const res = await api.newDownload({ url, saveDirectory: state.directory });
    if (res && res.error) toast(res.error, "error");
    else if (res && res.id) {
      input.value = "";
      toast("Download started", "success");
      await refreshHistory();
    }
  } catch (err) {
    console.error(err);
    toast(err.message || "Failed to start download", "error");
  } finally {
    if (btn) { btn.disabled = false; btn.innerHTML = original; }
  }
}

/* ---------------- Lookup ---------------- */
function findItem(id) {
  const numId = Number(id);
  const row = state.history.find((x) => x.id === numId);
  if (row) {
    const live = state.active.get(numId);
    return {
      ...row,
      status: live ? live.status : getEffectiveStatus(row),
    };
  }
  const entry = state.active.get(numId);
  if (entry) {
    return {
      id: numId,
      filename: entry.filename,
      directory: entry.filePath,
      url: entry.url,
      totalSize: entry.totalSize,
      status: entry.status,
    };
  }
  return null;
}

/* ---------------- Action dispatch ---------------- */
async function handleAction(action, id) {
  const numId = Number(id);
  const key = `${action}:${numId}`;
  if (state.inflight.has(key)) return;
  state.inflight.add(key);

  try {
    switch (action) {
      case "pause": {
        const entry = state.active.get(numId);
        if (entry) {
          entry.status = "Paused";
          entry.speedMBps = 0;
          entry.etaSeconds = 0;
          render();
        }
        let res;
        try { res = await api.pauseDownload(numId); }
        catch (err) {
          if (entry) entry.status = "Downloading";
          render();
          toast("Could not pause: " + (err.message || err), "error");
          break;
        }
        if (!res || res.success === false) {
          if (entry) entry.status = "Downloading";
          render();
          toast((res && res.error) || "Could not pause download", "error");
        } else {
          toast("Download paused", "info");
        }
        break;
      }

      case "resume": {
        const item = findItem(numId);
        const prev = state.active.get(numId);

        const base = {
          id: numId,
          filename: item ? item.filename : (prev?.filename || "download"),
          filePath: item ? item.directory : prev?.filePath,
          totalSize: item ? item.totalSize : (prev?.totalSize || 0),
          percent: prev?.percent || 0,
          speedMBps: 0,
          etaSeconds: 0,
          startedAt: Date.now(),
        };
        const snapshot = { ...base, status: "Paused" };

        state.active.set(numId, { ...base, status: "Downloading" });
        render();

        let res;
        try { res = await api.resumeDownload(numId); }
        catch (err) {
          state.active.set(numId, snapshot);
          render();
          toast("Could not resume: " + (err.message || err), "error");
          break;
        }
        if (!res || res.success === false) {
          state.active.set(numId, snapshot);
          render();
          toast((res && res.error) || "Could not resume download", "error");
        } else {
          toast("Download resumed", "info");
        }
        break;
      }

      case "cancel": {
        const entry = state.active.get(numId);
        state.active.delete(numId);
        render();

        let res;
        try { res = await api.cancelDownload(numId, true); }
        catch (err) {
          if (entry) state.active.set(numId, entry);
          render();
          toast("Could not cancel: " + (err.message || err), "error");
          break;
        }
        if (!res || res.success === false) {
          if (entry) state.active.set(numId, entry);
          render();
          toast((res && res.error) || "Could not cancel download", "error");
        } else {
          toast("Download cancelled", "info");
        }
        break;
      }

      case "retry": {
        const item = findItem(numId);
        const prev = state.active.get(numId);

        const base = {
          id: numId,
          filename: item ? item.filename : (prev?.filename || "download"),
          filePath: item ? item.directory : prev?.filePath,
          totalSize: item ? item.totalSize : (prev?.totalSize || 0),
          percent: 0,
          speedMBps: 0,
          etaSeconds: 0,
          startedAt: Date.now(),
        };
        const snapshot = { ...base, status: "Error" };

        state.active.set(numId, { ...base, status: "Downloading" });
        render();

        let res;
        try { res = await api.resumeDownload(numId); }
        catch (err) {
          state.active.set(numId, snapshot);
          render();
          toast("Could not retry: " + (err.message || err), "error");
          break;
        }
        if (!res || res.success === false) {
          state.active.set(numId, snapshot);
          render();
          toast((res && res.error) || "Could not retry download", "error");
        } else {
          toast("Retrying download", "info");
        }
        break;
      }

      case "remove": {
        const ok = await confirmDialog(
          "Remove from history?",
          "This will remove the entry from your history list. The file on disk (if any) will be kept.",
          { confirmLabel: "Remove", danger: true }
        );
        if (!ok) break;
        const res = await api.deleteDownload(numId, false);
        if (res && res.success) toast("Removed from history", "info");
        else if (res && res.error) toast(res.error, "warning");
        state.selected.delete(numId);
        break;
      }

      case "open": {
        const item = findItem(numId);
        if (!item) break;
        const res = await api.openFile(item.directory);
        if (res && !res.success) toast(res.error || "File not found", "error");
        break;
      }
      case "folder": {
        const item = findItem(numId);
        if (!item) break;
        api.openFolder(item.directory);
        break;
      }
      case "copy": {
        const item = findItem(numId);
        if (!item || !item.url) { toast("No URL to copy", "warning"); break; }
        try {
          await navigator.clipboard.writeText(item.url);
          toast("URL copied", "success");
        } catch { toast("Could not copy URL", "error"); }
        break;
      }
      case "details": {
        const item = findItem(numId);
        if (!item) break;
        openDetails(item);
        break;
      }

      default: break;
    }
  } catch (err) {
    console.error("[flow] action failed:", action, err);
    toast(err.message || "Action failed", "error");
  } finally {
    state.inflight.delete(key);
    if (["pause", "resume", "cancel", "retry", "remove"].includes(action)) {
      try { await refreshHistory(); } catch {}
    }
  }
}

/* ---------------- Bulk actions ---------------- */
async function runBulk(kind) {
  const ids = Array.from(state.selected);
  if (!ids.length) return;

  if (kind === "clear-selection") {
    state.selected.clear();
    render();
    return;
  }

  if (kind === "remove") {
    const ok = await confirmDialog(
      "Remove selected from history?",
      `Remove ${ids.length} entr${ids.length === 1 ? "y" : "ies"} from your history? Files on disk (if any) will be kept.`,
      { confirmLabel: "Remove" }
    );
    if (!ok) return;
  }
  if (kind === "cancel") {
    const ok = await confirmDialog(
      "Cancel selected downloads?",
      `Cancel ${ids.length} active download${ids.length === 1 ? "" : "s"}? Partial files will be deleted.`,
      { confirmLabel: "Cancel downloads" }
    );
    if (!ok) return;
  }

  const results = await Promise.allSettled(ids.map((id) => handleAction(kind, id)));
  const failed = results.filter((r) => r.status === "rejected").length;
  state.selected.clear();
  if (failed) toast(`${failed} action(s) failed`, "warning");
  else toast(`Bulk ${kind} complete`, "success");
  await refreshHistory();
}

/* ---------------- Details modal ---------------- */
let _detailsItem = null;
function openDetails(item) {
  _detailsItem = item;
  const set = (id, val) => { const el = $(id); if (el) el.textContent = val; };
  set("#det-name", item.filename || "—");
  const statusEl = $("#det-status");
  if (statusEl) statusEl.innerHTML = statusBadge(item.status);
  set("#det-size", formatBytes(item.totalSize));
  set("#det-date", formatDate(item.timestamp));
  set("#det-path", item.directory || "—");
  set("#det-url",  item.url || "—");
  $("#details-modal")?.classList.add("open");
}

function closeDetails() {
  $("#details-modal")?.classList.remove("open");
  _detailsItem = null;
}

/* ---------------- Directory ---------------- */
async function chooseDirectory() {
  if (!window.api || !api.selectDirectory) return;
  const dir = await api.selectDirectory();
  if (!dir) return;
  state.directory = dir;
  updateDirectoryLabels();
  toast("Save folder updated", "success");
}

function resetDirectory() {
  state.directory = null;
  updateDirectoryLabels();
  toast("Reset to default folder", "info");
}

/* ================================================================
 *  IPC event wiring
 * ================================================================ */
function registerIpcListeners() {
  api.onDownloadStart((data) => {
    const id = data.id;
    state.active.set(id, {
      id,
      filename: data.fileName || data.filename || "download",
      filePath: data.filePath,
      totalSize: data.totalSize || 0,
      percent: 0,
      speedMBps: 0,
      etaSeconds: 0,
      status: "Downloading",
      startedAt: Date.now(),
    });
    render();
    refreshHistory();
  });

  api.onDownloadProgress((data) => {
    const id = data.id;
    let entry = state.active.get(id);
    if (!entry) {
      const row = state.history.find((x) => x.id === id);
      if (!row) return;
      const s = String(row.status || "").toLowerCase();
      if (s !== "downloading" && s !== "preparing") return;
      entry = {
        id,
        filename: row.filename,
        filePath: row.directory,
        totalSize: row.totalSize,
        status: "Downloading",
        startedAt: Date.now(),
      };
      state.active.set(id, entry);
    }

    if (entry.status === "Paused") return;

    entry.percent    = Math.max(0, Math.min(100, parseFloat(data.percent) || 0));
    entry.speedMBps  = data.speedMBps || 0;
    entry.etaSeconds = data.etaSeconds || 0;
    entry.status     = "Downloading";

    // Surgical updates only — do NOT call render() here, or every history
    // list gets rebuilt and hover transitions flicker.
    renderActiveContainers();
    updateLiveHistoryProgress();
  });

  api.onDownloadError((data) => {
    // Don't rip the card out of Current Downloads on a resume failure —
    // the main process restores DB to 'Paused' and refreshHistory will
    // keep the row. Only toast the message here.
    if (!data.silent) {
      toast(data.message || "Download failed", "error");
    }
    refreshHistory();
  });

  api.onStatusChange(() => {
    refreshHistory();
  });
}

/* ================================================================
 *  Event listeners
 * ================================================================ */
function bindEvents() {
  $$(".nav-item").forEach((btn) => {
    btn.addEventListener("click", () => setView(btn.dataset.view));
  });

  document.addEventListener("click", (e) => {
    const goto = e.target.closest("[data-goto]");
    if (goto) { setView(goto.dataset.goto); return; }
  });

  on("#theme-toggle", "click", toggleTheme);
  on("#settings-theme-toggle", "click", toggleTheme);

  on("#paste-btn", "click", handlePaste);
  on("#download-btn", "click", handleDownload);
  on("#url-input", "keydown", (e) => { if (e.key === "Enter") handleDownload(); });

  on("#quick-dir-btn", "click", chooseDirectory);
  on("#settings-choose-dir", "click", chooseDirectory);
  on("#settings-reset-dir", "click", resetDirectory);

  on("#filter-tabs", "click", (e) => {
    const tab = e.target.closest(".filter-tab");
    if (!tab) return;
    state.allFilter = tab.dataset.filter || "all";
    $$(".filter-tab").forEach((t) => t.classList.toggle("active", t === tab));
    renderAll();
  });

  on("#all-search", "input", (e) => {
    state.allSearch = e.target.value || "";
    renderAll();
  });

  on("#all-sort", "change", (e) => {
    state.allSort = e.target.value;
    renderAll();
  });

  on("#select-toggle-btn", "click", () => {
    state.selectMode = !state.selectMode;
    if (!state.selectMode) state.selected.clear();
    renderAll();
  });

  on("#bulk-bar", "click", (e) => {
    const btn = e.target.closest("[data-bulk]");
    if (!btn) return;
    runBulk(btn.dataset.bulk);
  });

  const clearCompletedHandler = async () => {
    const ok = await confirmDialog(
      "Clear completed downloads?",
      "All completed entries will be removed from your history. The files on disk will not be touched.",
      { confirmLabel: "Clear completed" }
    );
    if (!ok) return;
    const res = await api.clearCompleted();
    if (res && res.success) toast(`Removed ${res.removed} entr${res.removed === 1 ? "y" : "ies"}`, "success");
    else toast((res && res.error) || "Could not clear completed", "error");
  };
  on("#clear-completed-btn", "click", clearCompletedHandler);
  on("#settings-clear-completed", "click", clearCompletedHandler);

  on("#modal-close", "click", closeDetails);
  on("#details-modal", "click", (e) => {
    if (e.target.id === "details-modal") closeDetails();
  });

  on("#det-copy-url", "click", async () => {
    if (!_detailsItem || !_detailsItem.url) return;
    try { await navigator.clipboard.writeText(_detailsItem.url); toast("URL copied", "success"); }
    catch { toast("Could not copy URL", "error"); }
  });
  on("#det-open-folder", "click", () => {
    if (_detailsItem?.directory) api.openFolder(_detailsItem.directory);
  });

  on("#confirm-ok", "click", () => closeConfirm(true));
  on("#confirm-cancel", "click", () => closeConfirm(false));
  on("#confirm-modal", "click", (e) => {
    if (e.target.id === "confirm-modal") closeConfirm(false);
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      closeDetails();
      closeConfirm(false);
    }
  });

  document.addEventListener("click", (e) => {
    const check = e.target.closest(".row-check");
    if (check) {
      const id = Number(check.dataset.id);
      if (check.checked) state.selected.add(id);
      else state.selected.delete(id);
      renderAll();
      return;
    }

    const btn = e.target.closest("[data-action]");
    if (!btn) return;
    const { action, id } = btn.dataset;
    if (!id) return;
    handleAction(action, id);
  });
}

/* ================================================================
 *  Fatal error display
 * ================================================================ */
function showFatal(message) {
  console.error("[flow] FATAL:", message);
  document.body.innerHTML = `
    <div style="padding:40px;font-family:ui-monospace,Menlo,monospace;color:#ef4444;background:#0b0d12;min-height:100vh;box-sizing:border-box;">
      <h1 style="margin:0 0 12px;">⚠️ Flow failed to start</h1>
      <pre style="white-space:pre-wrap;color:#f0f0f0;font-size:13px;">${escapeHtml(message)}</pre>
      <p style="color:#8a93a4;font-size:12px;margin-top:20px;">
        Open DevTools (Ctrl+Shift+I / Cmd+Option+I) to see the full error.
      </p>
    </div>`;
}

/* ================================================================
 *  Boot
 * ================================================================ */
async function boot() {
  if (!window.api) {
    showFatal(
      "window.api is undefined.\n\n" +
      "The preload script did not expose the API. Check:\n" +
      "  • preload.js exists next to main.js\n" +
      "  • main.js webPreferences.preload points to it\n" +
      "  • preload.js has no syntax errors (check DevTools)"
    );
    return;
  }

  try { applyTheme(); } catch (e) { console.error("[flow] applyTheme:", e); }
  try { bindEvents(); } catch (e) { console.error("[flow] bindEvents:", e); }

  try { registerIpcListeners(); } catch (e) {
    console.error("[flow] registerIpcListeners:", e);
    showFatal("Failed to register IPC listeners: " + e.message);
    return;
  }

  try {
    if (api.getDefaultDirectory) {
      state.defaultDirectory = await api.getDefaultDirectory();
    }
  } catch (e) { console.error("[flow] getDefaultDirectory:", e); }

  try { await refreshHistory(); } catch (e) { console.error(e); }
  try { setView("dashboard"); } catch (e) { console.error("[flow] setView:", e); }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", boot, { once: true });
} else {
  boot();
}