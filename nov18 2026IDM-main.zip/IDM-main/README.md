# Flow — Multithreaded Download Manager

> A fast, resumable, multithreaded download manager built on Electron.
> Adaptive worker pool, chunk-level work-stealing, HTTP/2 with HTTP/1.1
> fallback, and a browser-extension bridge for capturing downloads.

---

## Table of Contents

- [Features](#features)
- [Screenshots](#screenshots)
- [Requirements](#requirements)
- [Installation](#installation)
- [Usage](#usage)
  - [Downloading a file](#downloading-a-file)
  - [Managing downloads](#managing-downloads)
  - [Browser extension](#browser-extension)
- [How it works](#how-it-works)
  - [Architecture](#architecture)
  - [The download pipeline](#the-download-pipeline)
  - [Resume & partial state](#resume--partial-state)
- [Project structure](#project-structure)
- [Configuration](#configuration)
- [HTTP bridge API](#http-bridge-api)
- [Troubleshooting](#troubleshooting)
- [Development](#development)
- [Roadmap](#roadmap)
- [License](#license)

---

## Features

| Category | What you get |
|---|---|
| **Speed** | 2–20 parallel workers, adaptive to file size. Chunk-level work-stealing keeps fast connections saturated and slow ones busy. |
| **Resilience** | Chunk-level retries (main + worker), stall watchdog, atomic state writes, corrupted-state detection. |
| **Resume** | Per-chunk byte-offset persistence in a `.fastdl` sidecar. Pause/resume survives app restarts, crashes, and force-quits. |
| **Protocol** | HTTP/2 first, per-worker HTTP/1.1 keep-alive fallback. Range-request verification. HTML-error-page detection. |
| **UX** | Live speed + ETA, per-download pause/resume/cancel, bulk selection, filter/search/sort, dark/light theme. |
| **Extension** | Local HTTP bridge on `127.0.0.1:27812` for capturing downloads from your browser. |
| **Safety** | Filename sanitization (Windows reserved names, length caps), disk-space pre-flight check, collision-safe naming, cross-device rename fallback. |
| **YouTube** | Optional `youtubeManager` module — if `yt-dlp` is installed, YouTube URLs route to it automatically. |

---

## Screenshots

> *Add your own — drop PNGs into `docs/` and reference them here.*
>
> ```
> ![Dashboard](docs/dashboard.png)
> ![All downloads](docs/all.png)
> ```

---

## Requirements

- **Node.js** 18 or newer
- **npm** 8 or newer
- **OS** Linux, macOS, or Windows
- *(optional)* `xdotool` on Linux for reliable window-raising from the bridge
- *(optional)* `yt-dlp` on `PATH` for YouTube downloads

---

## Installation

```bash
git clone https://github.com/yourname/flow.git
cd flow
npm install