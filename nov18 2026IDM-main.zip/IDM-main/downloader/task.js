/* ================================================================
 *  Flow — DownloadTask (v3.4)
 *
 *  Single owner of a download's lifecycle.
 *
 *  Non-resumable resume fix (v3.4)
 *  -------------------------------
 *  Previously, _initNonResumable wiped the .fastdl and .download files
 *  before any resume attempt, so pausing a non-resumable download and
 *  clicking Resume silently restarted from byte 0 and lost all
 *  progress.
 *
 *  Now _initNonResumable tries to resume from an existing state file
 *  first. On success, the chunk's `downloaded` offset is restored and
 *  the worker re-requests from that byte. The server (which does not
 *  honour Range) returns the whole file with 200 OK; transport.js
 *  marks it `fullResponse`, and range.js inserts a skip transform to
 *  discard the leading `downloaded` bytes before writing. Progress is
 *  preserved across pause/resume and across app restarts.
 *
 *  If the state file is missing or invalid (corrupt, mismatched size,
 *  validator mismatch, or a state file from a chunked download), we
 *  fall back to the old wipe-and-restart behaviour.
 * ================================================================ */

const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");
const crypto = require("crypto");
const { EventEmitter } = require("events");
const { Worker } = require("worker_threads");
const { performance } = require("perf_hooks");

const {
    STALL_TIMEOUT_MS,
    WATCHDOG_INTERVAL_MS,
    FORCE_KILL_MS,
    MAX_CHUNK_ATTEMPTS,
    PROGRESS_THROTTLE_MS,
    NO_PROGRESS_FAIL_MS,
    RESUME_GRACE_MS,
    THROTTLE_GROWTH_INTERVAL_MS,
    MAX_WORKER_RESPAWNS,
    FINALIZE_TIMEOUT_MS,
    MB,
} = require("./config");

const { renameWithRetry, uniquePath } = require("./utils");
const {
    computeWorkerCount,
    computeChunkSize,
    buildChunkLayout,
    isValidState,
    persistState,
    hashUrl,
} = require("./chunkState");
const { stampMarkOfTheWeb } = require("./motw");

/* ---------------- State enum & transitions ---------------- */
const STATES = Object.freeze({
    DOWNLOADING: "downloading",
    WAITING:     "waiting",
    PAUSING:     "pausing",
    CANCELLING:  "cancelling",
    FAILING:     "failing",
    FINALIZING:  "finalizing",
    FINALIZED:   "finalized",
});

const TRANSITIONS = Object.freeze({
    downloading: new Set(["downloading", "waiting", "pausing", "cancelling", "failing", "finalizing"]),
    waiting:     new Set(["downloading", "pausing", "cancelling", "failing", "finalizing"]),
    pausing:     new Set(["cancelling", "finalizing", "finalized"]),
    cancelling:  new Set(["finalizing", "finalized"]),
    failing:     new Set(["finalizing", "finalized"]),
    finalizing:  new Set(["finalized"]),
    finalized:   new Set(),
});

const ACTIVE_STATES = new Set([STATES.DOWNLOADING, STATES.WAITING]);

/* ---------------- Auto-sort category map ---------------- */
const CATEGORY_EXT = {
    Video:      ["mp4","mkv","avi","mov","webm","flv","m4v","wmv","mpg","mpeg","ts","m2ts"],
    Music:      ["mp3","wav","flac","aac","ogg","m4a","wma","opus","aiff"],
    Documents:  ["pdf","doc","docx","txt","rtf","odt","md","xls","xlsx","ppt","pptx","csv","epub"],
    Compressed: ["zip","rar","7z","tar","gz","bz2","xz","iso","dmg"],
};

function getFileCategory(filename) {
    const ext = (String(filename || "").split(".").pop() || "").toLowerCase();
    for (const [cat, exts] of Object.entries(CATEGORY_EXT)) {
        if (exts.includes(ext)) return cat;
    }
    return "Other";
}

class DownloadTask extends EventEmitter {
    /* =========================================================
     *  Constructor
     * ========================================================= */
    constructor({ id, url, filePath, totalSize, sender, extraHeaders = {}, validators = {} }) {
        super();

        if (!id || typeof id !== "string") throw new Error("id must be a non-empty string");
        if (typeof url !== "string" || !url) throw new Error("url must be a non-empty string");
        if (typeof filePath !== "string" || !path.isAbsolute(filePath)) {
            throw new Error("filePath must be an absolute path");
        }
        if (!Number.isInteger(totalSize) || totalSize < 0) {
            throw new Error("totalSize must be a finite non-negative integer");
        }
        if (extraHeaders && (typeof extraHeaders !== "object" || Array.isArray(extraHeaders))) {
            throw new Error("extraHeaders must be a plain object");
        }

        this.id = id;
        this.url = url;
        this.filePath = filePath;
        this.totalSize = totalSize;
        this.sender = sender;
        this.extraHeaders = extraHeaders;
        this.validators = {
            etag: validators.etag || null,
            lastModified: validators.lastModified || null,
            validator: validators.validator || null,
            contentType: validators.contentType || null,
            finalUrl: validators.finalUrl || url,
            resumable: validators.resumable !== false,
            saveDirectory: validators.saveDirectory || path.dirname(filePath),
        };

        this.statePath = filePath + ".fastdl";
        this.tempFilePath = filePath + ".download";

        this.state = STATES.DOWNLOADING;

        this.chunks = [];
        this.chunkSize = 0;
        this.pendingChunks = [];
        this.finishedChunks = new Set();
        this.workers = new Map();
        this._nextWorkerId = 0;
        this.workersTotal = 0;
        this.activeConcurrency = 0;
        this.workerCount = 0;

        this.totalDownloaded = 0;
        this.initialDownloaded = 0;
        this._speedSamples = [];
        this._lastProgressEmitAt = 0;

        this.firstError = null;
        this.firstErrorCode = null;
        this._workerRespawns = 0;

        this.watchdog = null;
        this.forceKillTimer = null;
        this._growthTimer = null;
        this._waitTimer = null;

        this._persistAttemptAt = 0;
        this._persistChain = Promise.resolve();

        this._startedAt = this._monotonicNow();
        this._lastGlobalProgressAt = this._startedAt;
        this._resumeGraceUntil = 0;

        this._lastThrottleAt = 0;
        this._throttleCount = 0;
        this._retryTimers = new Set();

        this._resolveRun = null;
        this._resolvePause = null;
        this._resolveCancel = null;
        this._finalized = false;
        this._finalizePromise = null;

        if (this.sender && typeof this.sender.send === "function") {
            this.on("progress", (payload) => {
                try { this.sender.send("download-progress", payload); } catch { /* renderer gone */ }
            });
        }

        this.on("error", () => {});
    }

    /* =========================================================
     *  Public API
     * ========================================================= */
    run() {
        return new Promise((resolve, reject) => {
            this._resolveRun = resolve;
            (async () => {
                try {
                    if (this._handlePostRenameCleanup()) return;
                    await this._initChunks();
                } catch (err) {
                    this._finalized = true;
                    this.state = STATES.FINALIZED;
                    return reject(err);
                }
                this._start();
            })();
        });
    }

    pause() {
        return new Promise((resolve) => {
            if (!ACTIVE_STATES.has(this.state)) {
                return resolve({
                    success: false,
                    error: this._stateError(`Cannot pause from state '${this.state}'`),
                });
            }
            this._resolvePause = resolve;
            this._transition(STATES.PAUSING);
            this._clearForceKill();
            this._broadcastAbort();
            this._maybeFinalize();
            if (!this._finalized) this._armForceKill();
        });
    }

    cancel() {
        return new Promise((resolve) => {
            if (!ACTIVE_STATES.has(this.state) && this.state !== STATES.PAUSING) {
                return resolve({
                    success: false,
                    error: this._stateError(`Cannot cancel from state '${this.state}'`),
                });
            }
            this._resolveCancel = resolve;
            this._transition(STATES.CANCELLING);
            this._clearForceKill();
            this._broadcastAbort();
            this._maybeFinalize();
            if (!this._finalized) this._armForceKill();
        });
    }

    onSystemResume() {
        const now = this._monotonicNow();
        this._resumeGraceUntil = now + RESUME_GRACE_MS;
        for (const chunk of this.chunks) {
            if (chunk.state === "claimed") chunk.lastActivity = now;
        }
        this._lastGlobalProgressAt = now;
    }

    /* =========================================================
     *  Clock & primitives
     * ========================================================= */
    _monotonicNow() {
        return performance.now();
    }

    _transition(newState) {
        const allowed = TRANSITIONS[this.state];
        if (!allowed || !allowed.has(newState)) {
            throw new Error(`Illegal state transition ${this.state} -> ${newState}`);
        }
        const oldState = this.state;
        this.state = newState;
        try { this.emit("state-change", oldState, newState); } catch { /* listener threw */ }
        if (newState === STATES.WAITING) {
            try { this.emit("waiting"); } catch { /* listener threw */ }
        }
    }

    _stateError(msg) {
        return this.firstError ? `${msg}: ${this.firstError}` : msg;
    }

    _setFirstError(message, code) {
        if (this.firstError) return;
        this.firstError = message;
        this.firstErrorCode = code;
        try { this.emit("error", new Error(message)); } catch { /* listener threw */ }
    }

    _log(text) {
        try { this.emit("log", text); } catch { /* listener threw */ }
        console.log(`[downloadManager id=${this.id}] ${text}`);
    }

    _errorLog(text, err) {
        const suffix = err ? `: ${err.message || String(err)}` : "";
        console.error(`[downloadManager id=${this.id}] ${text}${suffix}`);
    }

    /* =========================================================
     *  Init — async so a large file does not block the main thread
     * ========================================================= */
    async _initChunks() {
        if (this.validators.resumable === false) {
            return this._initNonResumable();
        }

        const workerCount = computeWorkerCount(this.totalSize);
        const chunkSize = computeChunkSize(this.totalSize, workerCount);
        this.workerCount = workerCount;
        this.chunkSize = chunkSize;

        let chunks = null;
        const stateExists = fs.existsSync(this.statePath);
        const tempExists = fs.existsSync(this.tempFilePath);

        if (stateExists && tempExists) {
            chunks = this._tryResume();
        }

        if (!chunks) {
            if (tempExists && this.totalSize > 0) {
                const orphanPath = `${this.tempFilePath}.orphan-${Date.now()}`;
                try {
                    fs.renameSync(this.tempFilePath, orphanPath);
                    this._log(`preserved orphaned partial: ${orphanPath}`);
                } catch (err) {
                    this._errorLog("could not preserve orphan", err);
                }
            }
            const fh = await fsp.open(this.tempFilePath, "w");
            try { await fh.truncate(this.totalSize); } finally { await fh.close(); }
            chunks = buildChunkLayout(this.totalSize, chunkSize);
            this._log(`starting fresh: ${chunks.length} chunks, target ${workerCount} workers`);
        }

        this.chunks = chunks;
        this.totalDownloaded = chunks.reduce((a, c) => a + c.downloaded, 0);
        this.initialDownloaded = this.totalDownloaded;

        for (const c of chunks) {
            if (c.state === "pending") this.pendingChunks.push(c.id);
            else if (c.state === "done") this.finishedChunks.add(c.id);
        }

        const pending = this.pendingChunks.length;
        this.workersTotal = pending === 0 ? 0 : Math.min(workerCount, pending);
        this.activeConcurrency = this.workersTotal;
    }

    /**
     * Non-resumable single-stream layout.
     *
     * If a valid state file and pre-allocated temp file already exist,
     * resume from the saved `downloaded` byte offset. The server will
     * ignore Range and return the whole file with 200; the worker's
     * skip transform drops the leading `downloaded` bytes before
     * writing, preserving progress across pause and restart.
     */
    async _initNonResumable() {
        const stateExists = fs.existsSync(this.statePath);
        const tempExists  = fs.existsSync(this.tempFilePath);

        if (stateExists && tempExists) {
            const resumed = this._tryResumeNonResumable();
            if (resumed) {
                this.chunks = [resumed];
                this.chunkSize = this.totalSize;
                this.workerCount = 1;
                this.workersTotal = 1;
                this.activeConcurrency = 1;
                this.totalDownloaded = resumed.downloaded;
                this.initialDownloaded = this.totalDownloaded;

                if (resumed.downloaded >= this.totalSize) {
                    this.finishedChunks = new Set([0]);
                    this.pendingChunks = [];
                } else {
                    this.finishedChunks = new Set();
                    this.pendingChunks = [0];
                }
                this._log(
                    `non-resumable: resuming at byte ${resumed.downloaded}/${this.totalSize}`
                );
                return;
            }
        }

        // Fresh start — wipe any stale partial data.
        try { if (stateExists) fs.unlinkSync(this.statePath); } catch {}
        try { if (tempExists) fs.unlinkSync(this.tempFilePath); } catch {}

        if (this.totalSize === 0) {
            this.chunks = [];
            this.pendingChunks = [];
            this.finishedChunks = new Set();
            this.workerCount = 0;
            this.workersTotal = 0;
            this.activeConcurrency = 0;
            this.chunkSize = 0;
            this.totalDownloaded = 0;
            this.initialDownloaded = 0;
            return;
        }

        const fh = await fsp.open(this.tempFilePath, "w");
        try { await fh.truncate(this.totalSize); } finally { await fh.close(); }

        this.chunks = [{
            id: 0,
            start: 0,
            end: this.totalSize - 1,
            downloaded: 0,
            state: "pending",
            workerId: null,
            attempts: 0,
            lastActivity: 0,
        }];
        this.chunkSize = this.totalSize;
        this.workerCount = 1;
        this.workersTotal = 1;
        this.activeConcurrency = 1;
        this.totalDownloaded = 0;
        this.initialDownloaded = 0;
        this.pendingChunks = [0];
        this.finishedChunks = new Set();

        this._log("non-resumable: single-stream download from byte 0");
    }

    /**
     * Validate and hydrate a saved state file for a non-resumable
     * download. Returns the resumed chunk on success, null otherwise.
     */
    _tryResumeNonResumable() {
        let parsed;
        try {
            parsed = JSON.parse(fs.readFileSync(this.statePath, "utf8"));
        } catch (err) {
            this._errorLog("non-resumable: corrupt state file — restart", err);
            return null;
        }

        let tempSize = -1;
        try { tempSize = fs.statSync(this.tempFilePath).size; } catch { return null; }
        if (tempSize !== this.totalSize) {
            this._log(`non-resumable: temp size ${tempSize} != ${this.totalSize} — restart`);
            return null;
        }

        if (!isValidState(parsed, this.totalSize)) {
            this._log("non-resumable: state validation failed — restart");
            return null;
        }

        if (parsed.chunks.length !== 1) {
            // A chunked state file paired with a non-resumable probe means
            // the file's Range support changed between runs. Safer to
            // restart than to reinterpret the chunk layout.
            this._log(
                `non-resumable: state has ${parsed.chunks.length} chunks — restart`
            );
            return null;
        }

        const c = parsed.chunks[0];
        if (c.start !== 0 || c.end !== this.totalSize - 1) {
            this._log("non-resumable: state chunk layout mismatch — restart");
            return null;
        }

        // Validator gate: only resume if the file has not changed.
        const storedValidator  = parsed.validator || null;
        const currentValidator = this.validators.validator || null;
        if (storedValidator && currentValidator && storedValidator !== currentValidator) {
            this._log("non-resumable: validator mismatch — restart");
            return null;
        }

        // Restore captured metadata from state.
        if (parsed.validator)    this.validators.validator = parsed.validator;
        if (parsed.etag)         this.validators.etag = parsed.etag;
        if (parsed.lastModified) this.validators.lastModified = parsed.lastModified;
        if (parsed.contentType)  this.validators.contentType = parsed.contentType;

        return {
            id: 0,
            start: 0,
            end: this.totalSize - 1,
            downloaded: c.downloaded,
            state: "pending",
            workerId: null,
            attempts: 0,
            lastActivity: 0,
        };
    }

    _tryResume() {
        let parsed;
        try {
            parsed = JSON.parse(fs.readFileSync(this.statePath, "utf8"));
        } catch (err) {
            this._errorLog("corrupt state file", err);
            return null;
        }

        let tempSize = -1;
        try { tempSize = fs.statSync(this.tempFilePath).size; } catch { return null; }
        if (tempSize !== this.totalSize) {
            this._log(`temp size ${tempSize} != totalSize ${this.totalSize} — restart`);
            return null;
        }

        if (!isValidState(parsed, this.totalSize)) {
            this._log("state validation failed — restart");
            return null;
        }

        const storedValidator = parsed.validator || null;
        const currentValidator = this.validators.validator || null;
        const bothHave = storedValidator && currentValidator;
        const neitherHas = !storedValidator && !currentValidator;

        if (bothHave && storedValidator !== currentValidator) {
            this._log(`validator mismatch (${storedValidator} != ${currentValidator}) — restart`);
            return null;
        }
        if (neitherHas) {
            const storedUrlHash = parsed.urlHash || null;
            if (storedUrlHash && storedUrlHash !== hashUrl(this.url)) {
                this._log("URL changed and no validator available — restart");
                return null;
            }
        }

        if (parsed.validator) this.validators.validator = parsed.validator;
        if (parsed.etag) this.validators.etag = parsed.etag;
        if (parsed.lastModified) this.validators.lastModified = parsed.lastModified;
        if (parsed.contentType) this.validators.contentType = parsed.contentType;

        const resumed = parsed.chunks.map((c) => ({
            ...c,
            state: c.downloaded >= (c.end - c.start + 1) ? "done" : "pending",
            workerId: null,
            attempts: 0,
            lastActivity: 0,
        }));
        const done = resumed.filter((c) => c.state === "done").length;
        this._log(`resuming: ${done}/${resumed.length} chunks complete`);
        return resumed;
    }

    _handlePostRenameCleanup() {
        const stateExists = fs.existsSync(this.statePath);
        const tempExists = fs.existsSync(this.tempFilePath);
        const finalExists = fs.existsSync(this.filePath);
        if (!stateExists || tempExists || !finalExists) return false;
        try { fs.unlinkSync(this.statePath); } catch { /* best effort */ }
        this._log("finalize-complete-but-uncleaned; cleaned state file");
        this._transition(STATES.FINALIZING);
        this._transition(STATES.FINALIZED);
        this._finalized = true;
        this._resolveRun?.({ success: true, filePath: this.filePath });
        return true;
    }

    _start() {
        if (this.totalSize === 0) {
            fs.writeFileSync(this.tempFilePath, "");
            this.chunks.forEach((c) => this.finishedChunks.add(c.id));
            setImmediate(() => this._maybeFinalize());
            return;
        }

        this._startWatchdog();
        this._scheduleConcurrencyGrowth();

        if (this.pendingChunks.length === 0) {
            setImmediate(() => this._maybeFinalize());
            return;
        }
        this._ensureWorkerCount();
    }

    /* =========================================================
     *  Worker lifecycle
     * ========================================================= */
    _ensureWorkerCount() {
        if (!ACTIVE_STATES.has(this.state)) return;
        if (this.pendingChunks.length === 0) return this._maybeFinalize();
        const live = this._activeWorkerCount();
        const needed = Math.min(this.activeConcurrency - live, this.pendingChunks.length);
        for (let i = 0; i < needed; i++) this._spawnWorker(this._nextWorkerId++);
    }

    _spawnWorker(workerId) {
        let worker;
        try {
            worker = new Worker(path.join(__dirname, "worker", "index.js"), {
                workerData: {
                    url: this.url,
                    headers: this.extraHeaders,
                    tempFilePath: this.tempFilePath,
                    workerId,
                    maxAttempts: 3,
                    ifRange: this.validators.validator || null,
                    probeContentType: this.validators.contentType || null,
                    totalSize: this.totalSize,
                },
            });
        } catch (err) {
            this._errorLog(`failed to spawn worker ${workerId}`, err);
            this._setFirstError("Failed to spawn download worker", "transient");
            this._enterFailing();
            return;
        }

        const entry = {
            id: workerId,
            worker,
            currentChunkId: null,
            alive: true,
            spawnedAt: this._monotonicNow(),
        };
        this.workers.set(workerId, entry);

        worker.on("message", (msg) => this._handleWorkerMessage(entry, msg));
        worker.on("error", (err) => this._handleWorkerError(entry, err));
        worker.on("exit", (code) => this._handleWorkerExit(entry, code));

        setImmediate(() => {
            if (ACTIVE_STATES.has(this.state)) {
                this._assignNextChunk(entry);
            } else {
                try { entry.worker.postMessage({ type: "no_more_chunks" }); } catch { /* already dead */ }
            }
        });
    }

    _handleWorkerError(entry, err) {
        this._errorLog(`worker ${entry.id} error`, err);
        if (!entry.alive) return;
        entry.alive = false;
        this._requeueChunk(entry);
        this.workers.delete(entry.id);
        this._respawnAfterCrash("Download worker crashed");
        this._maybeFinalize();
    }

    _handleWorkerExit(entry, code) {
        if (!entry.alive) {
            this.workers.delete(entry.id);
            return;
        }
        entry.alive = false;
        this._requeueChunk(entry);
        this.workers.delete(entry.id);

        if (code !== 0 && ACTIVE_STATES.has(this.state)) {
            this._errorLog(`worker ${entry.id} exited abnormally (code ${code})`);
            this._respawnAfterCrash("Download worker exited abnormally");
        } else if (ACTIVE_STATES.has(this.state)) {
            this._tryRespawnWorker();
        }
        this._maybeFinalize();
    }

    _respawnAfterCrash(reason) {
        if (this._workerRespawns >= MAX_WORKER_RESPAWNS) {
            this._setFirstError(reason || "Download worker crashed repeatedly", "transient");
            this._enterFailing();
            return;
        }
        this._workerRespawns++;
        this._tryRespawnWorker();
    }

    _tryRespawnWorker() {
        if (!ACTIVE_STATES.has(this.state)) return;
        if (this.pendingChunks.length === 0) return;
        if (this._activeWorkerCount() >= this.activeConcurrency) return;
        this._spawnWorker(this._nextWorkerId++);
    }

    _requeueChunk(entry) {
        if (entry.currentChunkId === null) return;
        const chunk = this.chunks[entry.currentChunkId];
        if (chunk && chunk.state === "claimed" && chunk.workerId === entry.id) {
            chunk.state = "pending";
            chunk.workerId = null;
            if (!this.pendingChunks.includes(chunk.id)) this.pendingChunks.push(chunk.id);
        }
        entry.currentChunkId = null;
    }

    _terminateAllWorkers() {
        const promises = [];
        for (const entry of this.workers.values()) {
            entry.alive = false;
            try {
                const p = entry.worker.terminate();
                if (p && typeof p.then === "function") promises.push(p.catch(() => {}));
            } catch { /* already dead */ }
        }
        this.workers.clear();
        return Promise.all(promises);
    }

    _activeWorkerCount() {
        let n = 0;
        for (const w of this.workers.values()) if (w.alive) n++;
        return n;
    }

    _broadcastAbort() {
        for (const w of this.workers.values()) {
            try { w.worker.postMessage({ type: "abort" }); } catch { /* dead */ }
        }
    }

    /* =========================================================
     *  Chunk assignment
     * ========================================================= */
    _assignNextChunk(entry) {
        if (!ACTIVE_STATES.has(this.state)) {
            entry.currentChunkId = null;
            try { entry.worker.postMessage({ type: "no_more_chunks" }); } catch { /* dead */ }
            return false;
        }
        if (this._activeWorkerCount() > this.activeConcurrency) {
            entry.currentChunkId = null;
            try { entry.worker.postMessage({ type: "no_more_chunks" }); } catch { /* dead */ }
            return false;
        }
        while (this.pendingChunks.length > 0) {
            const chunkId = this.pendingChunks.shift();
            const chunk = this.chunks[chunkId];
            if (!chunk || chunk.state !== "pending") continue;
            chunk.state = "claimed";
            chunk.workerId = entry.id;
            chunk.lastActivity = this._monotonicNow();
            entry.currentChunkId = chunkId;
            try {
                entry.worker.postMessage({ type: "chunk", chunk });
            } catch (err) {
                this._errorLog(`failed to send chunk ${chunkId} to worker ${entry.id}`, err);
                chunk.state = "pending";
                chunk.workerId = null;
                this.pendingChunks.unshift(chunkId);
                entry.currentChunkId = null;
                entry.alive = false;
                this.workers.delete(entry.id);
                try { entry.worker.terminate().catch(() => {}); } catch { /* dead */ }
                this._respawnAfterCrash("Failed to send chunk to worker");
                return false;
            }
            return true;
        }
        entry.currentChunkId = null;
        try { entry.worker.postMessage({ type: "no_more_chunks" }); } catch { /* dead */ }
        return false;
    }

    /* =========================================================
     *  Worker message handlers
     * ========================================================= */
    _handleWorkerMessage(entry, msg) {
        if (!msg || !entry.alive) return;
        if (this.state === STATES.FINALIZED || this.state === STATES.FINALIZING) return;

        switch (msg.type) {
            case "progress":     return this._onProgress(entry, msg);
            case "chunk_done":   return this._onChunkDone(entry, msg);
            case "chunk_failed": return this._onChunkFailed(entry, msg);
            case "worker_error": return this._onWorkerError(entry, msg);
            case "worker_done":  return this._onWorkerDone(entry);
            case "worker_log":   return void this._log(`[w${entry.id}] ${msg.text}`);
            default: return;
        }
    }

    _onProgress(entry, msg) {
        const chunk = this.chunks[msg.chunkId];
        if (!chunk || chunk.state !== "claimed") return;
        if (chunk.workerId !== entry.id) return;

        const chunkLength = chunk.end - chunk.start + 1;
        const chunkRelative = msg.fileOffset - chunk.start;
        const clamped = Math.max(0, Math.min(chunkLength, chunkRelative));

        if (clamped > chunk.downloaded) {
            const delta = clamped - chunk.downloaded;
            chunk.downloaded = clamped;
            this.totalDownloaded += delta;
            this._lastGlobalProgressAt = this._monotonicNow();
            chunk.attempts = 0;
            this._throttleCount = 0;
            this._recordSpeedSample();
            this._persistIfDue();
            this._emitProgress();
        }
        chunk.lastActivity = this._monotonicNow();

        if (this.state === STATES.WAITING) this._transition(STATES.DOWNLOADING);
    }

    _onChunkDone(entry, msg) {
        const chunk = this.chunks[msg.chunkId];
        if (!chunk) return;
        if (chunk.workerId !== entry.id && chunk.state === "claimed") return;

        const expected = chunk.end - chunk.start + 1;
        if (chunk.downloaded < expected) {
            this._errorLog(`chunk ${chunk.id} done but short (${chunk.downloaded}/${expected})`);
            return this._handleChunkFailure(entry, chunk, "transient", "Chunk reported done but bytes missing");
        }
        chunk.state = "done";
        chunk.workerId = null;
        chunk.attempts = 0;
        this.finishedChunks.add(chunk.id);
        entry.currentChunkId = null;

        if (this.finishedChunks.size === this.chunks.length) return this._maybeFinalize();
        this._persistIfDue(true);
        this._assignNextChunk(entry);
    }

    _onChunkFailed(entry, msg) {
        const chunk = this.chunks[msg.chunkId];
        if (!chunk) return;
        const code = msg.code || this._classifyMessage(msg.error || "");
        this._handleChunkFailure(entry, chunk, code, msg.error || "Unknown error");
    }

    _handleChunkFailure(entry, chunk, code, errorMessage) {
        if (code === "fatal-disk") {
            chunk.state = "failed";
            chunk.workerId = null;
            if (entry.currentChunkId === chunk.id) entry.currentChunkId = null;
            this._setFirstError(this._safeDiskMessage(errorMessage), code);
            return this._enterFailing();
        }
        if (code === "fatal-link") {
            chunk.state = "failed";
            chunk.workerId = null;
            if (entry.currentChunkId === chunk.id) entry.currentChunkId = null;
            this._setFirstError(this._safeLinkMessage(errorMessage), code);
            return this._enterFailing();
        }
        if (code === "file-changed") {
            chunk.state = "failed";
            chunk.workerId = null;
            if (entry.currentChunkId === chunk.id) entry.currentChunkId = null;
            this._setFirstError("Server file changed during download — restart required", code);
            try { if (fs.existsSync(this.statePath)) fs.unlinkSync(this.statePath); } catch { /* best effort */ }
            return this._enterFailing();
        }

        if (entry.currentChunkId === chunk.id) entry.currentChunkId = null;
        if (chunk.workerId === entry.id) chunk.workerId = null;

        const now = this._monotonicNow();
        this._lastThrottleAt = now;
        this._throttleCount++;

        if (code === "throttled" || this._throttleCount >= 3) {
            const prev = this.activeConcurrency;
            this.activeConcurrency = Math.max(1, Math.floor(this.activeConcurrency / 2));
            if (prev !== this.activeConcurrency) {
                this._log(`${code}: concurrency ${prev} -> ${this.activeConcurrency} (throttle #${this._throttleCount})`);
            }
        }

        chunk.state = "pending";
        chunk.attempts = 0;

        const delay = this._cappedBackoff(this._throttleCount);
        this._log(`${code}: chunk ${chunk.id} retry scheduled in ${Math.round(delay)}ms (throttle #${this._throttleCount})`);

        const timerId = setTimeout(() => {
            this._retryTimers.delete(timerId);
            if (!ACTIVE_STATES.has(this.state)) return;

            if (!this.pendingChunks.includes(chunk.id)) {
                this.pendingChunks.push(chunk.id);
            }
            if (this.state === STATES.WAITING) this._transition(STATES.DOWNLOADING);

            let woken = 0;
            for (const w of this.workers.values()) {
                if (w.alive && w.currentChunkId === null) {
                    this._assignNextChunk(w);
                    woken++;
                }
            }
            this._log(`retry timer fired for chunk ${chunk.id} (woken=${woken}, pending=${this.pendingChunks.length})`);

            this._ensureWorkerCount();
        }, delay);
        if (timerId.unref) timerId.unref();
        this._retryTimers.add(timerId);

        if (entry.alive) {
            this._assignNextChunk(entry);
        }

        if (this._activeWorkerCount() === 0 && this.state === STATES.DOWNLOADING) {
            this._transition(STATES.WAITING);
        }
    }

    _onWorkerError(entry, msg) {
        this._errorLog(`worker ${entry.id} reported error: ${msg.error}`);
        if (!entry.alive) return;
        entry.alive = false;
        this._requeueChunk(entry);
        this.workers.delete(entry.id);
        this._respawnAfterCrash("Download worker crashed");
        this._maybeFinalize();
    }

    _onWorkerDone(entry) {
        entry.alive = false;
        entry.currentChunkId = null;
        this.workers.delete(entry.id);
        this._maybeFinalize();
    }

    _enterFailing() {
        if (this.state === STATES.FAILING) {
            this._armForceKill();
            return;
        }
        if (!ACTIVE_STATES.has(this.state)) return;
        this._transition(STATES.FAILING);
        this._broadcastAbort();
        this._armForceKill();
        this._maybeFinalize();
    }

    _classifyMessage(errorMessage) {
        if (!errorMessage) return "transient";
        if (/ENOSPC|EACCES|ENOENT|EBADF/i.test(errorMessage)) return "fatal-disk";
        if (/HTTP 404|HTTP 410|expired/i.test(errorMessage))   return "fatal-link";
        if (/HTTP 429|HTTP 503/.test(errorMessage))            return "throttled";
        if (/Content-Range|If-Range|HTTP 416/i.test(errorMessage)) return "file-changed";
        return "transient";
    }

    _safeDiskMessage(raw) {
        if (/ENOSPC/i.test(raw)) return "Disk full";
        if (/EACCES/i.test(raw)) return "Permission denied writing file";
        if (/ENOENT/i.test(raw)) return "Temporary file was deleted";
        if (/EBADF/i.test(raw))  return "File handle lost";
        return "Disk error";
    }

    _safeLinkMessage(raw) {
        if (/HTTP 404/i.test(raw)) return "File not found on server";
        if (/HTTP 410/i.test(raw)) return "File no longer available on server";
        if (/HTTP 401|HTTP 403/i.test(raw)) return "Link expired or authentication required";
        return "Link unavailable";
    }

    _safeTransientMessage(raw) {
        if (/timeout|ETIMEDOUT/i.test(raw))     return "Connection timed out";
        if (/ECONNRESET|socket hang up/i.test(raw)) return "Connection reset by server";
        if (/ENOTFOUND|EAI_AGAIN/i.test(raw))   return "DNS lookup failed";
        if (/ECONNREFUSED/i.test(raw))          return "Connection refused";
        return "Network error";
    }

    /* =========================================================
     *  AIMD concurrency growth
     * ========================================================= */
    _scheduleConcurrencyGrowth() {
        if (this._growthTimer) clearTimeout(this._growthTimer);
        this._growthTimer = setTimeout(() => {
            if (!ACTIVE_STATES.has(this.state)) return;
            const sinceThrottle = this._monotonicNow() - this._lastThrottleAt;
            if (sinceThrottle >= THROTTLE_GROWTH_INTERVAL_MS && this.activeConcurrency < this.workersTotal) {
                this.activeConcurrency++;
                this._log(`concurrency grown to ${this.activeConcurrency}`);
                this._ensureWorkerCount();
            }
            this._scheduleConcurrencyGrowth();
        }, THROTTLE_GROWTH_INTERVAL_MS);
        if (this._growthTimer.unref) this._growthTimer.unref();
    }

    /* =========================================================
     *  Watchdog
     * ========================================================= */
    _startWatchdog() {
        this.watchdog = setInterval(() => {
            if (!ACTIVE_STATES.has(this.state)) return;
            const now = this._monotonicNow();
            if (now < this._resumeGraceUntil) return;

            for (const [wid, entry] of Array.from(this.workers)) {
                if (entry.currentChunkId === null) continue;
                const chunk = this.chunks[entry.currentChunkId];
                if (!chunk || chunk.state !== "claimed") continue;
                if (now - (chunk.lastActivity || 0) > STALL_TIMEOUT_MS) {
                    this._errorLog(`chunk ${chunk.id} stalled for >${Math.round(STALL_TIMEOUT_MS / 1000)}s — recovering`);
                    this._recoverWorker(wid);
                }
            }

            if (now - this._lastGlobalProgressAt > NO_PROGRESS_FAIL_MS) {
                this._setFirstError(
                    `No download progress for ${Math.round(NO_PROGRESS_FAIL_MS / 1000)} seconds`,
                    "transient"
                );
                this._enterFailing();
            }
        }, WATCHDOG_INTERVAL_MS);
        if (this.watchdog.unref) this.watchdog.unref();
    }

    async _recoverWorker(wid) {
        const entry = this.workers.get(wid);
        if (!entry) return;

        const stalledChunkId = entry.currentChunkId;
        this.workers.delete(wid);
        entry.alive = false;

        if (stalledChunkId !== null && stalledChunkId !== undefined) {
            const chunk = this.chunks[stalledChunkId];
            if (chunk && chunk.state === "claimed" && chunk.workerId === wid) {
                chunk.attempts = (chunk.attempts || 0) + 1;
                if (chunk.attempts >= MAX_CHUNK_ATTEMPTS && ACTIVE_STATES.has(this.state)) {
                    chunk.state = "failed";
                    this._setFirstError(
                        `Chunk stalled repeatedly — giving up after ${chunk.attempts} stalls`,
                        "transient"
                    );
                    this._requeueChunk(entry);
                    try { await entry.worker.terminate(); } catch { /* dead */ }
                    return this._enterFailing();
                }
            }
        }

        this._requeueChunk(entry);
        try { await entry.worker.terminate(); } catch { /* dead */ }
        if (ACTIVE_STATES.has(this.state)) this._ensureWorkerCount();
        this._maybeFinalize();
    }

    _scheduleWaitingRetry() {
        const backoff = this._cappedBackoff(this._throttleCount);
        if (this._waitTimer) clearTimeout(this._waitTimer);
        this._waitTimer = setTimeout(() => {
            if (this.state !== STATES.WAITING) return;
            this._transition(STATES.DOWNLOADING);
            this._ensureWorkerCount();
        }, backoff);
        if (this._waitTimer.unref) this._waitTimer.unref();
    }

    _cappedBackoff(count) {
        const base = 1000;
        const max = 90000;
        const exp = Math.min(max, base * Math.pow(2, Math.min(count, 6)));
        return exp + Math.random() * base;
    }

    /* =========================================================
     *  Force kill
     * ========================================================= */
    _armForceKill() {
        if (this.forceKillTimer) clearTimeout(this.forceKillTimer);
        this.forceKillTimer = setTimeout(() => {
            this._terminateAllWorkers().finally(() => this._maybeFinalize());
        }, FORCE_KILL_MS);
        if (this.forceKillTimer.unref) this.forceKillTimer.unref();
    }

    _clearForceKill() {
        if (this.forceKillTimer) {
            clearTimeout(this.forceKillTimer);
            this.forceKillTimer = null;
        }
    }

    _clearTimers() {
        if (this.watchdog) { clearInterval(this.watchdog); this.watchdog = null; }
        this._clearForceKill();
        if (this._growthTimer) { clearTimeout(this._growthTimer); this._growthTimer = null; }
        if (this._waitTimer) { clearTimeout(this._waitTimer); this._waitTimer = null; }
        for (const timerId of this._retryTimers) {
            clearTimeout(timerId);
        }
        this._retryTimers.clear();
    }

    /* =========================================================
     *  Persistence
     * ========================================================= */
    _persistIfDue(force = false) {
        const now = this._monotonicNow();
        const interval = this._persistInterval();
        if (!force && now - this._persistAttemptAt < interval) return;
        this._persistAttemptAt = now;
        this._persistChain = this._persistChain
            .then(() => persistState(this))
            .catch((err) => this._errorLog("state persist failed", err));
    }

    async _persistNow() {
        this._persistAttemptAt = this._monotonicNow();
        this._persistChain = this._persistChain
            .then(() => persistState(this))
            .catch((err) => this._errorLog("state persist failed", err));
        await this._persistChain;
    }

    _persistInterval() {
        if (this.chunks.length > 1000) return 5000;
        if (this.chunks.length > 500) return 3000;
        return 1000;
    }

    /* =========================================================
     *  Progress emission
     * ========================================================= */
    _recordSpeedSample() {
        const now = this._monotonicNow();
        this._speedSamples.push({ t: now, bytes: this.totalDownloaded });
        const cutoff = now - 10000;
        while (this._speedSamples.length > 20) this._speedSamples.shift();
        while (this._speedSamples.length > 2 && this._speedSamples[0].t < cutoff) {
            this._speedSamples.shift();
        }
    }

    _computeSpeed() {
        const s = this._speedSamples;
        if (s.length < 2) return 0;
        const dt = (s[s.length - 1].t - s[0].t) / 1000;
        if (dt <= 0) return 0;
        return (s[s.length - 1].bytes - s[0].bytes) / dt;
    }

    _emitProgress() {
        const now = this._monotonicNow();
        if (now - this._lastProgressEmitAt < PROGRESS_THROTTLE_MS) return;
        this._lastProgressEmitAt = now;

        const speedBps = this._computeSpeed();
        let percent = this.totalSize > 0 ? (this.totalDownloaded / this.totalSize) * 100 : 0;
        if (percent > 100) percent = 100;
        if (percent >= 100 && this.finishedChunks.size < this.chunks.length) percent = 99.9;

        const remaining = Math.max(0, this.totalSize - this.totalDownloaded);
        const etaSeconds = speedBps > 0 ? Math.round(remaining / speedBps) : 0;

        const payload = {
            id: this.id,
            percent: percent.toFixed(1),
            speedMBps: (speedBps / MB).toFixed(2),
            etaSeconds,
            downloaded: this.totalDownloaded,
            totalSize: this.totalSize,
        };
        try { this.emit("progress", payload); } catch (err) {
            this._errorLog("progress listener threw", err);
        }
    }

    /* =========================================================
     *  Finalization
     * ========================================================= */
    _maybeFinalize() {
        if (this._finalized) return;
        if (this._finalizePromise) return this._finalizePromise;

        if (this.chunks.length === 0) {
            return this._beginFinalize("success");
        }
        if (this.finishedChunks.size === this.chunks.length) {
            return this._beginFinalize("success");
        }
        if (this._activeWorkerCount() > 0) return;

        if (this.state === STATES.PAUSING)    return this._beginFinalize("pause");
        if (this.state === STATES.CANCELLING) return this._beginFinalize("cancel");
        if (this.state === STATES.FAILING)    return this._beginFinalize("failure");

        if (this._retryTimers.size > 0) return;

        if (ACTIVE_STATES.has(this.state)) {
            if (this.pendingChunks.length > 0 && this._workerRespawns < MAX_WORKER_RESPAWNS) {
                this._tryRespawnWorker();
                if (this._activeWorkerCount() > 0) return;
            }
            this._setFirstError(
                this.firstError || "All workers stopped before chunks were complete",
                this.firstErrorCode || "transient"
            );
            if (this.state !== STATES.FAILING) this._transition(STATES.FAILING);
            return this._beginFinalize("failure");
        }
        return;
    }

    _beginFinalize(kind) {
        if (this._finalizePromise) return this._finalizePromise;
        this._finalizePromise = Promise.race([
            this._runFinalizer(kind),
            new Promise((_, reject) =>
                setTimeout(() => reject(new Error("Finalization timeout")), FINALIZE_TIMEOUT_MS).unref()
            ),
        ]).catch((err) => {
            this._errorLog("finalization threw", err);
            this._completeFinalize({
                success: false,
                error: "Finalization failed: " + err.message,
                retryable: true,
            });
        });
        return this._finalizePromise;
    }

    async _runFinalizer(kind) {
        this._clearTimers();
        await this._terminateAllWorkers();
        if (kind === "success") return this._finalizeSuccess();
        if (kind === "pause")   return this._finalizePause();
        if (kind === "cancel")  return this._finalizeCancel();
        if (kind === "failure") return this._finalizeFailure();
    }

    async _finalizeSuccess() {
        if (this._finalized) return;
        if (this.state !== STATES.FINALIZING) this._transition(STATES.FINALIZING);

        let finalPath = this.filePath;
        let renameError = null;

        try {
            const stat = await fsp.stat(this.tempFilePath);
            if (stat.size !== this.totalSize) {
                throw new Error(`Temp file size mismatch: ${stat.size} != ${this.totalSize}`);
            }
            if (fs.existsSync(finalPath)) {
                finalPath = uniquePath(path.dirname(finalPath), path.basename(finalPath));
                this._log(`target existed, using ${finalPath}`);
            }
            await renameWithRetry(this.tempFilePath, finalPath);
        } catch (err) {
            renameError = err;
        }

        if (!renameError) {
            try {
                if (fs.existsSync(this.statePath)) await fsp.unlink(this.statePath);
            } catch (err) {
                this._errorLog("state unlink failed", err);
            }

            try {
                const filename = path.basename(finalPath);
                const category = getFileCategory(filename);
                const saveDir = this.validators.saveDirectory || path.dirname(finalPath);
                const categoryDir = path.join(saveDir, category);
                await fsp.mkdir(categoryDir, { recursive: true });

                let sortedPath = path.join(categoryDir, filename);
                if (fs.existsSync(sortedPath)) {
                    const ext = path.extname(filename);
                    const base = path.basename(filename, ext);
                    for (let i = 1; i < 1000; i++) {
                        const candidate = path.join(categoryDir, `${base} (${i})${ext}`);
                        if (!fs.existsSync(candidate)) {
                            sortedPath = candidate;
                            break;
                        }
                    }
                }
                await renameWithRetry(finalPath, sortedPath);
                this._log(`auto-sorted to ${category}/${path.basename(sortedPath)}`);
                finalPath = sortedPath;
            } catch (err) {
                this._errorLog("auto-sort failed — file stays in original location", err);
            }

            try {
                let hostUrl = null;
                try { hostUrl = new URL(this.validators.finalUrl || this.url).hostname; } catch { /* bad URL */ }
                stampMarkOfTheWeb(finalPath, {
                    hostUrl,
                    referrerUrl: this.validators.finalUrl || null,
                });
            } catch (err) {
                this._errorLog("MOTW stamp failed", err);
            }
        }

        this.filePath = finalPath;
        if (renameError) {
            this._completeFinalize({
                success: false,
                error: "Finalization failed: " + renameError.message,
                retryable: true,
            });
        } else {
            this._completeFinalize({ success: true, filePath: finalPath });
        }
    }

    async _finalizePause() {
        if (this._finalized) return;
        if (this.state === STATES.CANCELLING) return this._finalizeCancel();
        await this._persistNow();
        this._completeFinalize({ success: false, paused: true });
    }

    async _finalizeCancel() {
        if (this._finalized) return;
        this._completeFinalize({ success: false, cancelled: true });
    }

    async _finalizeFailure() {
        if (this._finalized) return;
        await this._persistNow();
        this._completeFinalize({
            success: false,
            error: this.firstError || "Download failed",
            code: this.firstErrorCode || null,
        });
    }

    _completeFinalize(result) {
        if (this._finalized) return;
        this._finalized = true;
        const prevState = this.state;
        this.state = STATES.FINALIZED;
        if (prevState !== STATES.FINALIZED) {
            try { this.emit("state-change", prevState, STATES.FINALIZED); } catch { /* listener threw */ }
        }

        this._resolveRun?.(result);
        if (result.success) {
            this._resolvePause?.({ success: false, error: "Download completed" });
            this._resolveCancel?.({ success: false, error: "Download completed" });
        } else if (result.paused) {
            this._resolvePause?.({ success: true });
            this._resolveCancel?.({ success: false, error: "Paused instead of cancelled" });
        } else if (result.cancelled) {
            this._resolveCancel?.({ success: true });
            this._resolvePause?.({ success: false, error: "Cancelled instead of paused" });
        } else {
            this._resolvePause?.({ success: false, error: result.error });
            this._resolveCancel?.({ success: false, error: result.error });
        }
        this._resolveRun = null;
        this._resolvePause = null;
        this._resolveCancel = null;
        try { this.emit("finalized", result); } catch { /* listener threw */ }
    }
}

module.exports = { DownloadTask, STATES, TRANSITIONS, getFileCategory };