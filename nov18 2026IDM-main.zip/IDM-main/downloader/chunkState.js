/* ================================================================
 *  Flow — chunk sizing, layout, validation, persistence
 * ================================================================ */

const crypto = require("crypto");

const {
  STATE_VERSION,
  MIN_CHUNK_SIZE,
  MAX_CHUNK_SIZE,
  CHUNKS_PER_WORKER,
  MAX_THREADS,
  MB,
  GB,
} = require("./config");

const { atomicWriteJson } = require("./utils");

function hashUrl(url) {
  return crypto.createHash("sha256").update(String(url)).digest("hex");
}

/* ---------------- Adaptive sizing (unchanged) ---------------- */
function computeWorkerCount(totalSize) {
  let desired;
  if (totalSize < 10 * MB)       desired = 2;
  else if (totalSize < 100 * MB) desired = 4;
  else if (totalSize < 500 * MB) desired = 8;
  else if (totalSize < 2 * GB)   desired = 12;
  else if (totalSize < 5 * GB)   desired = 16;
  else                           desired = MAX_THREADS;

  const maxBySize = Math.max(1, Math.floor(totalSize / (2 * MB)));
  return Math.max(1, Math.min(desired, maxBySize, MAX_THREADS));
}

function computeChunkSize(totalSize, workers) {
  const targetChunks = Math.max(1, workers * CHUNKS_PER_WORKER);
  const ideal = totalSize / targetChunks;
  return Math.max(
    MIN_CHUNK_SIZE,
    Math.min(MAX_CHUNK_SIZE, Math.ceil(ideal))
  );
}

/* ---------------- Layout (unchanged) ---------------- */
function buildChunkLayout(totalSize, chunkSize) {
  const chunks = [];
  let start = 0;
  let id = 0;
  while (start < totalSize) {
    const end = Math.min(start + chunkSize - 1, totalSize - 1);
    chunks.push({
      id,
      start,
      end,
      downloaded: 0,
      state: "pending",
      workerId: null,
      attempts: 0,
      lastActivity: 0,
    });
    start = end + 1;
    id++;
  }
  return chunks;
}

/* ---------------- Validation ---------------- */
function isValidState(state, totalSize) {
  if (!state || typeof state !== "object") return false;
  if (state.version !== STATE_VERSION) return false;
  if (state.totalSize !== totalSize) return false;
  if (!Array.isArray(state.chunks) || state.chunks.length === 0) return false;

  let expectedStart = 0;
  for (let i = 0; i < state.chunks.length; i++) {
    const c = state.chunks[i];
    if (!c || typeof c !== "object") return false;
    if (c.id !== i) return false;
    if (!Number.isInteger(c.start) || !Number.isInteger(c.end) || !Number.isInteger(c.downloaded)) {
      return false;
    }
    if (c.start !== expectedStart) return false;
    if (c.end < c.start) return false;
    if (c.downloaded < 0 || c.downloaded > c.end - c.start + 1) return false;
    expectedStart = c.end + 1;
  }
  if (expectedStart !== totalSize) return false;
  return true;
}

/* ---------------- Persist ---------------- */
function persistState(task) {
  try {
    atomicWriteJson(task.statePath, {
      version: STATE_VERSION,
      urlHash: hashUrl(task.url),
      totalSize: task.totalSize,
      chunkSize: task.chunkSize,
      etag: task.validators?.etag || null,
      lastModified: task.validators?.lastModified || null,
      validator: task.validators?.validator || null,
      contentType: task.validators?.contentType || null,
      chunks: task.chunks.map((c) => ({
        id: c.id,
        start: c.start,
        end: c.end,
        downloaded: c.downloaded,
      })),
    });
    task.lastSave = Date.now();
  } catch (err) {
    console.error("[downloadManager] state write failed:", err.message);
  }
}

module.exports = {
  computeWorkerCount,
  computeChunkSize,
  buildChunkLayout,
  isValidState,
  persistState,
  hashUrl,
};