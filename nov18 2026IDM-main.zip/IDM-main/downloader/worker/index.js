/* ================================================================
 *  Flow — download worker (entry point)
 *
 *  Message loop + abort handling. Delegates the actual work to:
 *    state.js     — workerData + mutable state + post/log/sleep
 *    h2.js        — HTTP/2 session management (unused; kept until
 *                   Phase 5 cleanup)
 *    h1.js        — HTTPS/HTTP fallback
 *    transport.js — openStream dispatcher + validateResponse
 *    range.js     — downloadRange (pipeline + limiter + progress)
 *    chunk.js     — downloadChunk (retry loop)
 * ================================================================ */

const { parentPort } = require("worker_threads");

const { state, post, log } = require("./state");
const { closeH2 } = require("./h2");
const { downloadChunk } = require("./chunk");

/* ---------------- Message loop ---------------- */
parentPort.on("message", async (msg) => {
  if (!msg) return;

  if (msg.type === "abort") {
    state.isShuttingDown = true;
    // Kill any in-flight write so pipeline unwinds immediately.
    try { if (state.currentWriteStream) state.currentWriteStream.destroy(); } catch {}
    // If between chunks, exit now so the main process can finalize
    // pause/cancel without waiting for its hard-kill timer.
    if (!state.currentWriteStream) {
      closeH2();
      process.exit(0);
    }
    return;
  }

  if (msg.type === "chunk") {
    try {
      await downloadChunk(msg.chunk);
      post({ type: "chunk_done", chunkId: msg.chunk.id });
    } catch (err) {
      if (err.message === "aborted" || state.isShuttingDown) {
        // Silent exit — main process is closing us down.
        closeH2();
        process.exit(0);
      }
      post({
        type: "chunk_failed",
        chunkId: msg.chunk.id,
        error: err.message || String(err),
        code: err.code || "transient",
      });
    }
    return;
  }

  if (msg.type === "no_more_chunks") {
    closeH2();
    post({ type: "worker_done" });
    setImmediate(() => process.exit(0));
    return;
  }
});

/* ---------------- Safety: uncaught exceptions ---------------- */
process.on("uncaughtException", (err) => {
  log(`uncaught exception: ${err.message}`);
  post({ type: "worker_error", error: err.message });
  process.exit(1);
});