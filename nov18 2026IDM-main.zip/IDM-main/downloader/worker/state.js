/* ================================================================
 *  Flow — worker state
 *
 *  Single place that unpacks workerData and holds mutable per-thread
 *  state (currentWriteStream, isShuttingDown) plus IPC helpers.
 *
 *  ifRange / probeContentType / totalSize are required for change
 *  detection and response validation in transport.js. totalSize is
 *  validated here so a malformed spawn fails loudly instead of
 *  silently disabling checks inside a request.
 * ================================================================ */

const { workerData, parentPort } = require("worker_threads");

const {
  url,
  headers: extraHeaders = {},
  tempFilePath,
  workerId,
  maxAttempts = 3,
  ifRange = null,
  probeContentType = null,
  totalSize,
} = workerData;

if (!Number.isInteger(totalSize) || totalSize < 0) {
  throw new Error("worker: workerData.totalSize is required (non-negative integer)");
}

const state = {
  // Immutable config from main thread
  url,
  extraHeaders,
  tempFilePath,
  workerId,
  maxAttempts,
  ifRange,
  probeContentType,
  totalSize,

  // Mutable runtime state
  currentWriteStream: null,
  isShuttingDown: false,
};

function post(msg) { parentPort.postMessage(msg); }
function log(text) { post({ type: "worker_log", text }); }
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

module.exports = { state, post, log, sleep };