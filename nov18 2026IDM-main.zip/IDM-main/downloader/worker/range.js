/* ================================================================
 *  Flow — single range download
 *
 *  Streams one byte-range from the server directly into the temp file
 *  at the right offset, capping writes to the requested length and
 *  reporting incremental progress as an ABSOLUTE FILE OFFSET high-water
 *  mark (not a delta). On failure, the throw carries .bytesWritten so
 *  the caller can advance without double-counting.
 *
 *  When transport.js marks a response as `fullResponse` (server
 *  returned 200 for a ranged request), a byte-skipping Transform is
 *  inserted before the limiter. This consumes and discards the first
 *  `start` bytes of the full-file stream, then writes only the bytes
 *  belonging to this chunk. Correct output, no restart needed.
 * ================================================================ */

const fs = require("fs");
const { pipeline } = require("stream/promises");
const { Transform } = require("stream");

const { PROGRESS_INTERVAL_MS, WRITE_BUFFER_BYTES } = require("./config");
const { state, post } = require("./state");
const { openStream, validateResponse } = require("./transport");

/**
 * Returns a Transform that discards the first `skip` bytes of its
 * input and passes the rest through unchanged.
 */
function createSkipTransform(skip) {
  let skipped = 0;
  return new Transform({
    transform(chunk, _enc, cb) {
      if (skipped >= skip) return cb(null, chunk);
      const need = skip - skipped;
      if (chunk.length <= need) {
        skipped += chunk.length;
        return cb(); // entirely discarded
      }
      skipped += need;
      cb(null, chunk.slice(need));
    },
  });
}

async function downloadRange(start, end, chunkId) {
  const remaining = end - start + 1;
  if (remaining <= 0) return 0;

  const resp = await openStream(start, end);
  try {
    validateResponse(resp, start, remaining);
  } catch (err) {
    try { resp.stream.destroy(); } catch {}
    throw err;
  }

  /* ---- Build the transform pipeline ---- */
  const transforms = [];

  if (resp.fullResponse && start > 0) {
    // Server returned the whole file. Discard the leading `start` bytes
    // so the limiter only sees bytes that belong to this chunk.
    transforms.push(createSkipTransform(start));
  }

  // Byte-limiting transform: refuse to write more than `remaining` bytes
  let passed = 0;
  const limiter = new Transform({
    transform(chunk, _enc, cb) {
      const space = remaining - passed;
      if (space <= 0) return cb();
      if (chunk.length <= space) {
        passed += chunk.length;
        return cb(null, chunk);
      }
      passed += space;
      cb(null, chunk.slice(0, space));
    },
  });
  transforms.push(limiter);

  const ws = fs.createWriteStream(state.tempFilePath, {
    flags: "r+",
    start,
    highWaterMark: WRITE_BUFFER_BYTES,
  });

  state.currentWriteStream = ws;

  // Report ABSOLUTE file offset high-water. Main uses max(), so double
  // posting the same offset is harmless; delta double-counting is not.
  let lastReported = -1;
  const report = () => {
    const hw = start + ws.bytesWritten;
    if (hw > lastReported) {
      lastReported = hw;
      post({ type: "progress", chunkId, fileOffset: hw });
    }
  };

  const progressTimer = setInterval(report, PROGRESS_INTERVAL_MS);

  try {
    await pipeline(resp.stream, ...transforms, ws);
    report();
    return ws.bytesWritten;
  } catch (err) {
    report();
    // Attach partial-write count so chunk.js can advance `downloaded`
    // without re-fetching bytes that are already on disk.
    err.bytesWritten = ws.bytesWritten;
    throw err;
  } finally {
    clearInterval(progressTimer);
    state.currentWriteStream = null;
  }
}

module.exports = { downloadRange };