/* ================================================================
 *  Flow — HTTP/1.1 keep-alive agents (shared across requests)
 * ================================================================ */

const https = require("https");
const http = require("http");

const httpsAgent = new https.Agent({
  keepAlive: true,
  keepAliveMsecs: 30000,
  maxSockets: 16,
  maxFreeSockets: 4,
});

const httpAgent = new http.Agent({
  keepAlive: true,
  keepAliveMsecs: 30000,
  maxSockets: 16,
  maxFreeSockets: 4,
});

module.exports = { httpsAgent, httpAgent };