/* ================================================================
 *  Flow — transport dispatcher
 *
 *  HTTP/1.1 only. Validates that a 206 response's Content-Range matches
 *  the request, that Content-Encoding is identity, that Content-Length
 *  matches the requested length.
 *
 *  For 200 responses:
 *    - If this is a full-file request (start=0, expectedBytes=totalSize)
 *      → accepted as a normal non-resumable single-stream download.
 *    - If the server returned 200 for a ranged request (start > 0 or
 *      expectedBytes < totalSize) → marks the response with
 *      `resp.fullResponse = true`. The caller (range.js) will skip the
 *      leading `start` bytes and write the correct slice. This prevents
 *      the CoolROM-style permanent pause when a server ignores Range.
 *
 *  Every throw carries a typed err.code that chunk.js uses for
 *  classification: fatal-disk | fatal-link | file-changed | throttled
 *  | transient. For throttled errors, err.retryAfter carries the
 *  Retry-After header value in seconds when present.
 * ================================================================ */

const { openHttpsStream } = require("./h1");
const { state } = require("./state");

async function openStream(start, end) {
  return openHttpsStream(state.url, state.extraHeaders, start, end, state.ifRange);
}

function typedError(message, code, extra = {}) {
  const err = new Error(message);
  err.code = code;
  for (const k of Object.keys(extra)) {
    if (extra[k] !== undefined) err[k] = extra[k];
  }
  return err;
}

function validateResponse(resp, start, expectedBytes) {
  /* ---- Fatal HTTP statuses ---- */
  if (resp.status === 401 || resp.status === 403) {
    throw typedError(`HTTP ${resp.status} — link expired or auth required`, "fatal-link", { status: resp.status });
  }
  if (resp.status === 404) {
    throw typedError("HTTP 404 — file not found", "fatal-link", { status: 404 });
  }
  if (resp.status === 410) {
    throw typedError("HTTP 410 — file no longer available", "fatal-link", { status: 410 });
  }
  if (resp.status === 416) {
    throw typedError("HTTP 416 — range not satisfiable", "file-changed", { status: 416 });
  }
  if (resp.status === 429) {
    const retryAfter = resp.headers["retry-after"] ? Number(resp.headers["retry-after"]) : null;
    throw typedError("HTTP 429 — server is rate-limiting this link", "throttled", {
      status: 429,
      retryAfter: Number.isFinite(retryAfter) ? retryAfter : null,
    });
  }
  if (resp.status >= 500) {
    const retryAfter = resp.headers["retry-after"] ? Number(resp.headers["retry-after"]) : null;
    throw typedError(`HTTP ${resp.status} — server error`, resp.status === 503 ? "throttled" : "transient", {
      status: resp.status,
      retryAfter: Number.isFinite(retryAfter) ? retryAfter : null,
    });
  }
  if (resp.status !== 200 && resp.status !== 206) {
    throw typedError(`Unexpected HTTP ${resp.status}`, "transient", { status: resp.status });
  }

  /* ---- Content-Encoding must be identity (we sent identity) ---- */
  const ce = String(resp.headers["content-encoding"] || "identity").toLowerCase();
  if (ce !== "identity") {
    throw typedError(`Unexpected Content-Encoding: ${ce}`, "transient");
  }

  /* ================================================================
   *  200 OK — server ignored Range or this is a full-file request
   * ================================================================ */
  if (resp.status === 200) {
    const isFullFileRequest = (start === 0 && expectedBytes === state.totalSize);

    if (isFullFileRequest) {
      // Normal non-resumable single-stream download: the whole file is
      // the requested range. Validate Content-Length against totalSize.
      const cl = resp.headers["content-length"];
      if (cl !== undefined) {
        const clNum = parseInt(cl, 10);
        if (Number.isFinite(clNum) && clNum !== expectedBytes) {
          throw typedError(`Content-Length ${clNum} != expected ${expectedBytes}`, "transient");
        }
      }
      return; // Valid — no Content-Range to check
    }

    // Server returned the whole file for a ranged request. Accept it
    // and mark the response so range.js can skip `start` bytes and
    // write only the chunk slice. This is the graceful fallback for
    // servers that ignore Range headers (CoolROM-style).
    const cl = resp.headers["content-length"];
    if (cl !== undefined) {
      const clNum = parseInt(cl, 10);
      if (Number.isFinite(clNum) && Number.isFinite(state.totalSize) && state.totalSize > 0 && clNum !== state.totalSize) {
        // Server says the full file is a different size than we probed.
        // Could be a genuine file change or a misbehaving server.
        throw typedError(`Full-response Content-Length ${clNum} != probed totalSize ${state.totalSize}`, "transient");
      }
    }
    resp.fullResponse = true;
    return; // Skip Content-Range validation — there is none in a 200
  }

  /* ================================================================
   *  206 Partial Content — validate the range matches our request
   * ================================================================ */
  const cr = String(resp.headers["content-range"] || "");
  const m = cr.match(/bytes\s+(\d+)-(\d+)\/(\d+)/i);
  if (!m) throw typedError("HTTP 206 without valid Content-Range", "transient", { status: 206 });
  const crStart = parseInt(m[1], 10);
  const crEnd = parseInt(m[2], 10);
  const crTotal = parseInt(m[3], 10);
  if (crStart !== start) {
    throw typedError(`Content-Range start ${crStart} != requested ${start}`, "file-changed", { status: 206 });
  }
  const expectedEnd = start + expectedBytes - 1;
  if (crEnd !== expectedEnd) {
    throw typedError(`Content-Range end ${crEnd} != requested ${expectedEnd}`, "file-changed", { status: 206 });
  }
  if (Number.isFinite(state.totalSize) && state.totalSize > 0 && crTotal !== state.totalSize) {
    throw typedError(`Content-Range total ${crTotal} != probed ${state.totalSize}`, "file-changed", { status: 206 });
  }

  /* ---- Content-Length must match the requested range length ---- */
  const cl = resp.headers["content-length"];
  if (cl !== undefined) {
    const clNum = parseInt(cl, 10);
    if (Number.isFinite(clNum) && clNum !== expectedBytes) {
      throw typedError(`Content-Length ${clNum} != expected ${expectedBytes}`, "transient");
    }
  }

  /* ---- HTML guard: reject only if probe saw a non-HTML content type ---- */
  const ct = String(resp.headers["content-type"] || "").toLowerCase();
  const probeCt = String(state.probeContentType || "").toLowerCase();
  if (ct.includes("text/html") && !probeCt.includes("text/html") && expectedBytes > 100 * 1024) {
    throw typedError("Server returned HTML error page", "transient");
  }
}

module.exports = { openStream, validateResponse };