/* ================================================================
 *  Flow — HTTP/2 transport
 *
 *  Lazily establishes one session per worker. Once we learn the origin
 *  doesn't speak h2 (`Protocol error` etc.), we set h2Status to
 *  "unsupported" and never try again for this worker's lifetime.
 * ================================================================ */

const http2 = require("http2");
const { H2_CONNECT_TIMEOUT_MS, USER_AGENT } = require("./config");
const { state, log } = require("./state");

let h2Session = null;
let h2Status = "unknown";   // "unknown" | "ok" | "unsupported"

function isH2Usable() { return h2Status !== "unsupported"; }
function markH2Unsupported() { h2Status = "unsupported"; }

function closeH2() {
  try { if (h2Session) h2Session.close(); } catch {}
  h2Session = null;
}

async function tryGetH2Session() {
  if (h2Status === "unsupported") return null;
  if (h2Session && !h2Session.closed && !h2Session.destroyed) return h2Session;

  const origin = new URL(state.url).origin;

  return new Promise((resolve, reject) => {
    let session;
    try {
      session = http2.connect(origin);
    } catch (err) {
      h2Status = "unsupported";
      return reject(err);
    }

    const timer = setTimeout(() => {
      try { session.destroy(); } catch {}
      h2Status = "unsupported";
      reject(new Error("HTTP/2 connect timeout"));
    }, H2_CONNECT_TIMEOUT_MS);

    session.once("connect", () => {
      clearTimeout(timer);
      h2Session = session;
      h2Status = "ok";
      log("HTTP/2 session established");
      resolve(session);
    });

    session.once("error", (err) => {
      clearTimeout(timer);
      h2Status = "unsupported";
      try { session.destroy(); } catch {}
      reject(err);
    });

    session.once("close", () => {
      if (h2Session === session) h2Session = null;
    });
  });
}

function openH2Stream(session, start, end) {
  return new Promise((resolve, reject) => {
    const u = new URL(state.url);

    const reqHeaders = {
      ":method": "GET",
      ":path": u.pathname + u.search,
      ":authority": u.host,
      ":scheme": "https",
      "range": `bytes=${start}-${end}`,
      "accept-encoding": "identity",
      "user-agent": USER_AGENT,
    };
    for (const k of Object.keys(state.extraHeaders)) {
      reqHeaders[k.toLowerCase()] = state.extraHeaders[k];
    }

    let req;
    try {
      req = session.request(reqHeaders);
    } catch (err) {
      return reject(err);
    }

    let responded = false;

    req.once("response", (h) => {
      responded = true;
      resolve({
        status: parseInt(h[":status"], 10),
        headers: h,
        stream: req,
      });
    });

    req.once("error", (err) => {
      if (!responded) reject(err);
    });

    req.end();
  });
}

module.exports = {
  tryGetH2Session,
  openH2Stream,
  isH2Usable,
  markH2Unsupported,
  closeH2,
};