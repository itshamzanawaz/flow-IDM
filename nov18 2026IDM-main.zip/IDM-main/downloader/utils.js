/* ================================================================
 *  Flow — filename / path / fs helpers
 * ================================================================ */

const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");

/* ---------------- Filenames ---------------- */
function safeFilename(name) {
  if (!name || typeof name !== "string") return "download.bin";
  let n = name
    .replace(/[\x00-\x1f\x7f]/g, "")
    .replace(/[\\/:*?"<>|]/g, "_")
    .replace(/^[\s.]+|[\s.]+$/g, "");
  const base = n.split(".")[0].toUpperCase();
  const reserved = [
    "CON","PRN","AUX","NUL",
    "COM1","COM2","COM3","COM4","COM5","COM6","COM7","COM8","COM9",
    "LPT1","LPT2","LPT3","LPT4","LPT5","LPT6","LPT7","LPT8","LPT9",
  ];
  if (reserved.includes(base)) n = "_" + n;
  if (n.length > 200) {
    const ext = path.extname(n).slice(0, 20);
    n = n.slice(0, 200 - ext.length) + ext;
  }
  return n || "download.bin";
}

function parseFilename(disposition, finalUrl) {
  if (disposition && typeof disposition === "string") {
    const rfc = disposition.match(/filename\*\s*=\s*([^']+)'[^']*'([^;]+)/i);
    if (rfc) {
      try { return safeFilename(decodeURIComponent(rfc[2].trim())); } catch {}
    }
    const plain = disposition.match(/filename\s*=\s*(?:"([^"]*)"|([^;]+))/i);
    if (plain) {
      const val = (plain[1] || plain[2] || "").trim();
      if (val) return safeFilename(val);
    }
  }
  try {
    const u = new URL(finalUrl);
    const base = path.basename(u.pathname);
    if (base) return safeFilename(decodeURIComponent(base));
  } catch {}
  return "download.bin";
}

function uniquePath(dir, filename) {
  const full = path.join(dir, filename);
  const exists = (p) => fs.existsSync(p) || fs.existsSync(p + ".fastdl");
  if (!exists(full)) return full;

  const ext = path.extname(filename);
  const base = filename.slice(0, filename.length - ext.length);
  for (let i = 1; i < 1000; i++) {
    const candidate = path.join(dir, `${base} (${i})${ext}`);
    if (!exists(candidate)) return candidate;
  }
  return path.join(dir, `${base}-${Date.now()}${ext}`);
}

/* ---------------- Rename (cross-device safe) ---------------- */
async function renameCrossDevice(oldPath, newPath) {
  try {
    await fsp.rename(oldPath, newPath);
    return;
  } catch (err) {
    if (err.code !== "EXDEV") throw err;
  }
  await fsp.copyFile(oldPath, newPath);
  try { await fsp.unlink(oldPath); } catch {}
}

async function renameWithRetry(oldPath, newPath, retries = 5) {
  let lastErr = null;
  for (let i = 0; i < retries; i++) {
    try {
      await renameCrossDevice(oldPath, newPath);
      return;
    } catch (err) {
      lastErr = err;
      await new Promise((r) => setTimeout(r, 400 * (i + 1)));
    }
  }
  throw lastErr;
}

/* ---------------- Atomic JSON write ---------------- */
function atomicWriteJson(filePath, obj) {
  const tmp = filePath + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(obj));
  fs.renameSync(tmp, filePath);
}

module.exports = {
  safeFilename,
  parseFilename,
  uniquePath,
  renameCrossDevice,
  renameWithRetry,
  atomicWriteJson,
};