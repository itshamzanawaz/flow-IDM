/* ================================================================
 *  Flow — Mark-of-the-Web / quarantine stamping
 *
 *  Best-effort: any failure is logged and swallowed. Downloads must
 *  never fail because a platform attribute could not be written.
 * ================================================================ */

const fs = require("fs");
const { execFileSync } = require("child_process");

function stampMarkOfTheWeb(filePath, { hostUrl, referrerUrl } = {}) {
    try {
        if (process.platform === "win32") {
            const lines = ["[ZoneTransfer]", "ZoneId=3"];
            if (hostUrl) lines.push(`HostUrl=${hostUrl}`);
            if (referrerUrl) lines.push(`ReferrerUrl=${referrerUrl}`);
            const adsPath = filePath + ":Zone.Identifier";
            fs.writeFileSync(adsPath, lines.join("\r\n"), "utf8");
        } else if (process.platform === "darwin") {
            const flags = "0083";
            const ts = Math.floor(Date.now() / 1000).toString(16);
            const origin = String(hostUrl || "").replace(/[;\r\n]/g, "_");
            const value = `${flags};${ts};Flow;${origin}`;
            execFileSync("xattr", ["-w", "com.apple.quarantine", value, filePath], { stdio: "ignore" });
        }
        /* Linux: no standard equivalent. No-op. */
    } catch (err) {
        console.warn("[motw] failed to stamp:", err.message);
    }
}

module.exports = { stampMarkOfTheWeb };