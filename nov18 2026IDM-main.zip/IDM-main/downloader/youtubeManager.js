const youtubedl = require('youtube-dl-exec');
const path = require('path');

const activeYoutubeTasks = new Map();

// downloader/youtubeManager.js
async function prepareYoutubeDownload(url, saveDirectory) {
  try {
    const info = await youtubedl(url, {
      dumpJson: true,
      noCheckCertificates: true,
      noWarnings: true,
      preferFreeFormats: true,
      noPlaylist: true, // <-- Prevents infinite metadata fetching on playlists
      socketTimeout: 30, 
    });

    const safeTitle = (info.title || "YouTube_Video").replace(/[\/\\?%*:|"<>]/g, '-');
    const fileName = `${safeTitle}.mp4`;
    const filePath = path.join(saveDirectory, fileName);
    const totalSize = info.filesize_approx || info.filesize || 0;

    return { fileName, filePath, totalSize };
  } catch (err) {
    console.error("YT-DLP Error:", err.message || err);
    throw new Error("YouTube metadata fetch failed. Check your internet or URL.");
  }
}

function startYoutubeTask(id, url, filePath, sender) {
  return new Promise((resolve, reject) => {
    // Spawns the yt-dlp process
    const dlProcess = youtubedl.exec(url, {
      format: 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
      output: filePath,
      mergeOutputFormat: 'mp4',
      noWarnings: true,
      noPlaylist: true, // <-- Ensures only one file is downloaded
    });

    activeYoutubeTasks.set(id, dlProcess);

    // Catch the unhandled promise rejection to prevent Node from crashing
    dlProcess.catch((err) => {
      console.error(`yt-dlp process rejected for ID ${id}`);
    });

    // Parse stdout for progress tracking
    dlProcess.stdout.on('data', (data) => {
      const text = data.toString();
      
      // Example output: [download]  45.0% of ~50.00MiB at  2.00MiB/s ETA 00:15
      const progressMatch = text.match(/\[download\]\s+([\d.]+)%/);
      const speedMatch = text.match(/at\s+([\d.]+)([a-zA-Z]+\/s)/);
      const etaMatch = text.match(/ETA\s+([\d:]+)/);

      if (progressMatch) {
        let percent = parseFloat(progressMatch[1]);
        
        // Lazy Progress: Hold at 99.9% while FFmpeg merges the audio and video
        if (percent >= 100) percent = 99.9;
        
        let speedMBps = 0;
        if (speedMatch) {
           const speedValue = parseFloat(speedMatch[1]);
           const speedUnit = speedMatch[2].toLowerCase();
           if (speedUnit.includes('k')) speedMBps = (speedValue / 1024).toFixed(2);
           else if (speedUnit.includes('g')) speedMBps = (speedValue * 1024).toFixed(2);
           else speedMBps = speedValue.toFixed(2); // Defaults to MiB/s
        }

        let etaSeconds = 0;
        if (etaMatch) {
          const parts = etaMatch[1].split(':').map(Number);
          if (parts.length === 3) etaSeconds = parts[0] * 3600 + parts[1] * 60 + parts[2];
          else if (parts.length === 2) etaSeconds = parts[0] * 60 + parts[1];
        }

        if (sender) {
          sender.send("download-progress", { id, percent, speedMBps, etaSeconds });
        }
      }
    });

    // Parse stderr for FFmpeg errors and log ALL errors to the terminal
    dlProcess.stderr.on('data', (data) => {
      const text = data.toString();
      
      // Print the exact error from yt-dlp to your console
      console.error(`[YT-DLP ERROR]: ${text.trim()}`); 

      const lowerText = text.toLowerCase();
      if (lowerText.includes('ffmpeg not found') || lowerText.includes('ffprobe not found')) {
        reject(new Error("FFmpeg is missing. Required on system PATH to merge video and audio."));
      }
    });

    dlProcess.on('close', (code) => {
      activeYoutubeTasks.delete(id);
      if (code === 0) {
        // Push the true 100% right before resolving
        if (sender) sender.send("download-progress", { id, percent: 100, speedMBps: 0, etaSeconds: 0 });
        resolve({ success: true, filePath });
      } else {
        // Now it safely rejects and tells the UI there was an error
        reject(new Error(`yt-dlp failed (Code ${code}). Check terminal logs.`));
      }
    });
  });
}

function pauseYoutubeTask(id) {
  const task = activeYoutubeTasks.get(id);
  if (task) {
    task.kill('SIGINT'); // Gracefully kill yt-dlp, allows resuming later
    activeYoutubeTasks.delete(id);
  }
}

module.exports = { prepareYoutubeDownload, startYoutubeTask, pauseYoutubeTask };