/* ================================================================
 *  Flow — download engine (public facade)
 *
 *  Exports: prepareDownload, startTask, pauseTask, cancelTask,
 *           pauseAll, removePartialFiles, isTaskActive,
 *           getTaskInfo, onSystemResume
 * ================================================================ */

const fs = require("fs");
const path = require("path");

const { prepareDownload } = require("./probe");
const { DownloadTask } = require("./task");

const tasks = new Map();
const fileLocks = new Map();

function wrapSender(sender, originalId, stringId) {
  if (!sender || typeof sender.send !== "function") {
    return { send: () => {} };
  }
  return {
    send: (channel, payload) => {
      try {
        if (payload && typeof payload === "object" && payload.id === stringId) {
          sender.send(channel, { ...payload, id: originalId });
        } else {
          sender.send(channel, payload);
        }
      } catch { /* renderer gone */ }
    },
    isDestroyed:
      typeof sender.isDestroyed === "function"
        ? () => sender.isDestroyed()
        : undefined,
  };
}

function startTask(id, url, filePath, totalSize, sender, extraHeaders = {}, validators = {}) {
  const stringId = String(id);

  const existing = tasks.get(stringId);
  if (existing && existing.state !== "finalized") {
    return Promise.reject(new Error("A download is already running with this id."));
  }

  const lockedBy = fileLocks.get(filePath);
  if (lockedBy && lockedBy !== existing) {
    return Promise.reject(new Error("Another download is already writing to this file."));
  }

  const wrappedSender = wrapSender(sender, id, stringId);

  const task = new DownloadTask({
    id: stringId,
    url,
    filePath,
    totalSize,
    sender: wrappedSender,
    extraHeaders,
    validators,
  });

  tasks.set(stringId, task);
  fileLocks.set(filePath, task);

  return task.run().finally(() => {
    if (tasks.get(stringId) === task) tasks.delete(stringId);
    if (fileLocks.get(filePath) === task) fileLocks.delete(filePath);
  });
}

async function pauseTask(id) {
  const task = tasks.get(String(id));
  if (!task) return { success: false, error: "No active download with this id." };
  return task.pause();
}

async function cancelTask(id) {
  const task = tasks.get(String(id));
  if (!task) return { success: false, error: "No active download with this id." };
  return task.cancel();
}

async function pauseAll() {
  const ids = Array.from(tasks.keys());
  await Promise.all(ids.map((id) => pauseTask(id).catch(() => {})));
}

/* ---- NEW: task snapshot for download-window UI ---- */
function getTaskInfo(id) {
  const task = tasks.get(String(id));
  if (!task) return null;
  return {
    id: Number(id),
    filename: task.filePath ? path.basename(task.filePath) : "download",
    filePath: task.filePath,
    totalSize: task.totalSize || 0,
    downloaded: task.totalDownloaded || 0,
    percent: task.totalSize > 0
      ? ((task.totalDownloaded || 0) / task.totalSize) * 100
      : 0,
    state: task.state,
    resumable: task.validators.resumable !== false,
  };
}

function removePartialFiles(filePath) {
  const files = [
    filePath + ".fastdl",
    filePath + ".download",
    filePath + ".fastdl.tmp",
  ];
  for (const p of files) {
    try {
      if (fs.existsSync(p)) fs.unlinkSync(p);
    } catch (err) {
      console.error("[downloadManager] cleanup failed:", p, err.message);
    }
  }
}

function isTaskActive(id) {
  const t = tasks.get(String(id));
  return !!t && t.state !== "finalized";
}

async function onSystemResume() {
  for (const t of tasks.values()) {
    try { t.onSystemResume(); } catch {}
  }
}

module.exports = {
  prepareDownload,
  startTask,
  pauseTask,
  cancelTask,
  pauseAll,
  removePartialFiles,
  isTaskActive,
  getTaskInfo,        // ← the missing export
  onSystemResume,
};