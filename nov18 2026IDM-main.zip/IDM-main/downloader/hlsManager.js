/* ================================================================
 *  Flow — HLS (.m3u8) download via yt-dlp + ffmpeg
 * ================================================================ */

const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");
const fsp = require("fs/promises");

const {
  HLS_CONCURRENCY,
  HLS_FFMPEG_TIMEOUT_MS,
  HLS_DEFAULT_UA,
} = require("./config");
const { renameWithRetry } = require("./utils");
const { getFileCategory } = require("./task");

const activeHlsTasks = new Map();

function isHlsUrl(url) {
  return typeof url === "string" && /\.m3u8(\?|#|$)/i.test(url);
}

function deriveHlsHeaders(extraHeaders = {}, userAgent, url = "") {
  const out = {};
  let ref = extraHeaders.Referer || extraHeaders.referer;

  if (url.includes("net52.cc") || url.includes("freecdn") || url.includes("netmirror")) {
    ref = "https://net52.cc";
  }

  if (ref) {
    try {
      const u = new URL(ref);
      out.Origin  = u.origin;
      out.Referer = u.origin + "/";
    } catch {}
  }
  if (extraHeaders.Origin) out.Origin = extraHeaders.Origin;
  if (extraHeaders.Referer && !out.Referer) out.Referer = extraHeaders.Referer;
  if (extraHeaders.Cookie) out.Cookie = extraHeaders.Cookie;
  out["User-Agent"] = userAgent || HLS_DEFAULT_UA || "Mozilla/5.0";
  return out;
}

function argsFromHeaders(headers) {
  const args = [];
  for (const [k, v] of Object.entries(headers)) {
    if (!v) continue;
    if (k.toLowerCase() === "user-agent") args.push("--user-agent", String(v));
    else                                  args.push("--add-header", `${k}: ${v}`);
  }
  return args;
}

function safeFilename(name) {
  return String(name || "hls-video")
    .replace(/[\x00-\x1f\x7f]/g, "")
    .replace(/[\\/:*?"<>|]/g, "_")
    .replace(/^[\s.]+|[\s.]+$/g, "")
    .slice(0, 150) || "hls-video";
}

function isMeaningfulTitle(t) {
  if (!t) return false;
  const s = String(t).trim();
  if (s.length < 3) return false;
  if (/^\d+p?$/i.test(s)) return false;
  if (/^(video|audio|master|playlist|index|segment)$/i.test(s)) return false;
  return true;
}

function dumpJson(url, headers, timeoutMs) {
  return new Promise((resolve, reject) => {
    const args = [
      "--dump-json", "--no-warnings", "--no-playlist", "--no-check-certificate",
      ...argsFromHeaders(headers), url,
    ];
    let proc;
    try { proc = spawn("yt-dlp", args); }
    catch (err) { return reject(err); }

    let stdout = "", stderr = "";
    const timer = setTimeout(() => {
      try { proc.kill("SIGKILL"); } catch {}
      reject(new Error("yt-dlp dump-json timed out"));
    }, timeoutMs);

    proc.stdout.on("data", (d) => (stdout += d.toString()));
    proc.stderr.on("data", (d) => (stderr += d.toString()));
    
    proc.on("error", (err) => { 
      clearTimeout(timer); 
      if (err.code === 'ENOENT') reject(new Error("yt-dlp is not installed or not in PATH."));
      else reject(err); 
    });

    proc.on("close", (code) => {
      clearTimeout(timer);
      if (code !== 0) return reject(new Error(stderr.trim().slice(-300) || `exit ${code}`));
      try {
        const lines = stdout.trim().split("\n").filter(Boolean);
        if (!lines.length) return reject(new Error("no JSON"));
        resolve(JSON.parse(lines[lines.length - 1]));
      } catch (e) { reject(e); }
    });
  });
}

async function prepareHlsDownload(url, saveDirectory, extraHeaders = {}, opts = {}) {
  const headers = deriveHlsHeaders(extraHeaders, opts.userAgent, url);
  let title = "";
  let ext = "";

  // 1. Try dumpJson to get true title, ext, and filename
  try {
    const info = await dumpJson(url, headers, 6000);
    if (info) {
      if (info.title && isMeaningfulTitle(info.title)) title = info.title;
      if (info.ext) ext = info.ext;
      
      if (info._filename) {
        const pathExt = path.extname(info._filename).replace(".", "").toLowerCase();
        if (["mp3", "mp4", "mkv", "m4a", "webm", "avi", "flac", "wav"].includes(pathExt)) {
          ext = pathExt;
          title = path.basename(info._filename, "." + pathExt);
        }
      }
    }
  } catch (err) {
    console.warn(`[hlsManager] dumpJson failed: ${err.message}`);
  }

  // 2. If dumpJson failed, fall back to provided filename
  if (!title && opts.filename) {
    let rawName = opts.filename;
    const pathExt = path.extname(rawName).replace(".", "").toLowerCase();
    if (["mp3", "mp4", "mkv", "m4a", "webm", "avi", "flac", "wav"].includes(pathExt)) {
      ext = pathExt;
      title = path.basename(rawName, "." + pathExt);
    } else {
      title = rawName;
    }
  }

  // 3. Fallback to URL
  if (!title) {
    let rawName = url.split('?')[0];
    const parts = rawName.split('/');
    title = parts[parts.length - 1] || "hls-video";
    title = title.replace(/\.(m3u8|mp4|m4a|mkv|ts|mp3)$/i, "");
  }
  if (!title) title = `hls-${Date.now()}`;

  // 4. Enforce mp4 if split stream
  if (opts.audioUrl) {
    ext = "mp4";
  } else if (!ext || ["m3u8", "mpd", "ts"].includes(ext)) {
    ext = "mp4";
  }

  const fileName = safeFilename(title) + "." + ext;
  let filePath = path.join(saveDirectory, fileName);
  if (fs.existsSync(filePath) || fs.existsSync(filePath + ".part")) {
    const base = path.basename(fileName, "." + ext);
    for (let i = 1; i < 1000; i++) {
      const cand = path.join(saveDirectory, `${base} (${i}).${ext}`);
      if (!fs.existsSync(cand) && !fs.existsSync(cand + ".part")) {
        filePath = cand;
        break;
      }
    }
  }

  return {
    fileName: path.basename(filePath),
    filePath,
    totalSize: 0,
    resumable: false,
    hls: true,
    finalUrl: url,
    saveDirectory,
  };
}

function parseSpeed(s) {
  if (!s) return 0;
  const m = s.match(/([\d.]+)\s*([KMG]?)i?B\/s/i);
  if (!m) return 0;
  const v = parseFloat(m[1]);
  const u = (m[2] || "").toUpperCase();
  if (u === "G") return v * 1024;
  if (u === "K") return v / 1024;
  return v;
}

function parseEta(s) {
  if (!s) return 0;
  const p = s.split(":").map(Number);
  if (p.length === 3) return p[0] * 3600 + p[1] * 60 + p[2];
  if (p.length === 2) return p[0] * 60 + p[1];
  return 0;
}

function parseYtDlpProgress(text, cb) {
  const re = /\[download\]\s+([\d.]+)%\s+of\s+~?\s*([\d.]+\s*\w+)(?:\s+at\s+([\d.]+\s*\w+\/s))?(?:\s+ETA\s+([\d:]+))?/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    cb(parseFloat(m[1]) || 0, parseSpeed(m[3]), parseEta(m[4]));
  }
}

function runYtDlp(task, url, outputPath, headers, concurrency, onProgress) {
  return new Promise((resolve, reject) => {
    const safeConcurrency = String(concurrency || 16);

    const args = [
      "-N", safeConcurrency,
      "--no-warnings", "--no-playlist",
      "--newline", "--no-check-certificate",
      "--retries", "5", "--fragment-retries", "10",
      "--socket-timeout", "30",
      "-o", outputPath,
      ...argsFromHeaders(headers),
      url,
    ];

    console.log(`[HLS] Executing: yt-dlp ${args.join(" ")}`);

    let proc;
    try { proc = spawn("yt-dlp", args, { stdio: ["ignore", "pipe", "pipe"] }); }
    catch (err) { return reject(err); }

    task.proc = proc;
    let lastErr = "";

    const onData = (t) => parseYtDlpProgress(t, onProgress);
    proc.stdout.on("data", (d) => onData(d.toString()));
    proc.stderr.on("data", (d) => {
      const t = d.toString();
      lastErr = t;
      console.error(`[yt-dlp stderr]`, t.trim());
      onData(t);
    });

    proc.on("error", (err) => {
      task.proc = null;
      if (err.code === "ENOENT") reject(new Error("yt-dlp is not installed or not in PATH."));
      else reject(err);
    });

    proc.on("close", (code) => {
      task.proc = null;
      if (task.cancelled) return resolve();
      if (code === 0) return resolve();
      reject(new Error(lastErr.trim().slice(-300) || `yt-dlp exited ${code}`));
    });
  });
}

function mergeWithFfmpeg(task, videoPath, audioPath, outputPath) {
  return new Promise((resolve, reject) => {
    const args = [
      "-y", "-loglevel", "error",
      "-i", videoPath, "-i", audioPath,
      "-c", "copy", "-movflags", "+faststart",
      outputPath,
    ];

    let proc;
    try { proc = spawn("ffmpeg", args, { stdio: ["ignore", "pipe", "pipe"] }); }
    catch (err) { return reject(err); }

    task.proc = proc;
    let stderr = "";
    proc.stderr.on("data", (d) => {
      const t = d.toString();
      stderr += t;
      console.error(`[ffmpeg stderr]`, t.trim());
    });

    proc.on("error", (err) => {
      task.proc = null;
      if (err.code === "ENOENT") reject(new Error("ffmpeg is not installed or not in PATH."));
      else reject(err);
    });

    const timer = setTimeout(() => {
      try { proc.kill("SIGKILL"); } catch {}
      reject(new Error("ffmpeg timeout"));
    }, HLS_FFMPEG_TIMEOUT_MS || 300000);
    if (timer.unref) timer.unref();

    proc.on("close", (code) => {
      clearTimeout(timer);
      task.proc = null;
      if (task.cancelled) return resolve();
      if (code === 0) return resolve();
      reject(new Error(`ffmpeg exited ${code}: ${stderr.trim().slice(-300)}`));
    });
  });
}

async function cleanupTmp(p) {
  for (const suffix of ["", ".part", ".ytdl"]) {
    try { if (fs.existsSync(p + suffix)) await fsp.unlink(p + suffix); } catch {}
  }
}

async function sortHlsFile(filePath) {
  try {
    const filename   = path.basename(filePath);
    const category   = getFileCategory(filename);
    const saveDir    = path.dirname(filePath);
    const categoryDir = path.join(saveDir, category);

    await fsp.mkdir(categoryDir, { recursive: true });

    let sortedPath = path.join(categoryDir, filename);
    if (fs.existsSync(sortedPath)) {
      const ext  = path.extname(filename);
      const base = path.basename(filename, ext);
      for (let i = 1; i < 1000; i++) {
        const candidate = path.join(categoryDir, `${base} (${i})${ext}`);
        if (!fs.existsSync(candidate)) {
          sortedPath = candidate;
          break;
        }
      }
    }

    await renameWithRetry(filePath, sortedPath);
    console.log(`[HLS] auto-sorted to ${category}/${path.basename(sortedPath)}`);
    return sortedPath;
  } catch (err) {
    console.warn("[HLS] auto-sort failed — file stays in original location:", err.message);
    return filePath;
  }
}

async function startHlsTask(id, url, filePath, sender, extraHeaders = {}, opts = {}) {
  const numId = Number(id);
  const audioUrl = opts.audioUrl || null;
  const concurrency = opts.concurrency || HLS_CONCURRENCY || 16;
  const headers = deriveHlsHeaders(extraHeaders, opts.userAgent, url);

  const task = {
    id: numId, proc: null, cancelled: false,
    finalPath: filePath, videoPath: null, audioPath: null,
  };
  activeHlsTasks.set(numId, task);

  const emit = (pct, spd = 0, eta = 0) => {
    try {
      sender.send("download-progress", {
        id: numId,
        percent: Math.max(0, Math.min(99.9, pct)).toFixed(1),
        speedMBps: Number(spd || 0).toFixed(2),
        etaSeconds: eta,
        downloaded: 0, totalSize: 0,
      });
    } catch {}
  };

  try {
    if (audioUrl) {
      const dir  = path.dirname(filePath);
      const ext  = path.extname(filePath) || ".mp4";
      const base = path.basename(filePath, ext);
      const videoTmp = path.join(dir, `${base}.video${ext}`);
      const audioTmp = path.join(dir, `${base}.audio.m4a`);
      task.videoPath = videoTmp;
      task.audioPath = audioTmp;

      emit(0);
      await runYtDlp(task, url, videoTmp, headers, concurrency, (p, s, e) => {
        emit(p * 0.90, s, e);
      });
      if (task.cancelled) throw new Error("aborted");

      await runYtDlp(task, audioUrl, audioTmp, headers, concurrency, (p, s, e) => {
        emit(90 + p * 0.095, s, e);
      });
      if (task.cancelled) throw new Error("aborted");

      emit(99.9);
      await mergeWithFfmpeg(task, videoTmp, audioTmp, filePath);
      await cleanupTmp(videoTmp);
      await cleanupTmp(audioTmp);
    } else {
      await runYtDlp(task, url, filePath, headers, concurrency, (p, s, e) => {
        emit(p, s, e);
      });
    }

    if (task.cancelled) {
      activeHlsTasks.delete(numId);
      return { success: false, cancelled: true };
    }

    emit(100);

    const sortedPath = await sortHlsFile(filePath);

    activeHlsTasks.delete(numId);
    return { success: true, filePath: sortedPath };
  } catch (err) {
    activeHlsTasks.delete(numId);
    if (task.videoPath) await cleanupTmp(task.videoPath);
    if (task.audioPath) await cleanupTmp(task.audioPath);
    if (task.cancelled) return { success: false, cancelled: true };
    throw err;
  }
}

function pauseHlsTask(id) {
  const task = activeHlsTasks.get(Number(id));
  if (!task) return { success: false, error: "No active HLS task" };
  task.cancelled = true;
  if (task.proc) {
    try { task.proc.kill("SIGINT"); } catch {}
    const proc = task.proc;
    setTimeout(() => { try { proc && proc.kill("SIGKILL"); } catch {} }, 2000).unref?.();
  }
  activeHlsTasks.delete(Number(id));
  return { success: true };
}

module.exports = {
  isHlsUrl,
  prepareHlsDownload,
  startHlsTask,
  pauseHlsTask,
};