/* ================================================================
 *  Flow — save-directory selection
 * ================================================================ */

import { state } from "./state.js";
import { toast } from "./toast.js";
import { updateDirectoryLabels } from "./render.js";

export async function chooseDirectory() {
  if (!window.api || !window.api.selectDirectory) return;
  const dir = await window.api.selectDirectory();
  if (!dir) return;
  state.directory = dir;
  updateDirectoryLabels();
  toast("Save folder updated", "success");
}

export function resetDirectory() {
  state.directory = null;
  updateDirectoryLabels();
  toast("Reset to default folder", "info");
}