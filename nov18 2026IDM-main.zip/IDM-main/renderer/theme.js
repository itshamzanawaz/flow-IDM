/* ================================================================
 *  Flow — theme
 * ================================================================ */

import { state } from "./state.js";
import { $ } from "./utils.js";

export function applyTheme() {
  document.documentElement.setAttribute("data-theme", state.theme);
  const moon = $("#theme-icon-moon");
  const sun  = $("#theme-icon-sun");
  if (moon) moon.hidden = state.theme !== "dark";
  if (sun)  sun.hidden  = state.theme === "dark";
  const label = $("#settings-theme-label");
  if (label) label.textContent = state.theme === "dark" ? "Dark" : "Light";
}

export function toggleTheme() {
  state.theme = state.theme === "dark" ? "light" : "dark";
  localStorage.setItem("flow-theme", state.theme);
  applyTheme();
}