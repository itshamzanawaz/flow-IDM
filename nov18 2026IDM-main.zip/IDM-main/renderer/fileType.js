/* ================================================================
 *  Flow — filename → icon + colour mapping
 * ================================================================ */

import { SVG } from "./icons.js";

export const TYPE_MAP = {
  video:   { ext: ["mp4","mkv","avi","mov","webm","flv","m4v","wmv","mpg","mpeg","ts","m2ts"], color: "#8b5cf6" },
  audio:   { ext: ["mp3","wav","flac","aac","ogg","m4a","wma","opus","aiff"],            color: "#ec4899" },
  image:   { ext: ["jpg","jpeg","png","gif","webp","svg","bmp","tiff","ico"],     color: "#06b6d4" },
  archive: { ext: ["zip","rar","7z","tar","gz","bz2","xz","iso","dmg"],                 color: "#f59e0b" },
  doc:     { ext: ["pdf","doc","docx","txt","rtf","odt","md","xls","xlsx","ppt","pptx","csv","epub"], color: "#ef4444" },
  code:    { ext: ["js","ts","py","java","c","cpp","html","css","json","xml","sh","go","rs"], color: "#22c55e" },
  app:     { ext: ["exe","msi","dmg","pkg","deb","appimage","apk"],               color: "#6366f1" },
};

export function fileVisual(filename) {
  const ext = (String(filename || "").split(".").pop() || "").toLowerCase();
  for (const [type, cfg] of Object.entries(TYPE_MAP)) {
    if (cfg.ext.includes(ext)) return { svg: SVG[type] || SVG.file, color: cfg.color };
  }
  return { svg: SVG.file, color: "#6b7280" };
}

/**
 * Groups a file into a broad category for the Completed view.
 */
export function getFileCategory(filename) {
  const ext = (String(filename || "").split(".").pop() || "").toLowerCase();
  
  if (TYPE_MAP.video.ext.includes(ext)) return "Video";
  if (TYPE_MAP.audio.ext.includes(ext)) return "Music";
  if (TYPE_MAP.archive.ext.includes(ext)) return "Compressed";
  if (TYPE_MAP.doc.ext.includes(ext)) return "Documents";
  
  return "Other";
}