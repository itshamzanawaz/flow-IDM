/* ================================================================
 *  Flow — clipboard + new-download flow
 *
 *  handleDownload no longer silently ignores a successful response
 *  that lacks an `id`. It also surfaces "no response" so the user
 *  always gets feedback after clicking Download.
 * ================================================================ */

import { state } from "./state.js";
import { $, isValidUrl } from "./utils.js";
import { toast } from "./toast.js";
import { refreshHistory } from "./refresh.js";

export async function handlePaste() {
  try {
    if (!window.api || !window.api.readClipboard) throw new Error("Clipboard API not available");
    const text = await window.api.readClipboard();
    if (!text || !text.trim()) { toast("Clipboard is empty", "warning"); return; }
    const input = $("#url-input");
    if (!input) return;
    input.value = text.trim();
    input.focus();
    input.setSelectionRange(input.value.length, input.value.length);
    toast("URL pasted successfully", "success");
  } catch (err) {
    console.error(err);
    toast("Could not read clipboard", "error");
  }
}

export async function handleDownload() {
  const input = $("#url-input");
  if (!input) return;
  const url = input.value.trim();

  if (!url) { toast("Please enter a URL", "warning"); input.focus(); return; }
  if (!isValidUrl(url)) { toast("Please enter a valid http(s) URL", "error"); input.focus(); return; }
  if (!window.api || !window.api.newDownload) { toast("Backend not available", "error"); return; }

  const btn = $("#download-btn");
  const original = btn ? btn.innerHTML : "";
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner"></span><span>Preparing…</span>`;
  }

  // Client-side ceiling in case the main process hangs (the main process
  // also wraps prepareDownload in a 60 s timeout — this is belt-and-braces).
  let timer;
  const clientTimeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error("Preparing download timed out — check your network")), 70000);
  });

  try {
    const res = await Promise.race([
      window.api.newDownload({ url, saveDirectory: state.directory }),
      clientTimeout,
    ]);

    if (res && res.error) {
      toast(res.error, "error");
    } else if (res && res.success !== false) {
      input.value = "";
      toast("Download started", "success");
      await refreshHistory();
    } else {
      toast("Download did not start", "warning");
    }
  } catch (err) {
    console.error(err);
    toast(err.message || "Failed to start download", "error");
  } finally {
    if (timer) clearTimeout(timer);
    if (btn) { btn.disabled = false; btn.innerHTML = original; }
  }
}