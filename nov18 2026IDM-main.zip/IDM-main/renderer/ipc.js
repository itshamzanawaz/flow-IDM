/* ================================================================
 *  Flow — IPC event wiring
 * ================================================================ */

import { state } from "./state.js";
import { toast } from "./toast.js";
import { render, renderActiveContainers, updateLiveHistoryProgress } from "./render.js";
import { refreshHistory } from "./refresh.js";

export function registerIpcListeners() {
  const api = window.api;

  api.onDownloadStart((data) => {
    const id = data.id;
    state.active.set(id, {
      id,
      filename: data.fileName || data.filename || "download",
      filePath: data.filePath,
      totalSize: data.totalSize || 0,
      percent: 0,
      speedMBps: 0,
      etaSeconds: 0,
      status: "Downloading",
      startedAt: Date.now(),
    });
    render();
    refreshHistory();
  });

  api.onDownloadProgress((data) => {
    const id = data.id;
    let entry = state.active.get(id);
    if (!entry) {
      const row = state.history.find((x) => x.id === id);
      if (!row) return;
      const s = String(row.status || "").toLowerCase();
      if (s !== "downloading" && s !== "preparing") return;
      entry = {
        id,
        filename: row.filename,
        filePath: row.directory,
        totalSize: row.totalSize,
        status: "Downloading",
        startedAt: Date.now(),
      };
      state.active.set(id, entry);
    }

    if (entry.status === "Paused") return;

    entry.percent    = Math.max(0, Math.min(100, parseFloat(data.percent) || 0));
    entry.speedMBps  = data.speedMBps || 0;
    entry.etaSeconds = data.etaSeconds || 0;
    entry.status     = "Downloading";

    // Surgical updates only — do NOT call render() here.
    renderActiveContainers();
    updateLiveHistoryProgress();
  });

  api.onDownloadError((data) => {
    if (!data.silent) {
      toast(data.message || "Download failed", "error");
    }
    refreshHistory();
  });

  api.onStatusChange(() => {
    refreshHistory();
  });
}