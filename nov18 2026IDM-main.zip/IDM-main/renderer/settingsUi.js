/* ================================================================
 *  Flow — System settings card
 *
 *  Appended to the existing Settings view at boot, just before the
 *  "About" card. Uses the app's standard .card / .settings-row /
 *  .btn classes and the theme variables in styles.css, so it adapts
 *  to light/dark without any inline colours.
 *
 *  Two toggles (minimize to tray, start at login) and a "Quit Flow"
 *  button that exits the app completely (bypassing the tray).
 * ================================================================ */

import { toast } from "./toast.js";

export async function mountSettingsUi() {
  const container = document.querySelector('[data-view="settings"]');
  if (!container) {
    console.warn("[settings] settings view container not found");
    return;
  }
  if (container.querySelector("#flow-system-card")) return;

  let s = {};
  try { s = await window.api.getSettings(); } catch {}
  const isLinux = s.platform === "linux";

  const card = document.createElement("div");
  card.id = "flow-system-card";
  card.className = "card";

  card.innerHTML = `
    <h2 class="card-title">System</h2>
    <p class="card-desc">Background operation and startup behaviour.</p>

    <div class="settings-row">
      <div class="settings-info">
        <div class="settings-label">Minimize to tray on close</div>
        <div class="settings-value">Keep downloads running when the window is closed.</div>
      </div>
      <label class="settings-toggle">
        <input type="checkbox" id="flow-toggle-tray" ${s.minimizeToTray ? "checked" : ""}>
        <span class="toggle-track"></span>
      </label>
    </div>

    <div class="settings-row">
      <div class="settings-info">
        <div class="settings-label">Start Flow at system login</div>
        <div class="settings-value">${
          isLinux
            ? "Installs ~/.config/autostart/flow.desktop."
            : "Registers Flow as a login item."
        }</div>
      </div>
      <label class="settings-toggle">
        <input type="checkbox" id="flow-toggle-startup" ${s.startAtLogin ? "checked" : ""}>
        <span class="toggle-track"></span>
      </label>
    </div>

    <div class="settings-quit-row">
      <div class="settings-info">
        <div class="settings-label">Quit Flow</div>
        <div class="settings-value">Stop all downloads and exit completely.</div>
      </div>
      <div class="settings-actions">
        <button class="btn btn-ghost danger" id="flow-quit-btn" type="button">Quit Flow</button>
      </div>
    </div>
  `;

  // Insert before the "About" card so System is not the last thing
  // the user sees. Fall back to append if About is not present.
  const aboutCard = Array.from(container.querySelectorAll(".card")).find(
    (el) => el.querySelector(".card-title")?.textContent?.trim() === "About"
  );
  if (aboutCard) aboutCard.before(card);
  else container.appendChild(card);

  const trayToggle = card.querySelector("#flow-toggle-tray");
  trayToggle?.addEventListener("change", async (e) => {
    const v = e.target.checked;
    try {
      const res = await window.api.setMinimizeToTray(v);
      if (res && res.success === false) throw new Error(res.error || "Failed");
      toast(v ? "Flow will minimize to tray" : "Flow will quit on close", "success");
    } catch (err) {
      e.target.checked = !v;
      toast("Failed to save setting", "error");
    }
  });

  const startupToggle = card.querySelector("#flow-toggle-startup");
  startupToggle?.addEventListener("change", async (e) => {
    const v = e.target.checked;
    try {
      const res = await window.api.setStartAtLogin(v);
      if (res && res.success === false) throw new Error(res.error || "Failed");
      toast(
        v ? "Flow will start at login" : "Flow will not start at login",
        "success"
      );
    } catch (err) {
      e.target.checked = !v;
      toast("Failed to update autostart", "error");
    }
  });

  card.querySelector("#flow-quit-btn")?.addEventListener("click", async () => {
    try { await window.api.quitApp(); } catch {}
  });
}