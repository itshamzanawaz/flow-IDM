/* ================================================================
 *  Flow — history refresh + live active pruning
 *
 *  refreshHistory() must NOT delete an active entry whose DB row has
 *  not landed yet. Main writes the row asynchronously after
 *  startTask() returns; deleting here caused downloads to vanish a
 *  few ms after being added to state.active. Young entries
 *  (startedAt within the last 5 s) are protected.
 * ================================================================ */

import { state } from "./state.js";
import { render } from "./render.js";

const YOUNG_ENTRY_MS = 5000;

export function hasPendingAction(id) {
  return (
    state.inflight.has(`pause:${id}`) ||
    state.inflight.has(`resume:${id}`) ||
    state.inflight.has(`cancel:${id}`)
  );
}

export async function refreshHistory() {
  if (!window.api || !window.api.getHistory) return;
  try {
    state.history = await window.api.getHistory();

    for (const [id, entry] of Array.from(state.active.entries())) {
      if (hasPendingAction(id)) continue;

      const row = state.history.find((x) => x.id === id);
      if (!row) {
        // Row not in DB yet — probably a fresh download whose DB write
        // hasn't completed. Do not delete young entries.
        const age = Date.now() - (entry.startedAt || 0);
        if (age < YOUNG_ENTRY_MS) continue;
        state.active.delete(id);
        continue;
      }

      const st = String(row.status || "").toLowerCase();
      if (st === "downloading" || st === "preparing") {
        entry.status = st === "preparing" ? "Preparing" : "Downloading";
      } else if (st === "paused") {
        entry.status = "Paused";
        entry.speedMBps = 0;
        entry.etaSeconds = 0;
      } else {
        state.active.delete(id);
      }
    }

    render();
  } catch (err) {
    console.error("[flow] refreshHistory failed:", err);
  }
}