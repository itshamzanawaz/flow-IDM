/* ================================================================
 *  Flow — file details modal
 * ================================================================ */

import { $ } from "./utils.js";
import { statusBadge } from "./components/badges.js";
import { formatBytes, formatDate } from "./formatters.js";

let _detailsItem = null;

export function openDetails(item) {
  _detailsItem = item;
  const set = (id, val) => { const el = $(id); if (el) el.textContent = val; };
  set("#det-name", item.filename || "—");
  const statusEl = $("#det-status");
  if (statusEl) statusEl.innerHTML = statusBadge(item.status);
  set("#det-size", formatBytes(item.totalSize));
  set("#det-date", formatDate(item.timestamp));
  set("#det-path", item.directory || "—");
  set("#det-url",  item.url || "—");
  $("#details-modal")?.classList.add("open");
}

export function closeDetails() {
  $("#details-modal")?.classList.remove("open");
  _detailsItem = null;
}

export function getDetailsItem() {
  return _detailsItem;
}