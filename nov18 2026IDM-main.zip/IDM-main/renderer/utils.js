/* ================================================================
 *  Flow — DOM + string helpers
 * ================================================================ */

export const $  = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

export function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

export function on(sel, event, handler) {
  const el = typeof sel === "string" ? $(sel) : sel;
  if (!el) { console.warn("[flow] missing element for binding:", sel); return null; }
  el.addEventListener(event, handler);
  return el;
}

export function isValidUrl(str) {
  try {
    const u = new URL(str);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch { return false; }
}

export function normalizeStatus(s) {
  const v = String(s || "").toLowerCase();
  if (v === "downloading" || v === "preparing" || v === "resuming") return "downloading";
  if (v === "paused") return "paused";
  if (v === "completed") return "completed";
  if (v === "error") return "error";
  if (v === "cancelled" || v === "canceled") return "cancelled";
  return v || "unknown";
}