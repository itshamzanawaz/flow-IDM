/* ================================================================
 *  Flow — DOM event wiring
 * ================================================================ */

import { state } from "./state.js";
import { $, $$, on } from "./utils.js";
import { setView } from "./views.js";
import { toggleTheme } from "./theme.js";
import { handlePaste, handleDownload } from "./download.js";
import { handleAction, runBulk } from "./actions.js";
import { chooseDirectory, resetDirectory } from "./directory.js";
import { closeDetails, getDetailsItem } from "./details.js";
import { closeConfirm, confirmDialog } from "./confirm.js";
import { renderAll } from "./render.js";
import { toast } from "./toast.js";

async function clearCompletedHandler() {
  const ok = await confirmDialog(
    "Clear completed downloads?",
    "All completed entries will be removed from your history. The files on disk will not be touched.",
    { confirmLabel: "Clear completed" }
  );
  if (!ok) return;
  const res = await window.api.clearCompleted();
  if (res && res.success) toast(`Removed ${res.removed} entr${res.removed === 1 ? "y" : "ies"}`, "success");
  else toast((res && res.error) || "Could not clear completed", "error");
}

export function bindEvents() {
  /* ---------------- Navigation ---------------- */
  $$(".nav-item").forEach((btn) => {
    btn.addEventListener("click", () => setView(btn.dataset.view));
  });

  document.addEventListener("click", (e) => {
    const goto = e.target.closest("[data-goto]");
    if (goto) { setView(goto.dataset.goto); return; }
  });

  /* ---------------- Theme ---------------- */
  on("#theme-toggle", "click", toggleTheme);
  on("#settings-theme-toggle", "click", toggleTheme);

  /* ---------------- URL input ---------------- */
  on("#paste-btn", "click", handlePaste);
  on("#download-btn", "click", handleDownload);
  on("#url-input", "keydown", (e) => { if (e.key === "Enter") handleDownload(); });

  /* ---------------- Directory ---------------- */
  on("#quick-dir-btn", "click", chooseDirectory);
  on("#settings-choose-dir", "click", chooseDirectory);
  on("#settings-reset-dir", "click", resetDirectory);

  /* ---------------- All Downloads: filter / search / sort / select ---------------- */
  on("#filter-tabs", "click", (e) => {
    const tab = e.target.closest(".filter-tab");
    if (!tab) return;
    state.allFilter = tab.dataset.filter || "all";
    $$(".filter-tab").forEach((t) => t.classList.toggle("active", t === tab));
    renderAll();
  });

  on("#all-search", "input", (e) => {
    state.allSearch = e.target.value || "";
    renderAll();
  });

  on("#all-sort", "change", (e) => {
    state.allSort = e.target.value;
    renderAll();
  });

  on("#select-toggle-btn", "click", () => {
    state.selectMode = !state.selectMode;
    if (!state.selectMode) state.selected.clear();
    renderAll();
  });

  on("#bulk-bar", "click", (e) => {
    const btn = e.target.closest("[data-bulk]");
    if (!btn) return;
    runBulk(btn.dataset.bulk);
  });

  /* ---------------- Clear completed ---------------- */
  on("#clear-completed-btn", "click", clearCompletedHandler);
  on("#settings-clear-completed", "click", clearCompletedHandler);

  /* ---------------- Details modal ---------------- */
  on("#modal-close", "click", closeDetails);
  on("#details-modal", "click", (e) => {
    if (e.target.id === "details-modal") closeDetails();
  });

  on("#det-copy-url", "click", async () => {
    const item = getDetailsItem();
    if (!item || !item.url) return;
    try { await navigator.clipboard.writeText(item.url); toast("URL copied", "success"); }
    catch { toast("Could not copy URL", "error"); }
  });
  on("#det-open-folder", "click", () => {
    const item = getDetailsItem();
    if (item?.directory) window.api.openFolder(item.directory);
  });

  /* ---------------- Confirm modal ---------------- */
  on("#confirm-ok", "click", () => closeConfirm(true));
  on("#confirm-cancel", "click", () => closeConfirm(false));
  on("#confirm-modal", "click", (e) => {
    if (e.target.id === "confirm-modal") closeConfirm(false);
  });

  /* ---------------- Keyboard ---------------- */
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      closeDetails();
      closeConfirm(false);
    }
  });

  /* ---------------- Delegated row clicks ---------------- */
  document.addEventListener("click", (e) => {
    const check = e.target.closest(".row-check");
    if (check) {
      const id = Number(check.dataset.id);
      if (check.checked) state.selected.add(id);
      else state.selected.delete(id);
      renderAll();
      return;
    }

    const btn = e.target.closest("[data-action]");
    if (!btn) return;
    const { action, id } = btn.dataset;
    if (!id) return;
    handleAction(action, id);
  });
}