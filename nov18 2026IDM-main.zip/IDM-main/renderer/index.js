/* ================================================================
 *  Flow — Renderer entry point
 * ================================================================ */

import { state } from "./state.js";
import { escapeHtml } from "./utils.js";
import { applyTheme } from "./theme.js";
import { bindEvents } from "./events.js";
import { registerIpcListeners } from "./ipc.js";
import { refreshHistory } from "./refresh.js";
import { setView } from "./views.js";

function showFatal(message) {
  console.error("[flow] FATAL:", message);
  document.body.innerHTML = `
    <div style="padding:40px;font-family:ui-monospace,Menlo,monospace;color:#ef4444;background:#0b0d12;min-height:100vh;box-sizing:border-box;">
      <h1 style="margin:0 0 12px;">⚠️ Flow failed to start</h1>
      <pre style="white-space:pre-wrap;color:#f0f0f0;font-size:13px;">${escapeHtml(message)}</pre>
      <p style="color:#8a93a4;font-size:12px;margin-top:20px;">
        Open DevTools (Ctrl+Shift+I / Cmd+Option+I) to see the full error.
      </p>
    </div>`;
}

async function boot() {
  if (!window.api) {
    showFatal("window.api is undefined. The preload script did not expose the API.");
    return;
  }

  try { applyTheme(); } catch (e) { console.error("[flow] applyTheme:", e); }
  try { bindEvents(); } catch (e) { console.error("[flow] bindEvents:", e); }

  try { registerIpcListeners(); } catch (e) {
    console.error("[flow] registerIpcListeners:", e);
    showFatal("Failed to register IPC listeners: " + e.message);
    return;
  }

  try {
    if (window.api.getDefaultDirectory) {
      state.defaultDirectory = await window.api.getDefaultDirectory();
    }
  } catch (e) { console.error("[flow] getDefaultDirectory:", e); }

  try { await refreshHistory(); } catch (e) { console.error(e); }
  try { setView("dashboard"); } catch (e) { console.error("[flow] setView:", e); }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", boot, { once: true });
} else {
  boot();
}