/* ================================================================
 *  Flow — History row rendering
 *
 *  Retry/resume buttons show a different title when the row's last
 *  error was an expired-URL failure ("Refresh URL" instead of
 *  "Resume"/"Retry"), since clicking them opens the fresh-URL prompt.
 *
 *  Force-refresh (chain-link icon) is always available on Paused and
 *  Error rows — even when the error is not classified as expired.
 *  Use it when you know the URL is dead but the error text doesn't
 *  match the heuristic (e.g. a stuck 502).
 * ================================================================ */

import { SVG } from "../icons.js";
import { escapeHtml, normalizeStatus } from "../utils.js";
import { formatBytes, formatDate } from "../formatters.js";
import { statusBadge, fileIconHtml, emptyState } from "./badges.js";
import { state } from "../state.js";
import { getFileCategory } from "../fileType.js";

const ICON_BTN = (action, id, title, svg, danger = false) =>
  `<button class="btn-icon${danger ? " danger" : ""}" data-action="${action}" data-id="${id}" title="${title}" aria-label="${title}">${svg}</button>`;

function isExpiredError(errMsg) {
  return /expired|auth(?:entication)?\s+required|HTTP 403/i.test(String(errMsg || ""));
}

export function historyActions(item) {
  const id = item.id;
  const st = normalizeStatus(item.status);
  const expired = isExpiredError(item.error);

  if (st === "downloading") {
    return ICON_BTN("pause",  id, "Pause", SVG.pause)
         + ICON_BTN("popout", id, "Open progress window", SVG.external)
         + ICON_BTN("cancel", id, "Cancel", SVG.x, true)
         + ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
  }
  if (st === "paused") {
    const resumeTitle = expired ? "Refresh URL & resume" : "Resume";
    return ICON_BTN("resume", id, resumeTitle, SVG.play)
         + ICON_BTN("force-refresh", id, "Force refresh URL (auto-capture or paste)", SVG.refreshLink)
         + ICON_BTN("popout", id, "Open progress window", SVG.external)
         + ICON_BTN("cancel", id, "Cancel", SVG.x, true)
         + ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
  }
  if (st === "completed") {
    return ICON_BTN("open",   id, "Open file", SVG.external)
         + ICON_BTN("folder", id, "Show in folder", SVG.folder)
         + ICON_BTN("copy",   id, "Copy URL", SVG.copy)
         + ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
  }
  if (st === "error" || st === "cancelled") {
    const retryTitle = expired ? "Refresh URL" : "Retry";
    return ICON_BTN("retry",  id, retryTitle, SVG.retry)
         + ICON_BTN("force-refresh", id, "Force refresh URL (auto-capture or paste)", SVG.refreshLink)
         + ICON_BTN("copy",   id, "Copy URL", SVG.copy)
         + ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
  }
  return ICON_BTN("remove", id, "Remove from history", SVG.trash, true);
}

export function historyItemHtml(item, { selectable = false } = {}) {
  const st = normalizeStatus(item.status);
  const isLive = item.isLive && st === "downloading";
  const percent = isLive ? Math.max(0, Math.min(100, item.percent || 0)) : 0;

  const check = selectable
    ? `<label class="check-wrap"><input type="checkbox" class="row-check" data-id="${item.id}" ${
        state.selected.has(Number(item.id)) ? "checked" : ""
      }><span class="check-box"></span></label>`
    : "";

  const metaParts = [];
  if (isLive) {
    metaParts.push(
      `<span class="hi-progress" data-live-progress="${item.id}">${Math.round(percent)}% · ${item.speedMBps || 0} MB/s</span>`
    );
  }
  metaParts.push(escapeHtml(formatBytes(item.totalSize)));
  metaParts.push(escapeHtml(formatDate(item.timestamp)));
  const meta = metaParts.join(`<span class="dot"></span>`);

  const selectedCls = state.selected.has(Number(item.id)) ? " selected" : "";

  return `
    <div class="history-item${selectedCls}" data-id="${item.id}">
      ${check}
      ${fileIconHtml(item.filename)}
      <div class="hi-info" data-action="details" data-id="${item.id}">
        <div class="hi-name" title="${escapeHtml(item.filename)}">${escapeHtml(item.filename)}</div>
        <div class="hi-meta">${meta}</div>
      </div>
      <div class="hi-status">${statusBadge(item.status)}</div>
      <div class="hi-actions">${historyActions(item)}</div>
    </div>
  `;
}

export function historySignature(list, opts = {}) {
  const sel = opts.selectable
    ? Array.from(state.selected).sort((a, b) => a - b).join(",")
    : "";
  const rows = list
    .map((x) => `${x.id}:${normalizeStatus(x.status)}:${x.isLive ? "L" : "-"}`)
    .join("|");
  const groupStr = opts.groupByCategory ? "#grouped" : "";
  return `${rows}#${sel}${groupStr}`;
}

export function renderHistory(container, list, emptyTitle = "Nothing here yet", emptyDesc = "Your downloads will appear here.", opts = {}) {
  if (!container) return;
  const sig = historySignature(list, opts);
  if (container.dataset.sig === sig) return;
  container.dataset.sig = sig;

  if (!list.length) {
    container.innerHTML = emptyState(emptyTitle, emptyDesc);
    return;
  }

  if (opts.groupByCategory) {
    const groups = { Video: [], Music: [], Documents: [], Compressed: [], Other: [] };
    list.forEach(item => {
      const cat = getFileCategory(item.filename);
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(item);
    });

    const order = ["Video", "Music", "Documents", "Compressed", "Other"];
    const icons = {
      Video: SVG.video,
      Music: SVG.audio,
      Documents: SVG.doc,
      Compressed: SVG.archive,
      Other: SVG.file
    };

    container.innerHTML = order.map(cat => {
      if (groups[cat].length === 0) return "";
      return `
        <div class="history-group">
          <div class="history-group-header">
            <div class="hgh-icon">${icons[cat]}</div>
            <span class="hgh-title">${cat}</span>
            <span class="hgh-count">${groups[cat].length}</span>
          </div>
          <div class="history-list">
            ${groups[cat].map(item => historyItemHtml(item, opts)).join("")}
          </div>
        </div>
      `;
    }).join("");
    return;
  }

  container.innerHTML = list.map((item) => historyItemHtml(item, opts)).join("");
}