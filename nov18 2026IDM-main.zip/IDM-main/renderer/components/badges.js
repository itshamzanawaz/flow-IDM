/* ================================================================
 *  Flow — shared UI fragments: status badge, file icon, empty state
 * ================================================================ */

import { SVG } from "../icons.js";
import { escapeHtml } from "../utils.js";
import { fileVisual } from "../fileType.js";

export function statusBadge(status) {
  const s = String(status || "").toLowerCase();
  const map = {
    downloading: { label: "Downloading", cls: "downloading" },
    preparing:   { label: "Preparing",   cls: "preparing" },
    paused:      { label: "Paused",      cls: "paused" },
    completed:   { label: "Completed",   cls: "completed" },
    cancelled:   { label: "Canceled",    cls: "cancelled" },
    canceled:    { label: "Canceled",    cls: "cancelled" },
    error:       { label: "Failed",      cls: "error" },
  };
  const m = map[s] || { label: status || "Unknown", cls: "" };
  return `<span class="badge ${m.cls}"><span class="badge-dot"></span>${escapeHtml(m.label)}</span>`;
}

export function fileIconHtml(filename) {
  const { svg, color } = fileVisual(filename);
  return `<div class="file-icon" style="background:${color}1f; color:${color}">${svg}</div>`;
}

export function emptyState(title, desc) {
  return `
    <div class="empty">
      <div class="empty-icon">${SVG.downloadEmpty}</div>
      <div class="empty-title">${escapeHtml(title)}</div>
      <div class="empty-desc">${escapeHtml(desc)}</div>
    </div>
  `;
}