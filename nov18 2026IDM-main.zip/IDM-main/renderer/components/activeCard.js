/* ================================================================
 *  Flow — Active Downloads card
 * ================================================================ */

import { SVG } from "../icons.js";
import { fileVisual } from "../fileType.js";
import { formatBytes, formatEta } from "../formatters.js";
import { statusBadge, emptyState } from "./badges.js";

export function buildActiveCard(dl) {
  const card = document.createElement("div");
  card.className = "download-card";
  card.dataset.id = String(dl.id);
  const { svg, color } = fileVisual(dl.filename);

  card.innerHTML = `
    <div class="dl-head">
      <div class="file-icon" style="background:${color}1f; color:${color}">${svg}</div>
      <div class="dl-info">
        <div class="dl-name"></div>
        <div class="dl-sub"></div>
      </div>
      <div class="hi-status"></div>
      <div class="dl-actions">
        <button class="btn-icon" data-action="pause" data-id="${dl.id}" title="Pause">${SVG.pause}</button>
        <button class="btn-icon danger" data-action="cancel" data-id="${dl.id}" title="Cancel">${SVG.x}</button>
      </div>
    </div>
    <div class="progress-track">
      <div class="progress-bar"></div>
    </div>
    <div class="dl-stats">
      <span class="stat stat-size"></span>
      <span class="stat stat-speed"></span>
      <span class="stat stat-eta"></span>
    </div>
  `;
  updateActiveCard(card, dl, true);
  return card;
}

export function updateActiveCard(card, dl, initial = false) {
  const percent = Math.max(0, Math.min(100, Number(dl.percent) || 0));
  const isPaused = dl.status === "Paused";
  const isPreparing = dl.status === "Preparing";

  const nameEl = card.querySelector(".dl-name");
  if (nameEl && nameEl.textContent !== dl.filename) {
    nameEl.textContent = dl.filename || "";
    nameEl.title = dl.filename || "";
  }

  const subEl = card.querySelector(".dl-sub");
  if (subEl) {
    const wantSub = isPreparing ? "Preparing download…" : (dl.filePath || "");
    if (subEl.textContent !== wantSub) subEl.textContent = wantSub;
  }

  const statusEl = card.querySelector(".hi-status");
  if (statusEl) {
    const currentStatus = statusEl.dataset.status || "";
    const nextStatus = String(dl.status || "Downloading");
    if (currentStatus !== nextStatus) {
      statusEl.dataset.status = nextStatus;
      statusEl.innerHTML = statusBadge(nextStatus);
    }
  }

  const bar = card.querySelector(".progress-bar");
  if (bar) {
    if (isPreparing) {
      if (!bar.classList.contains("indeterminate")) {
        bar.classList.add("indeterminate");
        bar.style.width = "";
      }
    } else {
      if (bar.classList.contains("indeterminate")) bar.classList.remove("indeterminate");
      const width = `${percent}%`;
      if (bar.style.width !== width) bar.style.width = width;
    }
  }

  const totalStr = dl.totalSize ? formatBytes(dl.totalSize) : "Unknown size";
  const downloaded = dl.totalSize ? (dl.totalSize * percent) / 100 : 0;
  const speedStr = (!isPaused && !isPreparing && dl.speedMBps) ? `${dl.speedMBps} MB/s` : "—";
  const etaStr = (!isPaused && !isPreparing) ? formatEta(dl.etaSeconds) : "--";
  const shownPercent = isPreparing ? "—" : `${percent}%`;

  const sizeStat = card.querySelector(".stat-size");
  if (sizeStat) {
    const want = `<b>${shownPercent}</b>&nbsp;•&nbsp;${formatBytes(downloaded)} / ${totalStr}`;
    if (sizeStat.dataset.v !== want) { sizeStat.dataset.v = want; sizeStat.innerHTML = want; }
  }
  const speedStat = card.querySelector(".stat-speed");
  if (speedStat && speedStat.textContent !== speedStr) speedStat.textContent = speedStr;

  const etaStat = card.querySelector(".stat-eta");
  if (etaStat) {
    const want = `ETA <b>${etaStr}</b>`;
    if (etaStat.dataset.v !== want) { etaStat.dataset.v = want; etaStat.innerHTML = want; }
  }

  const actionsEl = card.querySelector(".dl-actions");
  if (actionsEl) {
    const primaryBtn = actionsEl.querySelector('[data-action="pause"], [data-action="resume"]');
    const wantAction = isPaused ? "resume" : "pause";
    if (!primaryBtn) {
      const btn = document.createElement("button");
      btn.className = "btn-icon";
      btn.dataset.action = wantAction;
      btn.dataset.id = dl.id;
      btn.innerHTML = isPaused ? SVG.play : SVG.pause;
      btn.title = isPaused ? "Resume" : "Pause";
      actionsEl.insertBefore(btn, actionsEl.firstChild);
    } else if (primaryBtn.dataset.action !== wantAction) {
      primaryBtn.dataset.action = wantAction;
      primaryBtn.title = isPaused ? "Resume" : "Pause";
      primaryBtn.innerHTML = isPaused ? SVG.play : SVG.pause;
    }
  }

  if (initial) card.dataset.inited = "1";
}

export function renderActive(container, list) {
  if (!container) return;

  const wanted = new Set(list.map((d) => String(d.id)));
  Array.from(container.querySelectorAll(".download-card")).forEach((card) => {
    if (!wanted.has(card.dataset.id)) card.remove();
  });

  if (!list.length) {
    if (!container.querySelector(".empty")) {
      container.innerHTML = emptyState("No active downloads", "Paste a link above to get started.");
    }
    return;
  }
  const emptyEl = container.querySelector(".empty");
  if (emptyEl) emptyEl.remove();

  list.forEach((dl, idx) => {
    const idStr = String(dl.id);
    let card = container.querySelector(`.download-card[data-id="${idStr}"]`);
    if (!card) card = buildActiveCard(dl);
    else updateActiveCard(card, dl);
    const currentAt = container.children[idx];
    if (currentAt !== card) container.insertBefore(card, currentAt || null);
  });
}