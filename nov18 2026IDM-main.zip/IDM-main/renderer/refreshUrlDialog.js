/* ================================================================
 *  Flow — "URL expired" refresh dialog
 *
 *  Shown when the user clicks Retry/Resume on a download whose last
 *  error indicates the URL has expired. The user pastes a fresh URL
 *  from the source site and the main process resumes the existing
 *  partial download from where it stopped.
 * ================================================================ */

let _resolver = null;
let _modalEl = null;

function ensureModal() {
  if (_modalEl && document.body.contains(_modalEl)) return _modalEl;

  const modal = document.createElement("div");
  modal.id = "refresh-url-modal";
  modal.className = "modal";
  modal.setAttribute("role", "dialog");
  modal.setAttribute("aria-modal", "true");
  modal.setAttribute("aria-labelledby", "refresh-url-title");

  modal.innerHTML = `
    <div class="modal-content confirm-content">
      <h2 class="modal-title" id="refresh-url-title">Download URL expired</h2>
      <div class="confirm-msg">
        The download link from the server has expired. This is common on
        sites like CoolROM that use short-lived signed URLs.
        <br><br>
        Open the source site again and click Download. Flow captures the
        new URL automatically and resumes from where it stopped — you
        don't need to paste it manually if the browser extension is
        installed. Otherwise paste the fresh URL below.
      </div>
      <input
        type="url"
        id="refresh-url-input"
        placeholder="https://..."
        spellcheck="false"
        autocomplete="off"
        style="
          width:100%;
          padding:10px 12px;
          margin:14px 0 4px;
          border:1px solid rgba(127,127,127,0.35);
          border-radius:6px;
          background:transparent;
          color:inherit;
          font-size:13px;
          box-sizing:border-box;
        "
      />
      <div class="delete-choice-actions">
        <button type="button" class="btn btn-primary" data-choice="ok">
          Resume with new URL
        </button>
        <button
          type="button"
          class="link-btn"
          data-choice="cancel"
          style="justify-content:center;padding:6px 0;width:100%;"
        >
          Cancel
        </button>
      </div>
    </div>
  `;

  modal.addEventListener("click", (e) => {
    if (e.target === modal) return close(null);
    const btn = e.target.closest("[data-choice]");
    if (!btn) return;
    const choice = btn.dataset.choice;
    if (choice === "cancel") return close(null);
    if (choice === "ok") {
      const input = modal.querySelector("#refresh-url-input");
      const val = input ? input.value.trim() : "";
      if (!val) {
        if (input) {
          input.style.borderColor = "#ef4444";
          input.focus();
        }
        return;
      }
      close(val);
    }
  });

  document.addEventListener("keydown", (e) => {
    if (!_modalEl || !_modalEl.classList.contains("open")) return;
    if (e.key === "Escape") return close(null);
    if (e.key === "Enter") {
      const input = _modalEl.querySelector("#refresh-url-input");
      const val = input ? input.value.trim() : "";
      if (val) close(val);
    }
  });

  document.body.appendChild(modal);
  _modalEl = modal;
  return modal;
}

function close(result) {
  if (_modalEl) _modalEl.classList.remove("open");
  if (_resolver) {
    const r = _resolver;
    _resolver = null;
    r(result);
  }
}

export function refreshUrlDialog() {
  return new Promise((resolve) => {
    _resolver = resolve;
    const modal = ensureModal();
    const input = modal.querySelector("#refresh-url-input");
    if (input) {
      input.value = "";
      input.style.borderColor = "";
    }
    modal.classList.add("open");
    setTimeout(() => input && input.focus(), 60);
  });
}