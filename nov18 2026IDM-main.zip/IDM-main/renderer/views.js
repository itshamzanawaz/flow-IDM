/* ================================================================
 *  Flow — view routing
 * ================================================================ */

import { state } from "./state.js";
import { $, $$ } from "./utils.js";
import { render } from "./render.js";

export const VIEW_META = {
  dashboard: { title: "Dashboard",     sub: "Start a new download — each one opens in its own window" },
  all:       { title: "All Downloads", sub: "Every download in one place — filter, search, and manage" },
  active:    { title: "Active",        sub: "Downloads currently in progress" },
  recent:    { title: "Recent",        sub: "Your most recent downloads with quick controls" },
  completed: { title: "Completed",     sub: "Downloads that finished successfully" },
};

export function setView(view) {
  if (view === "settings") {
    if (window.api && window.api.openSettingsWindow) {
      window.api.openSettingsWindow();
    }
    return; // Do not change the current view
  }

  state.view = view;
  $$(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.view === view));
  $$(".view").forEach((v) => v.classList.toggle("active", v.dataset.view === view));

  const meta = VIEW_META[view] || VIEW_META.dashboard;
  const titleEl = $("#page-title");
  const subEl = $("#page-subtitle");
  if (titleEl) titleEl.textContent = meta.title;
  if (subEl) subEl.textContent = meta.sub;
  render();
}