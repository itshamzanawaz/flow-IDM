/* ================================================================
 *  Flow — user-initiated actions
 *
 *  doResume / doRetry on an expired row now:
 *    1. Try auto-capture via window.api.requestFreshUrl(id).
 *    2. Fall back to the manual paste dialog.
 *
 *  doForceRefresh always goes through that same two-phase flow, even
 *  when the stored error does not match the "expired" heuristic. Use
 *  it when you know the URL is dead but the error text says something
 *  else (e.g. "Network error" from a stuck 502).
 * ================================================================ */

import { state } from "./state.js";
import { findItem } from "./data.js";
import { render } from "./render.js";
import { toast } from "./toast.js";
import { confirmDialog } from "./confirm.js";
import { deleteChoiceDialog } from "./deleteDialog.js";
import { refreshUrlDialog } from "./refreshUrlDialog.js";
import { refreshHistory } from "./refresh.js";
import { openDetails } from "./details.js";

function errorNeedsRefresh(errMsg) {
  return /expired|auth(?:entication)?\s+required|HTTP 403/i.test(String(errMsg || ""));
}

export async function handleAction(action, id, opts = {}) {
  const numId = Number(id);
  const key = `${action}:${numId}`;
  if (state.inflight.has(key)) return;
  state.inflight.add(key);

  try {
    switch (action) {
      case "pause":         return await doPause(numId);
      case "resume":        return await doResume(numId);
      case "cancel":        return await doCancel(numId);
      case "retry":         return await doRetry(numId);
      case "force-refresh": return await doForceRefresh(numId);
      case "remove":        return await doRemove(numId, opts);
      case "open":          return await doOpen(numId);
      case "folder":        return doFolder(numId);
      case "copy":          return await doCopy(numId);
      case "details":       return doDetails(numId);
      case "popout":        return await doPopout(numId);
    }
  } catch (err) {
    console.error("[flow] action failed:", action, err);
    toast(err.message || "Action failed", "error");
  } finally {
    state.inflight.delete(key);
    if (["pause", "resume", "cancel", "retry", "force-refresh", "remove"].includes(action)) {
      try { await refreshHistory(); } catch {}
    }
  }
}

/* ---------------- Individual actions ---------------- */
async function doPause(numId) {
  const entry = state.active.get(numId);
  if (entry) {
    entry.status = "Paused";
    entry.speedMBps = 0;
    entry.etaSeconds = 0;
    render();
  }
  let res;
  try { res = await window.api.pauseDownload(numId); }
  catch (err) {
    if (entry) entry.status = "Downloading";
    render();
    toast("Could not pause: " + (err.message || err), "error");
    return;
  }
  if (!res || res.success === false) {
    if (entry) entry.status = "Downloading";
    render();
    toast((res && res.error) || "Could not pause download", "error");
  } else {
    toast("Download paused", "info");
  }
}

async function doResume(numId) {
  const item = findItem(numId);
  if (item && errorNeedsRefresh(item.error)) return refreshWithNewUrl(numId, item);

  const prev = state.active.get(numId);
  const base = {
    id: numId,
    filename: item ? item.filename : (prev?.filename || "download"),
    filePath: item ? item.directory : prev?.filePath,
    totalSize: item ? item.totalSize : (prev?.totalSize || 0),
    percent: prev?.percent || 0,
    speedMBps: 0,
    etaSeconds: 0,
    startedAt: Date.now(),
  };
  const snapshot = { ...base, status: "Paused" };

  state.active.set(numId, { ...base, status: "Downloading" });
  render();

  let res;
  try { res = await window.api.resumeDownload(numId); }
  catch (err) {
    state.active.set(numId, snapshot); render();
    toast("Could not resume: " + (err.message || err), "error");
    return;
  }
  if (!res || res.success === false) {
    state.active.set(numId, snapshot); render();
    toast((res && res.error) || "Could not resume download", "error");
  } else {
    toast("Download resumed", "info");
  }
}

async function doCancel(numId) {
  const entry = state.active.get(numId);
  state.active.delete(numId);
  render();

  let res;
  try { res = await window.api.cancelDownload(numId, true); }
  catch (err) {
    if (entry) state.active.set(numId, entry);
    render();
    toast("Could not cancel: " + (err.message || err), "error");
    return;
  }
  if (!res || res.success === false) {
    if (entry) state.active.set(numId, entry);
    render();
    toast((res && res.error) || "Could not cancel download", "error");
  } else {
    toast("Download cancelled", "info");
  }
}

async function doRetry(numId) {
  const item = findItem(numId);
  if (item && errorNeedsRefresh(item.error)) return refreshWithNewUrl(numId, item);

  const prev = state.active.get(numId);
  const base = {
    id: numId,
    filename: item ? item.filename : (prev?.filename || "download"),
    filePath: item ? item.directory : prev?.filePath,
    totalSize: item ? item.totalSize : (prev?.totalSize || 0),
    percent: 0,
    speedMBps: 0,
    etaSeconds: 0,
    startedAt: Date.now(),
  };
  const snapshot = { ...base, status: "Error" };

  state.active.set(numId, { ...base, status: "Downloading" });
  render();

  let res;
  try { res = await window.api.resumeDownload(numId); }
  catch (err) {
    state.active.set(numId, snapshot); render();
    toast("Could not retry: " + (err.message || err), "error");
    return;
  }
  if (!res || res.success === false) {
    state.active.set(numId, snapshot); render();
    toast((res && res.error) || "Could not retry download", "error");
  } else {
    toast("Retrying download", "info");
  }
}

/**
 * Force-refresh: always opens the URL-refresh flow, regardless of what
 * the stored error message says. Use this when a download is stuck on
 * a generic error but you know the signed URL is dead.
 */
async function doForceRefresh(numId) {
  const item = findItem(numId);
  if (!item) {
    toast("Download not found", "warning");
    return;
  }
  return refreshWithNewUrl(numId, item);
}

/**
 * Two-phase URL refresh:
 *  Phase 1 — try auto-capture via the browser extension. The extension
 *            shows a notification; the user clicks Download on the
 *            site; the fresh URL flows back automatically.
 *  Phase 2 — fall back to manual paste dialog if auto-capture times
 *            out or the extension isn't installed.
 */
async function refreshWithNewUrl(numId, item) {
  // Phase 1 — auto-capture
  if (typeof window.api.requestFreshUrl === "function") {
    toast("Waiting for a fresh link from the browser…", "info");
    let autoRes = null;
    try {
      autoRes = await window.api.requestFreshUrl(numId, { timeoutMs: 90000 });
    } catch (err) {
      console.warn("[flow] requestFreshUrl failed:", err);
    }
    if (autoRes && autoRes.success && autoRes.resumed) {
      toast("Resumed with fresh link captured by extension", "success");
      return;
    }
    if (autoRes && autoRes.error) {
      toast(autoRes.error, "warning");
    }
  }

  // Phase 2 — manual paste fallback
  const newUrl = await refreshUrlDialog();
  if (!newUrl) return;

  const prev = state.active.get(numId);
  const base = {
    id: numId,
    filename: item.filename,
    filePath: item.directory,
    totalSize: item.totalSize,
    percent: prev?.percent || 0,
    speedMBps: 0,
    etaSeconds: 0,
    startedAt: Date.now(),
  };
  const snapshot = { ...base, status: prev?.status || item.status || "Error" };

  state.active.set(numId, { ...base, status: "Downloading" });
  render();

  let res;
  try { res = await window.api.refreshLink(numId, newUrl); }
  catch (err) {
    state.active.set(numId, snapshot); render();
    toast("Could not refresh link: " + (err.message || err), "error");
    return;
  }
  if (!res || res.success === false) {
    state.active.set(numId, snapshot); render();
    toast((res && res.error) || "Could not refresh link", "error");
  } else {
    toast("Resuming with fresh URL", "info");
  }
}

async function doRemove(numId, { skipConfirm = false, deleteFile = false } = {}) {
  const item = findItem(numId);
  // Cancel any in-flight fresh-URL wait before removing.
  try { await window.api.cancelFreshUrlRequest(numId); } catch {}

  let choice;
  if (skipConfirm) {
    choice = deleteFile ? "disk" : "list";
  } else {
    choice = await deleteChoiceDialog(item?.filename);
    if (!choice) return;
  }

  const res = await window.api.deleteDownload(numId, choice === "disk");
  if (res && res.success) {
    toast(choice === "disk" ? "Deleted from disk" : "Removed from history", "info");
  } else if (res && res.error) {
    toast(res.error, "warning");
  }
  state.selected.delete(numId);
}

async function doOpen(numId) {
  const item = findItem(numId);
  if (!item) return;
  const res = await window.api.openFile(item.directory);
  if (res && !res.success) toast(res.error || "File not found", "error");
}

function doFolder(numId) {
  const item = findItem(numId);
  if (!item) return;
  window.api.openFolder(item.directory);
}

async function doCopy(numId) {
  const item = findItem(numId);
  if (!item || !item.url) { toast("No URL to copy", "warning"); return; }
  try {
    await navigator.clipboard.writeText(item.url);
    toast("URL copied", "success");
  } catch { toast("Could not copy URL", "error"); }
}

function doDetails(numId) {
  const item = findItem(numId);
  if (!item) return;
  openDetails(item);
}

async function doPopout(numId) {
  if (!window.api || typeof window.api.openDownloadWindow !== "function") {
    toast("Open-in-window is not available", "warning");
    return;
  }
  try {
    const res = await window.api.openDownloadWindow(numId);
    if (res && res.success === false) {
      toast(res.error || "Could not open download window", "error");
    }
  } catch (err) {
    toast("Could not open download window: " + (err.message || err), "error");
  }
}

/* ---------------- Bulk actions ---------------- */
export async function runBulk(kind) {
  const ids = Array.from(state.selected);
  if (!ids.length) return;

  if (kind === "clear-selection") { state.selected.clear(); render(); return; }

  if (kind === "remove") {
    const label = ids.length === 1 ? undefined : `${ids.length} items`;
    const choice = await deleteChoiceDialog(label);
    if (!choice) return;
    const deleteFile = choice === "disk";
    const results = await Promise.allSettled(
      ids.map((id) => handleAction("remove", id, { skipConfirm: true, deleteFile }))
    );
    const failed = results.filter((r) => r.status === "rejected").length;
    state.selected.clear();
    if (failed) toast(`${failed} action(s) failed`, "warning");
    else toast(deleteFile ? "Deleted from disk" : "Removed from history", "success");
    await refreshHistory();
    return;
  }

  if (kind === "cancel") {
    const ok = await confirmDialog(
      "Cancel selected downloads?",
      `Cancel ${ids.length} active download${ids.length === 1 ? "" : "s"}? Partial files will be deleted.`,
      { confirmLabel: "Cancel downloads" }
    );
    if (!ok) return;
  }

  const results = await Promise.allSettled(ids.map((id) => handleAction(kind, id)));
  const failed = results.filter((r) => r.status === "rejected").length;
  state.selected.clear();
  if (failed) toast(`${failed} action(s) failed`, "warning");
  else toast(`Bulk ${kind} complete`, "success");
  await refreshHistory();
}