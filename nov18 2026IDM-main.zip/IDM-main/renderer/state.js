/* ================================================================
 *  Flow — renderer state
 *
 *  Single source of truth for the renderer's mutable model. Every
 *  module imports and mutates it directly; no framework, no proxies.
 *
 *  The worker has its OWN state.js under downloader/worker/state.js
 *  which uses require("worker_threads") — that file must NEVER be
 *  copied here. The renderer is an ES-module context; anything using
 *  require() or module.exports will abort the module graph at boot.
 * ================================================================ */

export const state = {
  /* History rows pulled from SQLite via IPC. */
  history: [],

  /* Live downloads started this session. Map<id:number, entry>. */
  active: new Map(),

  /* Row ids selected for bulk actions. */
  selected: new Set(),

  /* `${action}:${id}` keys of user actions currently in flight. */
  inflight: new Set(),

  /* Current view. Matches a [data-view] section in index.html. */
  view: "dashboard",

  /* "All Downloads" view controls. */
  allFilter: "all",
  allSearch: "",
  allSort: "newest",
  selectMode: false,

  /* Theme — persisted across launches. */
  theme: localStorage.getItem("flow-theme") || "dark",

  /* User-chosen save folder (null → main resolves default). */
  directory: null,

  /* Filled in by boot() from window.api.getDefaultDirectory(). */
  defaultDirectory: null,
};