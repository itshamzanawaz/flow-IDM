/* ================================================================
 *  Flow — Settings window renderer
 * ================================================================ */

import { applyTheme, toggleTheme } from "./theme.js";
import { toast } from "./toast.js";

applyTheme();

const $ = (s) => document.querySelector(s);

async function init() {
  let s = {};
  try { s = await window.api.getSettings(); } catch {}
  const isLinux = s.platform === "linux";

  // Populate toggles
  if ($("#flow-toggle-tray")) $("#flow-toggle-tray").checked = !!s.minimizeToTray;
  if ($("#flow-toggle-startup")) $("#flow-toggle-startup").checked = !!s.startAtLogin;
  
  if ($("#startup-desc")) {
    $("#startup-desc").textContent = isLinux
      ? "Installs ~/.config/autostart/flow.desktop."
      : "Registers Flow as a login item.";
  }

  // Fetch directory info
  try {
    if (window.api.getDefaultDirectory) {
      const dir = await window.api.getDefaultDirectory();
      if ($("#settings-dir")) $("#settings-dir").textContent = dir || "Default Downloads";
    }
  } catch {}

  // Fetch completed count
  try {
    const hist = await window.api.getHistory();
    const completed = hist.filter(h => String(h.status).toLowerCase() === 'completed').length;
    if ($("#settings-completed-count")) $("#settings-completed-count").textContent = completed;
  } catch {}

  // Events
  $("#settings-theme-toggle")?.addEventListener("click", () => {
    toggleTheme();
    if ($("#settings-theme-label")) {
      $("#settings-theme-label").textContent = document.documentElement.getAttribute("data-theme") === "dark" ? "Dark" : "Light";
    }
  });

  $("#settings-choose-dir")?.addEventListener("click", async () => {
    try {
      const dir = await window.api.selectDirectory();
      if (dir && $("#settings-dir")) {
        $("#settings-dir").textContent = dir;
        toast("Directory updated", "success");
      }
    } catch (e) { toast("Failed to choose directory", "error"); }
  });

  $("#settings-reset-dir")?.addEventListener("click", () => {
     if ($("#settings-dir")) $("#settings-dir").textContent = "Default Downloads";
     toast("Reset to default", "info");
  });

  $("#flow-toggle-tray")?.addEventListener("change", async (e) => {
    const v = e.target.checked;
    try {
      const res = await window.api.setMinimizeToTray(v);
      if (res && res.success === false) throw new Error(res.error);
      toast(v ? "Flow will minimize to tray" : "Flow will quit on close", "success");
    } catch (err) {
      e.target.checked = !v;
      toast("Failed to save setting", "error");
    }
  });

  $("#flow-toggle-startup")?.addEventListener("change", async (e) => {
    const v = e.target.checked;
    try {
      const res = await window.api.setStartAtLogin(v);
      if (res && res.success === false) throw new Error(res.error);
      toast(v ? "Flow will start at login" : "Flow will not start at login", "success");
    } catch (err) {
      e.target.checked = !v;
      toast("Failed to update autostart", "error");
    }
  });

  $("#flow-quit-btn")?.addEventListener("click", () => {
    window.api.quitApp();
  });

  $("#settings-clear-completed")?.addEventListener("click", async () => {
     const res = await window.api.clearCompleted();
     if (res && res.success) {
        toast(`Removed ${res.removed} entries`, "success");
        if ($("#settings-completed-count")) $("#settings-completed-count").textContent = "0";
     } else {
        toast("Failed to clear completed", "error");
     }
  });
}
init();