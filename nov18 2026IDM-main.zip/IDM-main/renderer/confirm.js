/* ================================================================
 *  Flow — confirm dialog
 * ================================================================ */

import { $ } from "./utils.js";

let _confirmResolver = null;

export function confirmDialog(title, message, { confirmLabel = "Confirm", danger = true } = {}) {
  return new Promise((resolve) => {
    _confirmResolver = resolve;
    const t = $("#confirm-title"); if (t) t.textContent = title;
    const m = $("#confirm-msg");  if (m) m.textContent = message;
    const ok = $("#confirm-ok");
    if (ok) {
      ok.textContent = confirmLabel;
      ok.classList.toggle("btn-danger", danger);
      ok.classList.toggle("btn-primary", !danger);
    }
    $("#confirm-modal")?.classList.add("open");
  });
}

export function closeConfirm(result) {
  $("#confirm-modal")?.classList.remove("open");
  if (_confirmResolver) { _confirmResolver(result); _confirmResolver = null; }
}