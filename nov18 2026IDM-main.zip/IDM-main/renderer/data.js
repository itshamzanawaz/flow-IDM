/* ================================================================
 *  Flow — merged data model (live + history)
 *
 *  The merged list intentionally includes active downloads that are
 *  NOT yet in history, because main writes the DB row asynchronously
 *  after the download starts. Without this, a started download is
 *  invisible on the "All Downloads" and "Dashboard" views for as long
 *  as the DB write is pending — which is perceived as a freeze.
 * ================================================================ */

import { state } from "./state.js";

export function getEffectiveStatus(item) {
  const live = state.active.get(item.id);
  if (live) return live.status;
  const s = String(item.status || "").toLowerCase();
  if (s === "downloading" || s === "preparing") return "Paused";
  return item.status;
}

export function getMergedList() {
  const merged = state.history.map((item) => {
    const live = state.active.get(item.id);
    return {
      ...item,
      status: getEffectiveStatus(item),
      percent: live ? (live.percent || 0) : 0,
      speedMBps: live ? (live.speedMBps || 0) : 0,
      etaSeconds: live ? (live.etaSeconds || 0) : 0,
      isLive: !!live,
    };
  });

  // Include active downloads that are not yet in history (DB write
  // pending). This is the fix for "download starts but nothing shows".
  const seen = new Set(state.history.map((x) => x.id));
  for (const [id, live] of state.active.entries()) {
    if (seen.has(id)) continue;
    merged.push({
      id,
      filename: live.filename || "download",
      directory: live.filePath || "",
      url: live.url || "",
      totalSize: live.totalSize || 0,
      timestamp: new Date(live.startedAt || Date.now()).toISOString(),
      status: live.status || "Downloading",
      percent: live.percent || 0,
      speedMBps: live.speedMBps || 0,
      etaSeconds: live.etaSeconds || 0,
      isLive: true,
    });
  }

  return merged;
}

export function getActiveList() {
  return Array.from(state.active.values()).sort(
    (a, b) => (b.startedAt || 0) - (a.startedAt || 0)
  );
}

export function findItem(id) {
  const numId = Number(id);
  const row = state.history.find((x) => x.id === numId);
  if (row) {
    const live = state.active.get(numId);
    return {
      ...row,
      status: live ? live.status : getEffectiveStatus(row),
    };
  }
  const entry = state.active.get(numId);
  if (entry) {
    return {
      id: numId,
      filename: entry.filename,
      directory: entry.filePath,
      url: entry.url,
      totalSize: entry.totalSize,
      status: entry.status,
    };
  }
  return null;
}