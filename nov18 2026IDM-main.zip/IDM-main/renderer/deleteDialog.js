/* ================================================================
 *  Flow — delete-choice dialog
 * ================================================================ */

let _resolver = null;
let _modalEl = null;

function ensureModal() {
  if (_modalEl && document.body.contains(_modalEl)) return _modalEl;

  const modal = document.createElement("div");
  modal.id = "delete-choice-modal";
  modal.className = "modal";
  modal.setAttribute("role", "dialog");
  modal.setAttribute("aria-modal", "true");
  modal.setAttribute("aria-labelledby", "delete-choice-title");

  modal.innerHTML = `
    <div class="modal-content confirm-content">
      <h2 class="modal-title" id="delete-choice-title">Delete download</h2>
      
      <!-- Using a div here ensures block-level text wrapping -->
      <div class="confirm-msg delete-choice-msg" id="delete-choice-msg"></div>
      
      <div class="delete-choice-note">
        Removing from the list keeps the file on disk. Deleting from disk permanently removes the file and any partial data.
      </div>

      <div class="delete-choice-actions">
        <button type="button" class="btn btn-danger" data-choice="disk">
          Delete from disk
        </button>
        <button type="button" class="btn btn-ghost" data-choice="list">
          Remove from list only
        </button>
        <button type="button" class="link-btn" data-choice="cancel" style="justify-content: center; padding: 6px 0; width: 100%;">
          Cancel
        </button>
      </div>
    </div>
  `;

  modal.addEventListener("click", (e) => {
    if (e.target === modal) return close(null);
    const btn = e.target.closest("[data-choice]");
    if (!btn) return;
    const choice = btn.dataset.choice;
    close(choice === "cancel" ? null : choice);
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && _modalEl && _modalEl.classList.contains("open")) {
      close(null);
    }
  });

  document.body.appendChild(modal);
  _modalEl = modal;
  return modal;
}

function close(result) {
  if (_modalEl) _modalEl.classList.remove("open");
  if (_resolver) {
    const r = _resolver;
    _resolver = null;
    r(result);
  }
}

export function deleteChoiceDialog(label) {
  return new Promise((resolve) => {
    _resolver = resolve;
    const modal = ensureModal();
    const msg = modal.querySelector("#delete-choice-msg");
    
    if (msg) {
      // We wrap the filename in a <strong> tag so it visually separates from the prompt
      if (label) {
        msg.innerHTML = `What would you like to do with <strong>“${label}”</strong>?`;
      } else {
        msg.textContent = "What would you like to do with this download?";
      }
    }
    
    modal.classList.add("open");
  });
}