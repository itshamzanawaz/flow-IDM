/* ================================================================
 *  Flow — toasts
 * ================================================================ */

import { SVG } from "./icons.js";
import { escapeHtml, $ } from "./utils.js";

export function toast(message, type = "info") {
  const container = $("#toast-container");
  if (!container) return;
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.innerHTML = `${SVG[type] || SVG.info}<span>${escapeHtml(message)}</span>`;
  container.appendChild(el);
  requestAnimationFrame(() => el.classList.add("show"));
  setTimeout(() => {
    el.classList.remove("show");
    setTimeout(() => el.remove(), 250);
  }, 3200);
}